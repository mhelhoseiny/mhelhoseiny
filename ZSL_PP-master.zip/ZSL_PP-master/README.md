# ZSLPP
Zero Shot Learning from Noisy Text Description at Part Precision

Data:
You can download the data [CUB2011](https://drive.google.com/open?id=0B_8vkk7CF-pwejFFcEp2R1FfRFU) and [NABird](https://drive.google.com/open?id=0B_8vkk7CF-pwOGhpQXFUUXZlQjg). The [trained models](https://drive.google.com/open?id=0B_8vkk7CF-pwMU5QQUlUOTZFblU) reproduce the results in the paper.  

Raw wikipedia article data and detailed merging information of NABird can be obtained [here](https://drive.google.com/open?id=0B_8vkk7CF-pwckxLQTVkcDBadGc).
