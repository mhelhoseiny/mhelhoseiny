(ProjectiveTransformation.cs) This class takes a rectangle and a any convex 4 points to generate transformation between one to the other.

I was also involved in an implementation of thin plate interpolation to do non linear transformation of images using Newton approach.
(This is written in Delphi) I can find it if you want to have a look. Let me know then



