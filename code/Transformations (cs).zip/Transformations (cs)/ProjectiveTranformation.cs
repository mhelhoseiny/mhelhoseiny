using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;


namespace calibaration
{
  public class ProjectiveTranformation
    {
        private RectangleF _srcRect;
        float[,] _Matrix = new float[3, 3];
        float[,] _InverseMatrix = new float[3, 3];

        private PointF _point0;
        private PointF _point1;
        private PointF _point2;
        private PointF _point3;
        public ProjectiveTranformation(RectangleF srcRect, PointF point0, PointF point1, PointF point2, PointF point3)
        {
            _srcRect = srcRect;
            _point0 = point0;
            _point1 = point1;
            _point2 = point2;
            _point3 = point3;
            PrepareTransformation();
        }

        public float[,] Mult(float[,] _Matrix, float[,] R)
        {
            float[,] Result=new float[3,3];
            for( int i = 0 ;i<= 2;i++ )
                for (int j = 0; j <= 2; j++)
                {
                    Result[i, j] = _Matrix[0, j] * R[i, 0] + 
                        _Matrix[1, j] * R[i, 1] + 
                        _Matrix[2, j] * R[i, 2];

                }
            return Result;
       }
        public PointF Transform(PointF srcPoint)
        {
            PointF returnedPoint = new PointF();

            float X, Y, Z;


            X = srcPoint.X; Y = srcPoint.Y;
            Z = _Matrix[0, 2] * X + _Matrix[1, 2] * Y + _Matrix[2, 2];

            if (Z == 0) { throw new Exception("Invalid value"); }
            else
                if (Z == 1)
                {

                    returnedPoint.X = (_Matrix[0, 0] * X + _Matrix[1, 0] * Y + _Matrix[2, 0]);
                    returnedPoint.Y = (_Matrix[0, 1] * X + _Matrix[1, 1] * Y + _Matrix[2, 1]);

                }
                else
                {

                    Z = 1 / Z;
                    returnedPoint.X = ((_Matrix[0, 0] * X + _Matrix[1, 0] * Y + _Matrix[2, 0]) * Z);
                    returnedPoint.Y = ((_Matrix[0, 1] * X + _Matrix[1, 1] * Y + _Matrix[2, 1]) * Z);

                }
            return returnedPoint;
        }
        public PointF ReverseTranaform(PointF DstPt)
        {
            PointF returnedPoint = new PointF();
            float X,Y,Z;

 
            X = DstPt.X; Y = DstPt.Y;
            Z = _InverseMatrix[0, 2] * DstPt.X +
      _InverseMatrix[1, 2] * DstPt.Y +
      _InverseMatrix[2, 2];

            if (Z == 0) { throw new Exception("Invalid value"); }

            else if (Z == 1)
            {


                returnedPoint.X = _InverseMatrix[0, 0] * X + _InverseMatrix[1, 0] * Y + _InverseMatrix[2, 0];
                returnedPoint.Y = _InverseMatrix[0, 1] * X + _InverseMatrix[1, 1] * Y + _InverseMatrix[2, 1];
            }
            else
            {
                Z = 1 / Z;
                returnedPoint.X = (_InverseMatrix[0, 0] * X + _InverseMatrix[1, 0] * Y + _InverseMatrix[2, 0]) * Z;
                returnedPoint.Y = (_InverseMatrix[0, 1] * X + _InverseMatrix[1, 1] * Y + _InverseMatrix[2, 1]) * Z;

            }
            return returnedPoint;
        }
       

        private void PrepareTransformation()
        {

            float dx1, dx2, px, dy1, dy2, py;
            float g, h, k;


            px = _point0.X - _point1.X + _point2.X - _point3.X;
            py = _point0.Y - _point1.Y + _point2.Y - _point3.Y;

            if ((px == 0) && (py == 0))
            {

                // affine mapping
                _Matrix[0, 0] = _point1.X - _point0.X;
                _Matrix[1, 0] = _point2.X - _point1.X;
                _Matrix[2, 0] = _point0.X;

                _Matrix[0, 1] = _point1.Y - _point0.Y;
                _Matrix[1, 1] = _point2.Y - _point1.Y;
                _Matrix[2, 1] = _point0.Y;

                _Matrix[0, 2] = 0;
                _Matrix[1, 2] = 0;
                _Matrix[2, 2] = 1;
            }


            else
            {

                // projective mapping
                dx1 = _point1.X - _point2.X;
                dx2 = _point3.X - _point2.X;
                dy1 = _point1.Y - _point2.Y;
                dy2 = _point3.Y - _point2.Y;
                k = dx1 * dy2 - dx2 * dy1;
                if (k != 0)
                {

                    g = (px * dy2 - py * dx2) / k;
                    h = (dx1 * py - dy1 * px) / k;

                    _Matrix[0, 0] = _point1.X - _point0.X + g * _point1.X;
                    _Matrix[1, 0] = _point3.X - _point0.X + h * _point3.X;
                    _Matrix[2, 0] = _point0.X;

                    _Matrix[0, 1] = _point1.Y - _point0.Y + g * _point1.Y;
                    _Matrix[1, 1] = _point3.Y - _point0.Y + h * _point3.Y;
                    _Matrix[2, 1] = _point0.Y;

                    _Matrix[0, 2] = g;
                    _Matrix[1, 2] = h;
                    _Matrix[2, 2] = 1;

                }
                else
                {
                    throw new Exception("Invalid case");
                    //FillChar(_Matrix, _Matrix.Length, 0);

                }
            }
                // denormalize texture space (u, v)

                float[,] R = new float[3, 3];
                MakeIdentity(R);
                R[0, 0] = 1 / (_srcRect.Right - _srcRect.Left);
                R[1, 1] = 1 / (_srcRect.Bottom - _srcRect.Top);

                _Matrix= Mult(_Matrix, R);

                MakeIdentity(R);

                R[2, 0] = -_srcRect.Left;
                R[2, 1] = -_srcRect.Top;
                _Matrix =  Mult(_Matrix, R);

                _InverseMatrix = Inverse(_Matrix);

              





        }

        private float[,] Inverse(float[,] _Matrix)
        {
            float Det;

            float[,] result =  new float[3,3];
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    result[i, j] = _Matrix[i, j];

 
            }
            Det = Determinant(_Matrix);
            //I think It should be e-5
            if (Math.Abs(Det) < (Math.E - 5))
                //_Matrix = IdentityMatrix();
                MakeIdentity(result);
            else
            {
                Adjoint(result);
                Scale(result, 1 / Det);
            }
            float[,] testInverse = Mult(_Matrix, result);
            return result;
        }

        public void Scale(float[,]Matrix,float x)
        {
                for(int i=0;i<3;i++)
                      for (int j = 0; j < 3; j++)
                      {
                          Matrix[i, j] = (Matrix[i, j] * x);
         
                      }
         
        }

        private float Determinant(float[,] _Matrix)
     {

        float result;
        result = function_DET(_Matrix[0, 0], _Matrix[1, 0], _Matrix[2, 0],
                     _Matrix[0,1], _Matrix[1,1], _Matrix[2,1],
                     _Matrix[0,2], _Matrix[1,2], _Matrix[2,2]);
        return result;

     }

        private float function_DET(float a1, float a2, float a3, float b1, float b2, float b3, float c1, float c2, float c3)
        {
            float Result;
            Result =
              a1 * (b2 * c3 - b3 * c2) -
              b1 * (a2 * c3 - a3 * c2) +
              c1 * (a2 * b3 - a3 * b2);
            return Result;

        }

    

        private void Adjoint(float[,] _Matrix) 
        {
            float a1, a2, a3,b1, b2, b3,c1, c2, c3;
            a1 = _Matrix[0, 0]; a2 = _Matrix[0, 1]; a3 = _Matrix[0, 2];
            b1 = _Matrix[1, 0]; b2 = _Matrix[1, 1]; b3 = _Matrix[1, 2];
            c1 = _Matrix[2, 0]; c2 = _Matrix[2, 1]; c3 = _Matrix[2, 2];
            _Matrix[0, 0] = A_DET(b2, b3, c2, c3);
            _Matrix[0, 1] = -A_DET(a2, a3, c2, c3);
            _Matrix[0, 2] = A_DET(a2, a3, b2, b3);
            
            _Matrix[1, 0] = -A_DET(b1, b3, c1, c3);
            _Matrix[1, 1] = A_DET(a1, a3, c1, c3);
            _Matrix[1, 2] = -A_DET(a1, a3, b1, b3);
            
            _Matrix[2, 0] = A_DET(b1, b2, c1, c2);
            _Matrix[2, 1] = -A_DET(a1, a2, c1, c2);
            _Matrix[2, 2] = A_DET(a1, a2, b1, b2);

        }

        private float A_DET(float a1,float a2,float b1,float b2)
        {
            float Result;
              Result = a1 * b2 - a2 * b1;
              return Result;
        }

        private void Mult_sara(float[,] _Matrix, float[,] R)
        {
           
            float[,] result = new float[3, 3];
                for(int i =0;i<3;i++)
                {
                 result[0,i] =  (_Matrix[0, 0] * R[0, i] + _Matrix[0, 1] * R[1, i] + _Matrix[0, 2] * R[2, i]);

                 result[1, i] = (_Matrix[1, 0] * R[0, i] + _Matrix[1, 1] * R[1, i] + _Matrix[1, 2] * R[2, i]);

                 result[2, i] = (_Matrix[2, 0] * R[0, i] + _Matrix[2, 1] * R[1, i] + _Matrix[2, 2] * R[2, i]);

                }
             
                _Matrix = result;
                //return result;    
        }

        private void MakeIdentity(float[,] R)
        {
            //Make Identity
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    if (i == j)
                    {
                        R[i, j] = 1;
                    }
                    else

                        R[i, j] = 0;
                }
        }

    

    }
}

