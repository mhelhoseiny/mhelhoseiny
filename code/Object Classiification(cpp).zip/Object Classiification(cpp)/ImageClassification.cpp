#include "ImageClassification.h"


ImageClassification::ImageClassification(void)
{
	
	HogDescMap[ObjClass::person] = new HOGDescriptor(Size(64,128), Size(16,16), Size(8,8),
    	Size(8,8), 9);
	HogDescMap[ObjClass::car] = new HOGDescriptor(Size(104,56), Size(16,16), Size(8,8),
    	Size(8,8), 18);
	HogDescMap[ObjClass::vehicles] = new HOGDescriptor(Size(120,80), Size(16,16), Size(8,8),
    	Size(8,8), 18);
	HogDescMap[ObjClass::object] = new HOGDescriptor(Size(64,64), Size(16,16), Size(8,8),
    	Size(8,8), 9);
	HogDescMap[ObjClass::bike] = new HOGDescriptor(Size(104,64), Size(16,16), Size(8,8),
    	Size(8,8), 18);

	/*HogDesc = HOGDescriptor(Size(32,64), Size(16,16), Size(8,8),
    	Size(8,8), 9);*/
}


ImageClassification::~ImageClassification(void)
{
}

void ImageClassification::LoadLearnedData()
{
}

void ImageClassification::Learn()
{

}

vector<ObjClass> ImageClassification::Classify(Mat currFrame, Mat MaskFrame, vector<Rect> objects) 
{
	vector<ObjClass>  vclasses(1);
	return vclasses;
}

ObjClass ImageClassification::Classify(Mat currFrame, Mat MaskFrame, Rect object) 
{
	return ObjClass::person;
}

std::string ObjClassToString(ObjClass objectClass)
{
	
	/*person =1,
	car = 2,
	vehicles =3,
	object = 4,
    bike =5 // or bikes*/

	switch (objectClass)
	{
		case ObjClass::person: return "person";
			break;
		case ObjClass::bike: return "bike";
			break;
		case ObjClass::car: return "car";
			break;
		case ObjClass::vehicles: return "vehicles";
			break;
	
		case ObjClass::object: return "object";
			break;
		default : return "None";

	}
}

void ImageClassification::AddToTrainingData(ObjClass obClass, Features* ftrs)
{
	switch(obClass)
	{
		case ObjClass::car : CarFeatures.push_back(ftrs); 
		break;
		case ObjClass::vehicles : VehicleFeatures.push_back(ftrs); 
		break;
		case ObjClass::bike : BikeFeatures.push_back(ftrs); 
		break;
		case ObjClass::person : HumanFeatures.push_back(ftrs); 
		break;
		case ObjClass::object : ObjectFeatures.push_back(ftrs); 
		break;
		/*case ObjClass::object : HumanFeatures.push_back(ftrs); 
		break;*/

	}
}

svm_parameter * readFromString(char* svmParams)
{
  //const char* strCharP =svmParams; 

  int argc=0;
  char* str = new char[100];
  str = strcpy(str,svmParams);
  const char deli[] = {' ','\0'};
  char*	 pch = strtok(str,deli);
  
  while (pch != NULL)
  {
    printf ("%s\n",pch);
    pch = strtok (NULL, " ");
	argc++;
  }
  char** argv = new char*[argc];
  int k=0;
  pch = strtok(svmParams," ");
   while (pch != NULL)
  {
    printf ("%s\n",pch);
    pch = strtok (NULL, " ");
	argv[k] = pch;
	k++;
  }

	struct svm_parameter * param = new svm_parameter();
	int i;

	// default values
	param->svm_type = C_SVC;
	param->kernel_type = RBF;
	param->degree = 3;
	param->gamma = 0;	// 1/num_features
	param->coef0 = 0;
	param->nu = 0.5;
	param->cache_size = 100;
	param->C = 1;
	param->eps = 1e-3;
	param->p = 0.1;
	param->shrinking = 1;
	param->probability = 0;
	param->nr_weight = 0;
	param->weight_label = NULL;
	param->weight = NULL;

	// parse options
	for(i=0;i<argc;i++)
	{
		if(argv[i][0] != '-') break;
		if(++i>=argc)
			break;
		switch(argv[i-1][1])
		{
			case 's':
				param->svm_type = atoi(argv[i]);
				break;
			case 't':
				param->kernel_type = atoi(argv[i]);
				break;
			case 'd':
				param->degree = atoi(argv[i]);
				break;
			case 'g':
				param->gamma = atof(argv[i]);
				break;
			case 'r':
				param->coef0 = atof(argv[i]);
				break;
			case 'n':
				param->nu = atof(argv[i]);
				break;
			case 'm':
				param->cache_size = atof(argv[i]);
				break;
			case 'c':
				param->C = atof(argv[i]);
				break;
			case 'e':
				param->eps = atof(argv[i]);
				break;
			case 'p':
				param->p = atof(argv[i]);
				break;
			case 'h':
				param->shrinking = atoi(argv[i]);
				break;
			case 'b':
				param->probability = atoi(argv[i]);
				break;
			
			case 'w':
				++param->nr_weight;
				param->weight_label = (int *)realloc(param->weight_label,sizeof(int)*param->nr_weight);
				param->weight = (double *)realloc(param->weight,sizeof(double)*param->nr_weight);
				param->weight_label[param->nr_weight-1] = atoi(&argv[i-1][2]);
				param->weight[param->nr_weight-1] = atof(argv[i]);
				break;
			default:
				fprintf(stderr,"Unknown option: -%c\n", argv[i-1][1]);
				break;
		}
	}


	// determine filenames

	return param;

}
void ImageClassification::LearnFromLoadedFeatureVectors()
{
	
	struct svm_problem prob;		
	struct svm_model *model;
	struct svm_node *x_space;
	prob.l = HumanFeatures.size()+ CarFeatures.size()+VehicleFeatures.size()+ObjectFeatures.size()+ BikeFeatures.size();
	int featureLength  = HumanFeatures[0]->HOG.size();
	int elements  = prob.l*featureLength;
	prob.y = (double*) malloc(sizeof(double)*prob.l);
	prob.x = (svm_node **)malloc(sizeof(svm_node *)*prob.l);
	x_space = (svm_node *) malloc(sizeof(svm_node)*elements);
	int k=0;
	int j=0;
	for(int i=0;i<HumanFeatures.size();i++,k++)
	{
		prob.y[k] = (double) ObjClass::person;
		prob.x[k] = &x_space[j];
		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=HumanFeatures[i]->HOG[l];
			j++;
		}

	}
	for(int i=0;i<CarFeatures.size();i++,k++)
	{
		prob.y[k] = (double) ObjClass::car;
		prob.x[k] = &x_space[j];

		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=CarFeatures[i]->HOG[l];
			j++;
		}

	}
	for(int i=0;i<VehicleFeatures.size();i++,k++)
	{
		prob.y[k] = (double) ObjClass::vehicles;
		prob.x[k] = &x_space[j];
		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=VehicleFeatures[i]->HOG[l];
			j++;
		}
	}
	for(int i=0;i<ObjectFeatures.size();i++,k++)
	{
		prob.y[k] = (double) ObjClass::object;
		prob.x[k] = &x_space[j];
		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=ObjectFeatures[i]->HOG[l];
			j++;
		}

	}
	for(int i=0;i<BikeFeatures.size();i++,k++)
	{
		prob.y[k] = (double) ObjClass::bike;
		prob.x[k] = &x_space[j];
		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=BikeFeatures[i]->HOG[l];
			j++;
		}

	}
	/*
	char  svmparams []= _T("-s 0 -c 10 -g 1 -t 2 -d 1 -b 1");
	struct svm_parameter * param = readFromString(svmparams);		// set by parse_command_line
	svmModel = svm_train(&prob,param);*/
	//svm_model=svmtrain(TrL(:), [PredTrL(:),zeros(size(PredTrL(:),1),1)],'-s 0 -c 10 -g 1 -t 2 -d 1 -b 1');
}



void ImageClassification::HOGTrainFromClassDSFolder(ObjClass obClass, string DatasetPath, float traininggRatio)
{
	HOGDescriptor* hDesc = HogDescMap[obClass];
	vector<string> arrPosFiles;
	std::stringstream sstm;
	sstm << DatasetPath<<"\\Pos" ;
	string DataSetPosFolder = sstm.str();
	SearchDirectory(DataSetPosFolder.c_str(), &arrPosFiles);
	int trainingPosSamples = traininggRatio*arrPosFiles.size(); 
	
	std::stringstream sstm2;
	sstm2 << DatasetPath<<"\\Neg" ;
	string DataSetNegFolder = sstm2.str();
	vector<string> arrNegFiles;
	SearchDirectory(DataSetNegFolder.c_str(), &arrNegFiles);
	int trainingNegSamples = traininggRatio*arrNegFiles.size(); 

	vector<vector<float>> PosFetures;
	for(int i=0;i<trainingPosSamples;i++)
	{
		string fname  = arrPosFiles[i];
		Mat im = imread(fname);
		vector<float> hogFeature;
		hDesc->compute(im,hogFeature);
		PosFetures.push_back(hogFeature);
	}
	
	vector<vector<float>> NegFetures;
	for(int i=0;i<trainingNegSamples;i++)
	{
		string fname  = arrNegFiles[i];
		Mat im = imread(fname);
		vector<float> hogFeature;
		hDesc->compute(im,hogFeature);
		NegFetures.push_back(hogFeature);
	}

	struct svm_problem prob;		
	struct svm_model *model;
	struct svm_node *x_space;
	prob.l = PosFetures.size()+ NegFetures.size();
	int featureLength  = PosFetures[0].size();
	int elements  = prob.l*(featureLength+1);
	prob.y = (double*) malloc(sizeof(double)*prob.l);
	prob.x = (svm_node **)malloc(sizeof(svm_node *)*prob.l);
	x_space = (svm_node *) malloc(sizeof(svm_node)*elements);
	int k=0;
	int j=0;
	for(int i=0;i<PosFetures.size();i++,k++)
	{
		prob.y[k] = 0;
		prob.x[k] = &x_space[j];
		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=PosFetures[i][l];
			j++;
		}
		x_space[j].index=-1;
		j++;
	}
	for(int i=0;i<NegFetures.size();i++,k++)
	{
		prob.y[k] = 1;
		prob.x[k] = &x_space[j];

		for(int l = 0;l<featureLength;l++)
		{
			x_space[j].index=l;
			x_space[j].value=NegFetures[i][l];
			j++;
		}
		x_space[j].index=-1;
		j++;

	}
	//char csstr[]= _T("");
	//char csstr[]= "-s 0 -c 10 -g 1 -t 2 -d 1 -b 1";
	// %svm_model=svmtrain(TrL(:), [PredTrL(:),zeros(size(PredTrL(:),1),1)],['-s 1 -c 10 -b 1 -w1 ',num2str(1.0/cntN), ' -w2 ',num2str(1.0/cntP)]);

	std::stringstream sstmparams;
	sstmparams << "-s 1 -c 0.01 -b 1 -w1 " <<1.0/PosFetures.size()<<" -w2 "<<1.0/NegFetures.size() ;
	string paramstr = sstmparams.str();
	char* csstr= (char*)paramstr.c_str();
	
	struct svm_parameter * param = readFromString(csstr);		// set by parse_command_line
	svmModel = svm_train(&prob,param);
	
	std::stringstream sstm3;
	sstm3 << DatasetPath<<"\\SVMModel.bin" ;
	string svmModelPath = sstm3.str();
	svm_save_model(svmModelPath.c_str(),svmModel);
	/*double* acc = new double[5];
	svm_cross_validation(&prob,param,5,acc );*/
}
//loads a file from SVMlight and converts the loaded support vectors to the weight vector.
void loadLinSVMfromModelFile(const char* filename, vector<float>* svm){
	ifstream svinstr (filename);
	string line;
	float d,g,s,r, b;
	int maxidx,numtrain,numsvm, type;
        int cur_svidx = 0;
	getline(svinstr, line);
        line.clear();
	svinstr >> type;
	if (type != 0){
		std::cout << "Error: Only linear SVM supported" << endl;
		return;
	}
	getline(svinstr, line);
	svinstr >> d;		//Kernel parameter d...
	line.clear();
	getline(svinstr, line);
	svinstr >>g;
        line.clear();
	getline(svinstr, line);
	svinstr >> s;
        line.clear();
	getline(svinstr, line);
	svinstr >> r;
        line.clear();
	getline(svinstr, line);
         line.clear();
	getline(svinstr, line);
	svinstr >> maxidx;	//highest feature idx
         line.clear();
	getline(svinstr, line);
	svinstr >> numtrain;	//num of training vecs
         line.clear();
	getline(svinstr, line);
	svinstr >> numsvm;	//num of support vecs
	 line.clear();
	getline(svinstr, line);
	svinstr >> b;		//offset b;
	 line.clear();
	getline(svinstr, line);
	 line.clear();
	svm->clear();
	svm->resize(maxidx+1, 0);
	(*svm)[maxidx] = -b;
	while(!svinstr.eof())
	{
		cur_svidx++;
		if (cur_svidx%20 ==0)
		{
			std::cout << cvRound((double)cur_svidx/(double)numsvm*100) << "%";
			flush(std::cout);
		}
		getline(svinstr, line);
		if (line.size() < 5){
			std::cout << "Skipped line" << endl;
			continue;
		}
		istringstream strstream(line);
		float ftemp;
		int itemp;
		double alpha;
		strstream >> alpha;
		int lastitemp = -1;
		while (!strstream.eof()) {
			strstream >> itemp;
			if (itemp == lastitemp){
				break;
			}
			lastitemp = itemp;
			char x;
			strstream >> x;
			strstream >>ftemp;
			(*svm)[itemp-1] += alpha * ftemp;
		}
		svinstr.sync();
	}
	
}

vector<float>* loadLinSVMfromModel(svm_model* libLinSVMModel)
{
	vector<float>* svm = new vector<float>();
	if (libLinSVMModel->param.svm_type != 0)
	{
		std::cout << "Error: Only linear SVM supported" << endl;
		return NULL;
	}
	svm_node* currP = libLinSVMModel->SV[0];
	while(currP->index !=-1 )
		{
			svm->push_back(0);
			
			currP++;
		}


	
	for(int i=0;i<libLinSVMModel->l;i++)
	{
		double alpha = libLinSVMModel->sv_coef[0][i];
		float ftemp;
		int itemp;
		svm_node* currVec = libLinSVMModel->SV[i];
		svm_node* currPtr = currVec;
		while(currPtr->index !=-1 )
		{
			itemp = currPtr->index;
			ftemp = currVec->value;
			(*svm)[itemp] += alpha * ftemp;
			currPtr++;
		}
		
	}
	
	return svm;
}
float ImageClassification::HOGTestFromClassDSFolder( svm_model *svmModel, ObjClass obClass,  string DatasetPath, float traininggRatio)
{
	SVM opCvSVM;
	
	float accuracy;
	HOGDescriptor* hDesc = HogDescMap[obClass];
	bool usingLIBSVM = false;
	if(!usingLIBSVM)
	{
		//
		vector<float>* svspl = loadLinSVMfromModel(svmModel);
		hDesc->setSVMDetector(*svspl);

	}

	vector<string> arrPosFiles;
	std::stringstream sstm;
	sstm << DatasetPath<<"\\Pos" ;
	string DataSetPosFolder = sstm.str();
	SearchDirectory(DataSetPosFolder.c_str(), &arrPosFiles);
	int trainingPosSamples = traininggRatio*arrPosFiles.size(); 
	
	std::stringstream sstm2;
	sstm2 << DatasetPath<<"\\Neg" ;
	string DataSetNegFolder = sstm2.str();
	vector<string> arrNegFiles;
	SearchDirectory(DataSetNegFolder.c_str(), &arrNegFiles);
	int trainingNegSamples = traininggRatio*arrNegFiles.size(); 
	int errors = 0;
	
	for(int i=trainingPosSamples;i<arrPosFiles.size();i++)
	{
		string fname  = arrPosFiles[i];
		Mat im = imread(fname);

		if(usingLIBSVM)
		{
			vector<float> hogFeature;
			hDesc->compute(im,hogFeature);
			struct svm_node* featureNodes = (svm_node *)malloc(sizeof(svm_node)*(hogFeature.size()+1));
			for(int j=0;j<hogFeature.size();j++)
			{
				featureNodes[j].index=j;
				featureNodes[j].value=hogFeature[j];
			}
			featureNodes[hogFeature.size()].index = -1;

			double v = svm_predict(svmModel,featureNodes);
			if(v==1)
				errors++;
		}
		else
		{
			vector<Rect> foundLocs;
			hDesc->detectMultiScale(im,foundLocs);
			if(foundLocs.size()==0)
				errors++;
		}
	}
	
	for(int i=trainingNegSamples;i<arrNegFiles.size();i++)
	{
		string fname  = arrNegFiles[i];
		Mat im = imread(fname);
		
		if(usingLIBSVM)
		{
			vector<float> hogFeature;
			hDesc->compute(im,hogFeature);
			struct svm_node* featureNodes = (svm_node *)malloc(sizeof(svm_node)*(hogFeature.size()+1));
			for(int j=0;j<hogFeature.size();j++)
			{
				featureNodes[j].index=j;
				featureNodes[j].value=hogFeature[j];
			}
			featureNodes[hogFeature.size()].index = -1;
			double v = svm_predict(svmModel,featureNodes);
			if(v==0)
				errors++;

		}
		else
		{
			vector<Rect> foundLocs;
			hDesc->detectMultiScale(im,foundLocs);
			if(foundLocs.size()>0)
				errors++;
		}
		
	}
	int allData = arrNegFiles.size()-trainingNegSamples +arrPosFiles.size()-trainingPosSamples;
	accuracy  = (float) (allData-errors)/(allData);
	return accuracy;
}

int SearchDirectory(LPCTSTR pszRootPath, 
                           vector<string>* arrFiles,
                           bool bRecursive)
{
   WIN32_FIND_DATA ffd;
   LARGE_INTEGER filesize;
   TCHAR szDir[MAX_PATH];
   size_t length_of_arg;
   HANDLE hFind = INVALID_HANDLE_VALUE;
   DWORD dwError=0;
   
   // Check that the input path plus 3 is not longer than MAX_PATH.
   // Three characters are for the "\*" plus NULL appended below.
   
   StringCchLength(pszRootPath, MAX_PATH, &length_of_arg);

   if (length_of_arg > (MAX_PATH - 3))
   {
      _tprintf(TEXT("\nDirectory path is too long.\n"));
      return (-1);
   }

   _tprintf(TEXT("\nTarget directory is %s\n\n"), pszRootPath);

   // Prepare string for use with FindFile functions.  First, copy the
   // string to a buffer, then append '\*' to the directory name.

   StringCchCopy(szDir, MAX_PATH, pszRootPath);
   StringCchCat(szDir, MAX_PATH, TEXT("\\*"));

   // Find the first file in the directory.

   hFind = FindFirstFile(szDir, &ffd);

   if (INVALID_HANDLE_VALUE == hFind) 
   {
      cout<<"Error FindFirstFile";;
      return dwError;
   } 
   
   // List all the files in the directory with some info about them.
   do
   {
      if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
      {
         _tprintf(TEXT("  %s   <DIR>\n"), ffd.cFileName);
      }
      else
      {
         filesize.LowPart = ffd.nFileSizeLow;
         filesize.HighPart = ffd.nFileSizeHigh;
         _tprintf(TEXT("  %s   %ld bytes\n"), ffd.cFileName, filesize.QuadPart);
		 std::stringstream sstm;
		 sstm << pszRootPath<<"\\" <<ffd.cFileName;
		 string result = sstm.str();	
		 arrFiles->push_back(result);
		 
		 
      }
	   
   }
   while (FindNextFile(hFind, &ffd) != 0);
 
   dwError = GetLastError();
   if (dwError != ERROR_NO_MORE_FILES) 
   {
      cout<<"Error FindFirstFile";
   }

   FindClose(hFind);
   return dwError;
}

void ImageClassification::GenerateHOGDataset(VideoIOManager* VideoManager, ObjClass obClass, string path)
{
	bool show = false;
	if(show)
		namedWindow("win1",1);

	unsigned int rows, cols;
	double fourcc;
	double fps;
	FrameInfo*  prevFrame =  NULL;
	FrameInfo*  fInfo = VideoManager->GetNextFrame();
	rows = VideoManager->InputStream->pControls->rows;
	cols = VideoManager->InputStream->pControls->cols;
	fourcc = VideoManager->InputStream->fourcc;
	fps = VideoManager->InputStream->fps;
	

	while(fInfo !=NULL)
	{
		cout<<fInfo->_frameNo <<endl;
				
		if(prevFrame!=NULL)
		{
			for(int i = 0;i<fInfo->CorrLocs.size();i++)
			{
				TrackedObject* trObInfo = VideoManager->trackedObjects[fInfo->ObjectIndices[i]];
				TrackingInfo* trInfo= trObInfo->trackingInfo[fInfo->CorrLocs[i]];
				Rect  rect= trInfo->rect;
				
				if(trObInfo->objClass!=0)
				{
					//cv::rectangle(fInfo->Image,rect,cv::Scalar(0,0,0),3);
					//cv::putText(fInfo->Image, ObjClassToString(trObInfo->objClass), cv::Point( rect.x,rect.y ),0,1,cv::Scalar(50,50,50));
					vector<vector<Point>> contours;
					vector<Point> biggestContour;
					
					int totalInsances  = trInfo->parentTrackedObject->NumFrames;
					int interval = totalInsances/10;
					int relIndex = trInfo->frame-trInfo->parentTrackedObject->trackingInfo[0]->frame;
					if((relIndex)%interval==0)
					{
						float DX=0;
						float DY=0;
						
						if(relIndex!=0)
						{
							Rect prevRect = trObInfo->trackingInfo[fInfo->CorrLocs[i]-interval]->rect;
							DX = rect.x+rect.width/2 -prevRect.x -prevRect.width/2;
							DY = rect.x+rect.width/2 -prevRect.y -prevRect.height/2;
						}
						if(relIndex==0|| sqrt(DX*DX+DY*DY)>=5)
						{
							Mat subIm  = GetHOGTrainingImage(fInfo, trInfo, obClass);
							if(subIm.rows>0)
							{
								if(trInfo->parentTrackedObject->objClass == obClass)
								{
									std::stringstream sstm;
									sstm <<path<< "\\Pos\\"<< VideoManager->_VideoName<<ObjClassToString(trInfo->parentTrackedObject->objClass) << fInfo->_frameNo<<"_"<< trInfo->parentTrackedObject->ObjId<<".jpg";
									string result = sstm.str();
									imwrite(result,subIm);
								}
								else
								{
									std::stringstream sstm;
									sstm <<path<<"\\Neg\\"<<VideoManager->_VideoName <<ObjClassToString(trInfo->parentTrackedObject->objClass) << fInfo->_frameNo<<"_"<< trInfo->parentTrackedObject->ObjId<<".jpg";
									string result = sstm.str();		
									imwrite(result,subIm);
								}
							}
							
						}
						
					}

				}
			}
		}
		

		//imshow("win1",MaskFrame);
		if(show)
		{
			//imshow("win1",MaskFrame);
			imshow("win1",fInfo->Image);
			waitKey(5);
		}
		if(prevFrame!= NULL)
			delete prevFrame;
		prevFrame = fInfo;
		fInfo = VideoManager->GetNextFrame();
	}

}


void ImageClassification::AppendFeauresFromVideo(VideoIOManager* VideoManager, ObjClass obClass) 
{
	 
	bool show = false;
	bool enablBG = false;
	if(show)
		namedWindow("win1",1);

	Mat MaskFrame;
	Mat prevMaskFrame;
	unsigned char * FGImage;
	unsigned char * FilteredFGImage;
	unsigned int rows, cols;
	double fourcc;
	double fps;
	FrameInfo*  prevFrame =  NULL;
	FrameInfo*  fInfo = VideoManager->GetNextFrame();
	rows = VideoManager->InputStream->pControls->rows;
	cols = VideoManager->InputStream->pControls->cols;
	fourcc = VideoManager->InputStream->fourcc;
	fps = VideoManager->InputStream->fps;
	
	NPBGSubtractor * pBGModel;
	if(enablBG)
	{
		pBGModel = new NPBGSubtractor; 
		BuildNPBGModel(VideoManager->InputStream,pBGModel,50,100,1,1);
		pBGModel->SetThresholds(10e-15,0.3);
	}

	int colorChannels = (VideoManager->InputStream->pControls->useColor ? 3 : 1);
	int listSize = 10;
	unsigned char ** DisplayBuffers = new unsigned char* [listSize];
	for(int i = 0; i<listSize; i++ ) 
		DisplayBuffers[i] = new unsigned char[rows*cols*colorChannels];

	FGImage = new unsigned char[rows*cols];//*colorChannels];

	FilteredFGImage = new unsigned char[rows*cols];//*colorChannels];
	
	while(fInfo !=NULL)
	{
		cout<<fInfo->_frameNo <<endl;
		
		if(enablBG)
		{
			(pBGModel)->NBBGSubtraction(fInfo->Image.data,FGImage,FilteredFGImage,DisplayBuffers);
			MaskFrame = Mat(rows,cols,CV_8UC1,FilteredFGImage);
		}
		
		/*dEtect All humans in the image
		vector<Rect> found, found_filtered;
		hog.detectMultiScale(fInfo->Image, found, 0, Size(8,8), Size(32,32), 1.05, 2);
	 
	    size_t i, j;
	    for( i = 0; i < found.size(); i++ )
	    {
		    Rect r = found[i];
		    for( j = 0; j < found.size(); j++ )
			    if( j != i && (r & found[j]) == r)
				    break;
		    if( j == found.size() )
			    found_filtered.push_back(r);
	    }
	    for( i = 0; i < found_filtered.size(); i++ )
	    {
		    Rect r = found_filtered[i];
		    // the HOG detector returns slightly larger rectangles than the real objects.
		    // so we slightly shrink the rectangles to get a nicer output.
		    r.x += cvRound(r.width*0.1);
		    r.width = cvRound(r.width*0.8);
		    r.y += cvRound(r.height*0.07);
		    r.height = cvRound(r.height*0.8);
		    rectangle(fInfo->Image, r.tl(), r.br(), cv::Scalar(0,255,0), 3);
	    }
	    imshow("people detector", fInfo->Image);
		waitKey(50);*/
		if(prevFrame!=NULL)
		{
			for(int i = 0;i<fInfo->CorrLocs.size();i++)
			{
				TrackedObject* trObInfo = VideoManager->trackedObjects[fInfo->ObjectIndices[i]];
				TrackingInfo* trInfo= trObInfo->trackingInfo[fInfo->CorrLocs[i]];
				Rect  rect= trInfo->rect;
				
				if(trObInfo->objClass!=0)
				{
					//cv::rectangle(fInfo->Image,rect,cv::Scalar(0,0,0),3);
					//cv::putText(fInfo->Image, ObjClassToString(trObInfo->objClass), cv::Point( rect.x,rect.y ),0,1,cv::Scalar(50,50,50));
					vector<vector<Point>> contours;
					vector<Point> biggestContour;
					if(enablBG)
					{
						Mat newF = MaskFrame(rect);

						
			
						findContours( newF,  contours, (int)CV_RETR_CCOMP, (int)CV_CHAIN_APPROX_SIMPLE,Point(rect.x,rect.y) );
			
						
						int bigst = -1;
						double carea  = -1;
						for(int i=0;i<contours.size();i++)
						{
						
							double area0 = contourArea(contours[i]);
							if(area0>carea)
							{
								carea = area0;
								bigst = i;

							}
							//drawContours(MaskFrame,contours,i, cv::Scalar(128,128,128),1);
						}
					
					


						if(bigst!=-1)
						{
							biggestContour = contours[bigst];
							if(show)
							{
								drawContours(MaskFrame,contours,bigst, cv::Scalar(255,255,255),CV_FILLED);
								drawContours(fInfo->Image,contours,bigst, cv::Scalar(0,0,0),1);
							}
						}

					}
					if(show)
					{
						
						/*string objwinName = "obj"+i + fInfo->_frameNo;
						imshow(objwinName, subIm);
						waitKey(1000);
						destroyWindow(objwinName);*/
						
							/*vector<float> desc;
							hog.compute(subIm, desc);
							vector<Rect> found;
							hog.detectMultiScale(subIm,found,0,Size(8,8));
	 
							if(found.size()>=1)
								cv::rectangle(fInfo->Image,rect,cv::Scalar(0,0,0),3);*/
						
						
					}


					//if(carea>rect.area()/2)
					//{
					//	// ADI is not available so far
					//	Mat ADI;
					//	LearnObjectFrame(fInfo, prevFrame, MaskFrame, prevMaskFrame, ADI ,trInfo, contours[biggest]);
					//}
					
					int totalInsances  = trInfo->parentTrackedObject->NumFrames;
					int interval = totalInsances/10;
					int relIndex = trInfo->frame-trInfo->parentTrackedObject->trackingInfo[0]->frame;
					if((relIndex)%interval==0)
					{
						float DX=0;
						float DY=0;
						
						if(relIndex!=0)
						{
							Rect prevRect = trObInfo->trackingInfo[fInfo->CorrLocs[i]-interval]->rect;
							DX = rect.x+rect.width/2 -prevRect.x -prevRect.width/2;
							DY = rect.x+rect.width/2 -prevRect.y -prevRect.height/2;
						}
						if(relIndex==0|| sqrt(DX*DX+DY*DY)>=5)
						{
							Mat ADI;
							Features* ftrs = ExtractObjectFeatureForLearning(fInfo, prevFrame, MaskFrame, prevMaskFrame, ADI ,trInfo, biggestContour,obClass);
							AddToTrainingData(trInfo->parentTrackedObject->objClass,ftrs);
						}
						
						if(enablBG)
							contours.clear();
					}

					//cv::rectangle(MaskFrame,rect,cv::Scalar(255,255,255),3);
					//cv::putText(MaskFrame, ObjClassToString(trObInfo->objClass), cv::Point( rect.x,rect.y ),0,1,cv::Scalar(255,255,255));
					
				}
			}
		}
		

		//imshow("win1",MaskFrame);
		if(show)
		{
			//imshow("win1",MaskFrame);
			imshow("win1",fInfo->Image);
			waitKey(5);
		}
		if(prevFrame!= NULL)
			delete prevFrame;
		prevFrame = fInfo;
		prevMaskFrame = MaskFrame;
		fInfo = VideoManager->GetNextFrame();
	}

	
	
}

double ExtractLumninanceSymmetry(FrameInfo* currFrame,Mat currImGray, Mat MaskFrame, RotatedRect rotRect)
{
	/*namedWindow("testill",1);
	imshow("testill",currImGray);
	waitKey(1000);*/

	Rect rect = rotRect.boundingRect();
	Mat imObj = currImGray(rect);
	Mat MaskObj = MaskFrame(rect);
	
	/*imshow("testill",imObj);
	waitKey(1000);
	imshow("testill",MaskObj);
	waitKey(1000);*/

	Mat mulIm ;

	multiply(imObj,MaskObj,mulIm,1.0/255);
	
	imshow("testill",mulIm);
	waitKey(1000);

	Mat rotIm;
	int totangle=-1;
	if(rotRect.angle>=0 &&rotRect.angle<=90)
		totangle = rotRect.angle;
	else if(rotRect.angle>90 &&rotRect.angle<=180)
		totangle = 180-rotRect.angle;
	else if(rotRect.angle>=180 &&rotRect.angle<=270)
		totangle = rotRect.angle-180;
	else
		totangle = 360-rotRect.angle;
	/*Point2f roRectPts[4];
	rotRect.points(roRectPts);

	Point2f tran = Point2f(rotRect.size.width/2-rotRect.center.x,rotRect.size.height/2-rotRect.center.y);
	Point2f src [3]= {roRectPts[0],roRectPts[1],roRectPts[2]};
	Point2f dst [3]= {roRectPts[0]+tran,roRectPts[1]+tran,roRectPts[2]+tran};*/
	Point rotRectRelCen ( rotRect.center.x -rect.x, rotRect.center.y-rect.y);
	
	warpAffine(mulIm,rotIm,getRotationMatrix2D(rotRectRelCen,360-totangle,1) ,mulIm.size());
	Mat rotIm2 = rotIm(Rect(rotRectRelCen.x-rotRect.size.width/2,rotRectRelCen.y-rotRect.size.height/2,rotRect.size.width,rotRect.size.height));
	/*imshow("testill",rotIm2);
	waitKey(1000);*/
	

	

	Mat halfim1 = rotIm(Rect(0,0,rotRect.size.width/2,rotRect.size.height ));
	Mat halfim2 = rotIm(Rect(rotRect.size.width/2,0,rotRect.size.width/2,rotRect.size.height));
    
	imshow("testill",halfim1);
	waitKey(1000);
	imshow("testill2",halfim2);
	waitKey(1000);
	Mat reduce1;
	cv::reduce(halfim1,reduce1,1,CV_REDUCE_AVG);
	Mat reduce2 (halfim2.rows,1,halfim2.type()) ;;
	cv::reduce(halfim2,reduce2,1,CV_REDUCE_AVG);
	Mat sub;
	subtract(reduce1, reduce2,sub);
	Mat squared;
	multiply(sub,sub,squared,rotRect.size.height/4);
	Scalar sumim = sum(squared);
	double val = sumim.val[0];
	double C = 100;
	return sqrt(val)*2/(C*rotRect.size.width);
}

Mat ImageClassification::GetHOGTrainingImage(FrameInfo* currFrame, TrackingInfo* trInfo , ObjClass obClass)
{
	HOGDescriptor* HogDesc = HogDescMap[obClass];
	
	int rx = max(0, trInfo->rect.x);
	int ry = max(0, trInfo->rect.y);
	Rect objRect = Rect(rx,ry,min(trInfo->rect.x+ trInfo->rect.width,currFrame->Image.cols-1)-rx  ,min(trInfo->rect.y+trInfo->rect.height,currFrame->Image.rows-1)-ry);
	
	if(objRect.width<=0 || objRect.height<=0)
	{
		return Mat();
	}
	Mat tmpim =currFrame->Image(objRect);
	float scaleX = (float)HogDesc->winSize.width/objRect.width;
	float scaleY = (float)HogDesc->winSize.height/objRect.height;
	Mat tmpIm2;
	float scale = max(scaleX, scaleY);

	Size dsize = Size((int)ceil(scale*tmpim.cols),(int) ceil(scale*tmpim.rows));
	resize(tmpim,tmpIm2,dsize);
	
	int cenX = tmpIm2.cols/2;
	int cenY = tmpIm2.rows/2;

	Mat subIm = tmpIm2(Rect(cenX-HogDesc->winSize.width/2, cenY-HogDesc->winSize.height/2,HogDesc->winSize.width,HogDesc->winSize.height));
	return subIm;
}
Features* ImageClassification::ExtractObjectFeatureForLearning(FrameInfo* currFrame, FrameInfo* prevFrame, Mat MaskFrame,Mat prevMaskFrame, Mat ADI, TrackingInfo* trInfo, vector<Point> contour, ObjClass obClass)
{
	Features* ftrs = new Features();
	// 0: Hog Features.
	HOGDescriptor* HogDesc = HogDescMap[obClass];
	Mat subIm =GetHOGTrainingImage(currFrame, trInfo, obClass); 
	
	if(trInfo->parentTrackedObject->objClass == obClass)
	{
		std::stringstream sstm;
		sstm << "F:\\Mohamed ELhoseiny\\Research\\Activity Recognition\\HOG training\\Human\\Pos\\"<< ObjClassToString(trInfo->parentTrackedObject->objClass) << currFrame->_frameNo<<"_"<< trInfo->parentTrackedObject->ObjId<<".jpg";
		string result = sstm.str();


		
		imwrite(result,subIm);
	}
	else
	{
		std::stringstream sstm;
		sstm << "F:\\Mohamed ELhoseiny\\Research\\Activity Recognition\\HOG training\\Human\\Neg\\"<< ObjClassToString(trInfo->parentTrackedObject->objClass) << currFrame->_frameNo<<"_"<< trInfo->parentTrackedObject->ObjId<<".jpg";
		string result = sstm.str();		
		imwrite(result,subIm);
	}

	vector<float> HogFeatures;
	
	//HogDesc->winSize = Size((subIm.cols/8)*8-1,(subIm.rows/8)*8-1);
	cout<<"FeatureSize = "<<HogDesc->getDescriptorSize()<<endl;
	ftrs->HOG = HogFeatures ;

	return ftrs;
	
	Mat imGray;
	MaskFrame.copySize(imGray) ;
	//currFrame->Image.convertTo(imGray,MaskFrame.type()) ;
	cvtColor(currFrame->Image, imGray, CV_RGB2GRAY);
	Mat ob1 = imGray(trInfo->rect);
	Mat ob2 = MaskFrame(trInfo->rect);
	Mat SObj ;
	multiply(ob1, ob2,SObj, 1.0/255); //Mat SObj =  ob1.mul(ob2,1.0/255);
	Mat SObjRsz ;
	resize(SObj, SObjRsz, Size(30,30));
	Mat Brsz;
	Mat MaskObj = MaskFrame(trInfo->rect);
	resize(MaskObj, Brsz, Size(30,30));

	//A : Lumninance Features
	//----------------------------------------
	RotatedRect rotRect =  fitEllipse(contour);
	
	
	
	ftrs->LumninanceSymmetry = ExtractLumninanceSymmetry(currFrame,imGray, MaskFrame, rotRect);
	

	//B: Smoothed DCT features (not complete)
	//----------------------------------------

	/*

	Mat ADIObj = ADI(trInfo->rect);
	//size_t sz;
	Mat ADIObjrsz;
	resize(ADIObj, ADIObjrsz, Size(30,30));
	//ADIObj.resize(s);
	Mat ADIObjDCT(ADIObjrsz) ;  
	dct(ADIObjrsz,ADIObjDCT);

	ftrs->Dct =  ADIObjDCT;*/

	//C: 2D moments
	//----------------------------------------
	ftrs->momentFtrs.moms = moments(MaskObj, true);
	HuMoments(ftrs->momentFtrs.moms ,ftrs->momentFtrs.h);
	
	ART* art = new ART();
	art->transform(SObj);
	
	ftrs->momentFtrs.ArtFeatures = art;


	//D: Symmetric organs fluctuation (not complete)
	//----------------------------------------
	Mat BPrevrsz;
	TrackingInfo* prevTrInfo = trInfo->parentTrackedObject->trackingInfo[trInfo->parentTrackedObject->CurrentLoc()-1];
	Mat MaskPrevObj = prevMaskFrame(prevTrInfo->rect);
	resize(MaskPrevObj, BPrevrsz, Size(30,30));
	Mat Z;
	cv::bitwise_xor(BPrevrsz, Brsz,Z);
	int blocksize = 5;
	Mat Zblks;
	resize(Z,Zblks,Size(30.0/blocksize, 30.0/blocksize),0,0,CV_INTER_LINEAR);
	threshold(Zblks, Zblks,128,255,THRESH_BINARY);




	//E: Commulants
	//----------------------------------------

	
	
	ftrs->cumulants.MeanIntensity= mean(SObjRsz)[0];
	 MatND hist;
	 int channels[] = {0};
	 float hrange[] = {0,255};
	 const float* ranges[] =  {hrange};
	 int histSize[] = {256};
	 calcHist(&SObj,1, channels,Mat(),hist, 1, histSize, ranges, true, false);
	 Scalar mn,stdev;

	meanStdDev(hist, mn, stdev);



	ftrs->cumulants.StdDevIntensity=stdev[0];

	/* calc skewness */
	double mean  = ftrs->cumulants.MeanIntensity;
	double skewness = 0;

	for(int i=0;i <256;i++)
	{
		skewness += hist.data[i]*pow((i-mean),3);
	}

	skewness/= pow(ftrs->cumulants.StdDevIntensity,3);

	ftrs->cumulants.Intensityskewness=skewness;

	//F: Horizontal and Vertical Projection
	//----------------------------------------

	Mat HorzProj;
	reduce(Brsz,HorzProj,1,CV_REDUCE_SUM);
	Mat VertProj;
	reduce(Brsz,VertProj,0,CV_REDUCE_SUM);
	ftrs->VertProj = VertProj;
	ftrs->HorzProj = HorzProj;

	//G: Morphological Features
	//----------------------------------------
	MorphologicalFeature mf;
	double contourPerimeter = arcLength(contour,true);
	double cArea = contourArea(contour);
	mf.Anthroopometry = rotRect.size.height/contourPerimeter;
	mf.compactness = cArea/(contourPerimeter*contourPerimeter);
	mf.aspectRatio = rotRect.size.width/rotRect.size.height;
	
	/*calculate COnvex Hull Area*/
	vector<Point> ch;
	cv::convexHull(contour,ch,false);
	double area = 0;
	for (int i = 0; i < ch.size(); i++){
		int next_i = (i+1)%(ch.size());
		double dX   = ch[next_i].x - ch[i].x;
		double avgY = (ch[next_i].y + ch[i].y)/2;
		area += dX*avgY;  // This is the integration step.
	}

	mf.solidity = cArea/area;

	//reduce(currFrame->Image, 
	


	
  

}
