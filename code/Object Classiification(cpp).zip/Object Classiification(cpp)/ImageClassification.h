
#include "NPBGBuild.h"
#include <sstream>
#include "ImageProcessing.h"
#include "ImageDisplay.h"
#include "ViratDSIOManager.h"
#include "ART.h"
#include "svm.h"
#include <tchar.h> 
#include <stdio.h>
#include <strsafe.h>
#include <windows.h>

#pragma comment(lib, "User32.lib")
using namespace std;
#pragma once
enum ObjClass
{
	None =0,
	person =1,
	car = 2,
	vehicles =3,
	object = 4,
    bike =5 // or bikes
	
};

int SearchDirectory(LPCTSTR pszRootPath, 
                           vector<string>* arrFiles,
                           bool bRecursive = true);

void loadLinSVMfromModelFile(const char* filename, vector<float>* svm);
vector<float>* loadLinSVMfromModel(svm_model* libLinSVMModel);

class MomentFeatures
{
public:
	//Moments
	Moments moms;
	//Hu moments
	double h[7];


	ART* ArtFeatures;
	double Zernikemoments;

};

class Cumulants
{
public:
	double StdDevIntensity;
	double MeanIntensity;
	double Intensityskewness;
};

class MorphologicalFeature
{
public:
	// height/ perimeter;
	double Anthroopometry;

	// area/ square perimeter
	double compactness;

	// width/ height
	double aspectRatio;

	// area/ convexHullarea
	double solidity; 
};

//SceneDependentFeatures
class SceneFeatures
{
	double height;
};


class Features
{
public:
	float LumninanceSymmetry;
	cv::Mat Dct;
	MomentFeatures momentFtrs;
	double symmetricFlunctations;

	MorphologicalFeature morphFeatures;
	
	SceneFeatures SDT;

	Mat HorzProj;
	Mat VertProj;

	Cumulants cumulants;
	vector<float> HOG;
};

class ImageClassification
{
private: 
	svm_model *svmModel;
	
	std::map<ObjClass,HOGDescriptor*> HogDescMap;
	void LoadLearnedData();
	void AddToTrainingData(ObjClass obClass, Features* ftrs);
	
public:
	vector<Features*> HumanFeatures;
	vector<Features*> CarFeatures;
	vector<Features*> VehicleFeatures;
	vector<Features*> ObjectFeatures;
	vector<Features*> BikeFeatures;
	vector<Features*> GroupOfHumanFeatures;

	void GenerateObjectsDataSet(ViratDSIOManager* viratDataset);
	void ImageClassification::LearnFromLoadedFeatureVectors();
	ImageClassification(void);
	~ImageClassification(void);
	//Learn from learning data that has been loaded using AccumulateLearningData.
	Features* ExtractObjectFeatureForLearning(FrameInfo* currFrame, FrameInfo* prevFrame, Mat MaskFrame,Mat prevMaskFrame, Mat ADI, TrackingInfo* trInfo, vector<Point> contour, ObjClass obClass);
	void Learn();
	
	vector<ObjClass> Classify(Mat currFrame, Mat MaskFrame, vector<Rect> objects) ;
	ObjClass Classify(Mat currFrame, Mat MaskFrame, Rect object) ;
	void AppendFeauresFromVideo(VideoIOManager* VideoManager, ObjClass obClass) ;

	void GenerateHOGDataset(VideoIOManager* VideoManager, ObjClass obClass, string path);

	// This function generates classifier from a folder contain Pos and Neg folders
	void HOGTrainFromClassDSFolder(ObjClass obClass, string DatasetPath, float traininggRatio);
	float HOGTestFromClassDSFolder( svm_model *svmModel, ObjClass obClass,  string DatasetPath, float traininggRatio);
	Mat GetHOGTrainingImage(FrameInfo* currFrame,TrackingInfo* trInfo ,ObjClass obClass);

	//void TrainFromDataset(ObjClass obClass, string path);
	
	
};

std::string ObjClassToString(ObjClass objectClass);

