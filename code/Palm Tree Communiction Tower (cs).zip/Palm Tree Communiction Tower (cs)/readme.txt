

This is a project that I have built completly alone in about 3-4 days for a problem faced HOI (House of invention corporation) in a deadline that was about one week after. Thankfully, I ,as an R&D engineer at that time, managed to build this tool that take specs of a telecomunication palm tree, render it, dalculate wind shieldings and Visualize the result (Red No shielding, Green means totally shielded).

UI and Geometry Generation
-------------------------
PalmTreeShieldingDataDlg.cs: The main dialog (The main functions the processes the inputs and generates the geometry  are  
AddLeafs() :- Add the leafs according the specs of the users.
AddAntennaAndPipes() :- Add antennas and pipes according to the specs by the user.


Rendering
--------------
RenderingModule: I was used to make a Graphics Engine, in which each entity to be rendered is called an entity and the controllder would manager the drawing of elements. Each entity to be drawn, should inherit from Entity and override the Draw function (e.g. GlBoundedPolyHedron.cs), so that the module is extensible .

The Graphics engine is subject to copyright so that I can't expose the code, just let me know we you would like me to the details.

In summary, the Graphics Engine is a generic controller that can render any entity given it implements the Draw function (it may have multple Draw functions is the entity looks different depending on the mode of the system). for depth check and camera views. The user have to define approximate surrouning 3d points or bounding box. This is to have generall support of camera operations like
a) Zoom fit.
b) YZ, XY, XZ View.
c) Iso View.


Analysis
-------------
This model do projection of the elements in the direction of the wind to determine the intersection and the amount of shielding in an interal fom

ShieldingModule: (GeneralizedShieldingProcess.cs) calculate the shielding (modeled by an integral) by numerically integrating elements of the polyhedron surrounding each 3d element (e.g. Antenna , pipe, leaf). The numerical step is defined by the user.

Some intersting functionalities has been done here e.g.
1) Plane.cs: TracePlane(Plane plane, Vector3 point, Vector3 direction): given a starting point and direction, the projection distance is retuned to that plane.
2) BoundingPolygon.cs: TracePlane(ConvexBoundedPlane plane, Vector3 point, Vector3 direction), do the same functiom on 3D polygon (i.e. polyherdron) with some specs (i.e. have a base plane and top plane and they are parallel and with equal number of sides.)
3) BoundingPolygon.cs:: GetFacingPlanes(Vector3 direction) rturn the facing planes in given 3D direction 


If you are interested in more details please let me know
