﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace MainProgram
{
    public class ColorInterPolator
    {
        List<Color> _colors;
        public ColorInterPolator(List<Color> colors)
        {
            _colors = colors;
        }

        public Color GetInterpolatedColor(double t)
        {
            if(t>=1)
                return _colors[_colors.Count-1];

            double tval = t *(_colors.Count-1);
            
            int i = (int)tval;
            tval -= i;
            Color clr1 = _colors[i];
            Color clr2 = _colors[i+1];


            return Color.FromArgb(
                (int)((1-tval) * clr1.R + ( tval) * clr2.R),
                (int)((1 - tval) * clr1.G + (tval) * clr2.G),
                (int)((1 - tval) * clr1.B + (tval) * clr2.B)
                );


             


        }
        
    }
}
