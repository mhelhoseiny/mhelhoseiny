﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using SMath = System.Math;
using Mapack;
using SoftoriaPole.Geometry;


namespace MainProgram
{
  

    public class VectorOperations
    {
        public static Vector3 FromLocalToGlobal(Vector3 position, Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            return position.X * localX + position.Y * localY + position.Z * localZ;
        }

        public static Vector3 FromGlobalToLocal(Vector3 position, Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            return new Vector3(localX | position, localY | position, localZ | position);

        }
        public static SoftoriaPole.Math.Vector3 CopyVector(SoftoriaPole.Math.Vector3 v)
        {
            return new SoftoriaPole.Math.Vector3(v.X, v.Y, v.Z);
        }
        public static SoftoriaPole.Math.Vector3 RotateAboutZ(SoftoriaPole.Math.Vector3 v, double theta)
        {
            Vector3 v1 = new Vector3();
            v1.Z = v.Z;
            v1.X = v.X * Math.Cos(theta) - v.Y * Math.Sin(theta);
            v1.Y = v.X * Math.Sin(theta) + v.Y * Math.Cos(theta);
            return v1;
        }
        public static Vector3 GetUnitVector(Vector3 vector)
        {
            Vector3 v = new Vector3(vector.X, vector.Y, vector.Z);

            double val = 1/Math.Sqrt(vector.X*vector.X+vector.Y*vector.Y+vector.Z*vector.Z);
            v*=val;
            return v;


        }
        public static SoftoriaPole.Math.Vector3 Crossproduct(SoftoriaPole.Math.Vector3 v1, SoftoriaPole.Math.Vector3 v2)
        {
            SoftoriaPole.Math.Vector3 v = new SoftoriaPole.Math.Vector3();
            v.X = v1.Y * v2.Z - v2.Y * v1.Z;
            v.Y = -(v1.X * v2.Z - v2.X * v1.Z);
            v.Z = v1.X * v2.Y - v2.X * v1.Y;
            return v;
        }
        public static double getangle(SoftoriaPole.Math.Vector3 v1, SoftoriaPole.Math.Vector3 v2, SoftoriaPole.Math.Vector3 n)
        {
            double val = (v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z) / (v1.Magnitude * v2.Magnitude);

            double angle = Math.Acos(val) *180 / Math.PI;
            return angle;
            SoftoriaPole.Math.Vector3 vtmp;
            if (angle < Math.PI / 2)
            {
                vtmp = Rotate(v1, n, -Math.PI / 2);
            }
            else
            {
                vtmp = Rotate(v1, n, Math.PI / 2);
            }

            double angle2 = (vtmp.X * v2.X + vtmp.Y * v2.Y + vtmp.Z * v2.Z) / (vtmp.Magnitude * v2.Magnitude);

            if (angle > Math.PI / 2 && angle2 > Math.PI / 2)
            {
                //3rd quarter
                return 2 * Math.PI - angle;
            }
            else if (angle > Math.PI / 2 && angle2 <= Math.PI / 2)
            {
                //2nd quarter
                return angle;

            }
            else if (angle <= Math.PI / 2 && angle2 <= Math.PI / 2)
            {
                //1st quarter
                return -angle;
            }
            else if (angle <= Math.PI / 2 && angle2 > Math.PI / 2)
            {
                //4th quarter
                return angle;

            }

            return angle;

        }
        public static double getangle(SoftoriaPole.Math.Vector3 v1, SoftoriaPole.Math.Vector3 v2)
        {

            SoftoriaPole.Math.Vector3 norm = Crossproduct(v1, v2);
            norm.Normalize();
            return getangle(v1, v2, norm);
        }
        public static SoftoriaPole.Math.Vector3 InterpolatePoints(SoftoriaPole.Math.Vector3 pt1, SoftoriaPole.Math.Vector3 pt2, double alpha)
        {
            SoftoriaPole.Math.Vector3 retpt = pt2 - pt1;
            retpt = pt1 + alpha * retpt;

            return retpt;
        }

        public static double Dotproduct(SoftoriaPole.Math.Vector3 v1, SoftoriaPole.Math.Vector3 v2)
        {
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z;
        }
        public static SoftoriaPole.Math.Vector3 Mulvector(SoftoriaPole.Math.Vector3 v, double s)
        {
            return new SoftoriaPole.Math.Vector3(v.X * s, v.Y * s, v.Z * s);
        }
        public static SoftoriaPole.Math.Vector3 Rotate2(SoftoriaPole.Math.Vector3 v, SoftoriaPole.Math.Vector3 n, double angle)
        {
            if (angle == 0)
                return v.Clone();
            // cos @ ( v - ( v dot n ) n ) + sin @( n cross v) + (v dot n)n;
            SoftoriaPole.Math.Vector3 vtmp = Math.Cos(angle) * (v - Mulvector(n, Dotproduct(v, n))) +
                Math.Sin(angle) * (Crossproduct(v, n) - Mulvector(n, Dotproduct(v, n)));
            if (vtmp.X != 0 || vtmp.Y != 0 || vtmp.Z != 0)
                return vtmp;
            return v.Clone();
        }

        public static Vector3 Rotate(Vector3 v,Vector3 n,double angle)
        {

            double c = Math.Cos(-angle);
            double s = Math.Sin(-angle);
            double t = 1 - c;

            Vector3 Rv = new Vector3();
            Rv.X = v.X * (t * n.X * n.X + c) + v.Y * (t * n.X * n.Y + s * n.Z) + v.Z * (t * n.X * n.Z - s * n.Y) + 0 * 1;
            Rv.Y = v.X * (t* n.X * n.Y-s*n.Z) + v.Y * (t*n.Y * n.Y  + c) + v.Z * (t* n.Y * n.Z + s*n.X) + 0 * 1; ;
            Rv.Z = v.X * (t * n.X * n.Y + s * n.Y) + v.Y * (t * n.Y * n.Z - s * n.X) + v.Z * (t * n.Z * n.Z + c) + 0 * 1;
            return Rv;
        }
        /// <summary>
        /// Computes and returns the three coordinate vectors of the three frame directions
        /// of the specified segment with the specified chi.
        /// </summary>
        /// <param name="segment"></param>
        /// <param name="chi"></param>
        /// <returns>
        /// retval[0], retval[1], retval[2] are the coordinate vectors of the
        /// directions i, j, k, respectively.
        /// </returns>
        public static double[][] ComputeFrame(Vector3 normal, double chi)
        {
            return Stiffness.StiffnessSolver.ComputeFrame(
                new Stiffness.Math.Vector3(normal.X, normal.Y, normal.Z),
                chi);               
            //Vector3 unitVec = normal;
            ////direction cosines. i.e., unit direction vector
            //unitVec.Normalize();
        //        Vector3 v, n;
        //        Vector3 k = new Vector3(0, 0, 1);
        //        v = k ^ unitVec;
        //        if (v.Magnitude < 1e-6)
        //        {
        //            //unitVec is along the z-axis
        //            v = new Vector3(1, 0, 0);//new Vector3(0, 1, 0);
        //            n = unitVec ^ v;
        //        }
        //        else
        //        {
        //            //v is horizontal such that it reverts if u reverts its direction
        //            v.Normalize();
        //            n = unitVec ^ v;
        //        }
        //      Matrix Rt = new Matrix(new double[][] {
        //          new double[]{unitVec.X, unitVec.Y, unitVec.Z},
        //            new double[]{v.X, v.Y, v.Z},
        //          new double[]{n.X, n.Y, n.Z}});
        //      //[u v n]_chi = [u v n]_0 * Rx(chi) 
        //      Matrix final = Rt.Transpose() * GeoMath.RotationXMatrix(chi);
        //      return final.Transpose().Data;
				//double l, m, n;
				//l = unitVec.X;
				//m = unitVec.Y;
				//n = unitVec.Z;
				//double D = SMath.Sqrt(l * l + n * n);
				//double[][] arr2d;
				//double c = SMath.Cos(chi);
				//double s = SMath.Sin(chi);
				//if (D < 1e-6)
				//    arr2d = new double[][]{
				//   new double[]{0,     m,   0},
				//   new double[]{-c,    0,   m*s},
				//   new double[]{s,		0,	  m*c}};
				//else
				//    arr2d = new double[][] {
				//   new double[]{l,						m,					n},
				//   new double[]{(-l*m*c-n*s)/D,		D*c,   (-m*n*c+l*s)/D},
				//   new double[]{(l*m*s-n*c)/D,		-D*s,  (m*n*s+l*c)/D}};

				//return arr2d;
        }
    }
}
