﻿using System;
using System.Collections.Generic;
using System.Text;
using GLEngine.Labels;
using OpenGL;

namespace MainProgram
{

    public class LeaderAndText1 : TextOnly
    {
        // Fields
        private float x;
        private float y;
        protected int yDistance;
        private float z;

        // Methods
        public LeaderAndText1(float x, float y, float z, string text, int yDistance)
            : base(text)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            base.text = text;
            this.yDistance = yDistance;
        }

        public override void Draw(float layer, float positionScale)
        {
            base.Draw(0, this.yDistance, positionScale);
            gl.LineWidth(1f / positionScale);
            gl.Begin(1);
            gl.Vertex3f(base.xPos * positionScale, (base.yPos * positionScale) + 5f, layer);
            gl.Vertex3f(base.xPos * positionScale, ((base.yPos * positionScale) + this.yDistance) - 5f, layer);
            gl.End();
        }

        public void UpdatePos()
        {
            float num;
            float num2;
            float num3;
            TextOnly.Project((double)this.x, (double)this.y, (double)this.z, out num, out num2, out num3);
            base.xPos = (int)num;
            base.yPos = (int)num2;
        }
    }

}