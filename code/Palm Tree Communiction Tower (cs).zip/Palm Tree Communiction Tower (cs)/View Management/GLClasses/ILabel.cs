﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;

namespace MainProgram.ViewManagement
{
    public interface ILabeled
    {
        Vector3 GetLabelPosition();
    }
}
