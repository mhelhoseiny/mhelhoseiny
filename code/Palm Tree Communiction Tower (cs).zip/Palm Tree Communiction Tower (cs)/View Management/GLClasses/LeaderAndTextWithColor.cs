﻿using System;
using System.Collections.Generic;
using System.Text;
using GLEngine.Labels;
using System.Drawing;
using OpenGL;
using SoftoriaPole.Math;
using SoftoriaPole.Geometry;

namespace MainProgram.ViewManagement
{
    class LeaderAndTextWithColor:LeaderAndText
    {
        private Color _color;
        private ILabeled _labeledObject;
  
       
        public LeaderAndTextWithColor(float x, float y, float z, string text, Color color, int yDistance,ILabeled labeledObject)
            : base(x, y, z, text, yDistance)
        {
            _color = color;
            _labeledObject = labeledObject;
         

        }
        public LeaderAndTextWithColor(float x,float y,float z,string text,Color color,int yDistance):base(x,y,z,text,yDistance)
        {
            _color = color;
           
        }
        public override void Draw(float layer, float positionScale)
        {
            gl.Color3ub(_color.R, _color.G, _color.B);
            base.Draw(layer, positionScale);
            //if (_labeledObject != null)
            //{
               

            //    Draw(0, yDistance, positionScale);

            //    gl.LineWidth(1.0f / positionScale);

            //    gl.Begin(gl.LINES);

            //    gl.Vertex3f(xPos * positionScale, yPos * positionScale + 5, layer);
            //    gl.Vertex3f(xPos * positionScale, yPos * positionScale + yDistance - 5, layer);

            //    gl.End();
            //    //this = new LeaderAndTextWithColor(x, y, z, text, _color, yDistance);
            //    //UpdatePos(x,y,z);
            //}
            //else
            //{
            //    base.Draw(layer, positionScale);
            //}
        }
        public override void UpdatePos()
        {
            if (_labeledObject != null)
            {
                Vector3 pos = _labeledObject.GetLabelPosition();
                x = (float)pos.X;
                y = (float)pos.Y;
                z = (float)pos.Z;
 
            }

            float winX, winY, winZ;

            Project(x, y, z, out winX, out winY, out winZ);

            xPos = (int)winX;
            yPos = (int)winY;

        }
    }
}
