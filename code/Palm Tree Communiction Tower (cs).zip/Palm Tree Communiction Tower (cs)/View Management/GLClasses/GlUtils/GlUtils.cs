﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using SoftoriaPole.Geometry;
using OpenGL;
using System.Drawing;

namespace MainProgram.View_Management.Glu
{
    internal partial class GlUtils
    {
        const double l = 0.5;
        public static void DrawCube(double xw, double yw, double zw)
        {
            DrawCube(xw, yw, zw, true);
        }
        public static void DrawCube(double xw,double yw,double zw,bool showZSides)
        {
            gl.PushMatrix();
            gl.Scaled(xw , yw , zw);
            
            gl.Begin(gl.QUADS);		// Draw The Cube Using quads
            //glColor3f(0.0f, l, 0.0f);	// Color Blue
            gl.Vertex3d(l, l, -l);	// Top Right Of The Quad (Top)
            gl.Vertex3d(-l, l, -l);	// Top Left Of The Quad (Top)
            gl.Vertex3d(-l, l, l);	// Bottom Left Of The Quad (Top)
            gl.Vertex3d(l, l, l);	// Bottom Right Of The Quad (Top)

            //glColor3f(l, 0.5f, 0.0f);	// Color Orange
            gl.Vertex3d(l, -l, l);	// Top Right Of The Quad (Bottom)
            gl.Vertex3d(-l, -l, l);	// Top Left Of The Quad (Bottom)
            gl.Vertex3d(-l, -l, -l);	// Bottom Left Of The Quad (Bottom)
            gl.Vertex3d(l, -l, -l);	// Bottom Right Of The Quad (Bottom)

            //glColor3f(1.0f, 0.0f, 0.0f);	// Color Red	
            if (showZSides)
            {
                gl.Vertex3d(l, l, l);	// Top Right Of The Quad (Front)
                gl.Vertex3d(-l, l, l);	// Top Left Of The Quad (Front)
                gl.Vertex3d(-l, -l, l);	// Bottom Left Of The Quad (Front)
                gl.Vertex3d(l, -l, l);	// Bottom Right Of The Quad (Front)
            }
            //glColor3f(l, l, 0.0f);	// Color Yellow
            if (showZSides)
            {
                gl.Vertex3d(l, -l, -l);	// Top Right Of The Quad (Back)
                gl.Vertex3d(-l, -l, -l);	// Top Left Of The Quad (Back)
                gl.Vertex3d(-l, l, -l);	// Bottom Left Of The Quad (Back)
                gl.Vertex3d(l, l, -l);	// Bottom Right Of The Quad (Back)
            }
            //glColor3f(0.0f, 0.0f, l);	// Color Blue
            gl.Vertex3d(-l, l, l);	// Top Right Of The Quad (Left)
            gl.Vertex3d(-l, l, -l);	// Top Left Of The Quad (Left)
            gl.Vertex3d(-l, -l, -l);	// Bottom Left Of The Quad (Left)
            gl.Vertex3d(-l, -l, l);	// Bottom Right Of The Quad (Left)

            //glColor3f(l, 0.0f, l);	// Color Violet
            gl.Vertex3d(l, l, -l);	// Top Right Of The Quad (Right)
            gl.Vertex3d(l, l, l);	// Top Left Of The Quad (Right)
            gl.Vertex3d(l, -l, l);	// Bottom Left Of The Quad (Right)
            gl.Vertex3d(l, -l, -l);	// Bottom Right Of The Quad (Right)
            gl.End();
            gl.PopMatrix();
 
        }
       
        public static void SetUpAxis(Vector3 startPosition,Vector3 endPosition)
        {
            
            SoftoriaPole.Math.Vector3 v2 = endPosition - startPosition;
            SetUpAxis(v2);

 
        }
        public static void SetUpAxis(Vector3 vector)
        {
            SoftoriaPole.Math.Vector3 v1 = new SoftoriaPole.Math.Vector3(0, 0, 1);
            SoftoriaPole.Math.Vector3 norm = VectorOperations.Crossproduct(v1, vector);
            double angle = VectorOperations.getangle(v1, vector);
            if (norm.X != 0 || norm.Y != 0 || norm.Z != 0)
                gl.Rotated(angle, norm.X, norm.Y, norm.Z);
            else
                if (angle == 180)
                {
                    gl.Rotated(180, 0, 1, 0);
                }
 
        }
    

        public static void OrientedCylinder(Vector3 startposition, Vector3 endposition, double startDiameter, double endDiameter, double thickness)
        {
            //OrientedCylinder(startposition, endposition, startDiameter, endDiameter, thickness, 32);
        }
        


        private static void DoOrientation(Vector3 startnodepos, Vector3 endnodepos)
        {
            throw new Exception("The method or operation is not implemented.");
        }
        /// <summary>
        /// Draw a cross arm with the specs as follows
        /// </summary>
        /// <param name="leftOverHangLength">leftOverHangLength</param>
        /// <param name="rightOvehangLength">rightOvehangLength</param>
        /// <param name="a">side1 length</param>
        /// <param name="b">side2 length</param>
        /// <param name="thickness">thickness</param>
        /// <param name="r1">curvature at the corner</param>
        /// <param name="r2">curvature at the terminals</param>
        public static void glDrawCrossArm(double leftOverHangLength, double rightOverhangLength, double riseAngle, double a, double b, double thickness, bool isAngleUporDown, double r1, double r2)
        {
            double length = (leftOverHangLength + rightOverhangLength);// System.Math.Cos((riseAngle * System.Math.PI) / 180);


            if (!(riseAngle >= -90 && riseAngle <= 90))
            {
               
                throw new Exception("riseAngle can not be greater than 90");
            }
            gl.PushMatrix();
            //gl.LoadIdentity();

            gl.Rotated(-riseAngle,0,1,0);

            gl.Translated((-leftOverHangLength+rightOverhangLength)/2,0,0);
            
            GlDrawAngle(length, a, b, thickness,isAngleUporDown, r1, r2);
            gl.PopMatrix();
            
        }

        public static void glDrawCrossArmOld(double leftOverHangLength, double rightOverhangLength, double riseAngle, double a, double b, double thickness, double r1, double r2)
        {
            double length = (leftOverHangLength + rightOverhangLength) / System.Math.Cos((riseAngle * System.Math.PI) / 180);

            double offsetx = (-leftOverHangLength + rightOverhangLength) / 2;

            if (!(riseAngle >= -90 && riseAngle <= 90))
            {

                throw new Exception("riseAngle can not be greater than 90");
            }
            gl.PushMatrix();
            //gl.LoadIdentity();

            gl.Rotated(-riseAngle, 0, 1, 0);
            if (riseAngle != 0)
            {
                double translatey = Math.Abs(Math.Tan((riseAngle * Math.PI) / 180) * offsetx);

                if (rightOverhangLength < leftOverHangLength)
                {
                    translatey = -translatey;
                }
                gl.Translated(offsetx, translatey, 0);
            }
            else
            {
                gl.Translated(offsetx, 0, 0);
            }

            GlDrawAngle(length, a, b, thickness,false, r1, r2);
            gl.PopMatrix();

        }

        /// <summary>
        /// Draw a cross arm with the specs as follows
        /// </summary>
        /// <param name="leftOverHangLength">leftOverHangLength</param>
        /// <param name="rightOvehangLength">rightOvehangLength</param>
        /// <param name="a">side1 length</param>
        /// <param name="b">side2 length</param>
        /// <param name="thickness">thickness</param>
        /// <param name="r1">curvature at the corner</param>
        /// <param name="r2">curvature at the terminals</param>
        public static void glChannelDrawCrossArm(double leftOverHangLength, double rightOverhangLength, double riseAngle, double a, double b, double thickness1,double thickness2,bool faceAorB, bool isAngleUporDown, double r1, double r2)
        {
            double length = (leftOverHangLength + rightOverhangLength);// System.Math.Cos((riseAngle * System.Math.PI) / 180);

            

            if (!(riseAngle >= -90 && riseAngle <= 90))
            {

                throw new Exception("riseAngle can not be greater than 90");
            }
            gl.PushMatrix();
            //gl.LoadIdentity();

            gl.Rotated(-riseAngle, 0, 1, 0);

            gl.Translated((-leftOverHangLength + rightOverhangLength) / 2, 0, 0);

            GlDrawChannel(length, a, b, thickness1,thickness2, faceAorB, isAngleUporDown, r1, r2);
            gl.PopMatrix();


        }
        
        public static void glDrawCrossArmkeleton(double leftOverHangLength, double rightOverhangLength, double riseAngle)
        {
            double length = (leftOverHangLength + rightOverhangLength);// System.Math.Cos((riseAngle * System.Math.PI) / 180);


            if (!(riseAngle >= -90 && riseAngle <= 90))
            {

                throw new Exception("riseAngle can not be greater than 90");
            }
            gl.PushMatrix();
            //gl.LoadIdentity();

            gl.Rotated(-riseAngle, 0, 1, 0);

            gl.Translated((-leftOverHangLength + rightOverhangLength) / 2, 0, 0);

            gl.Begin(gl.LINES);
            gl.Vertex3d(-length/2,0,0);
            gl.Vertex3d(length / 2, 0, 0);

            gl.End();
            gl.PopMatrix();

        }
        public static void glDrawCrossArmkeletonOld(double leftOverHangLength, double rightOverhangLength, double riseAngle)
        {

            double length = (leftOverHangLength + rightOverhangLength);// System.Math.Cos((riseAngle * System.Math.PI) / 180);


            if (!(riseAngle >= -90 && riseAngle <= 90))
            {

                throw new Exception("riseAngle can not be greater than 90");
            }
            gl.PushMatrix();
            //gl.LoadIdentity();

            gl.Rotated(-riseAngle, 0, 1, 0);

            gl.Translated((-leftOverHangLength + rightOverhangLength) / 2, 0, 0);
            gl.Begin(gl.LINES);
            gl.Vertex3d(-length / 2, 0, 0);
            gl.Vertex3d(length / 2, 0, 0);

            gl.End();
            gl.PopMatrix();

        }
        /// <summary>
        /// Draw an angle that has the center as tyhe origin (0,0,0)
        /// the angle is facing you if you are lookint is the direction of y axis.
        /// </summary>
        /// <param name="length">length of the angle</param>
        /// <param name="a">side 1 length</param>
        /// <param name="b">side 2 length</param>
        /// <param name="thickness">thickness</param>
        /// <param name="r1">curvature at the corner</param>
        /// <param name="r2">curvature at the terminals</param>
        public static void GlDrawAngle(double length, double a, double b, double thickness, bool isAngleUporDown, double r1, double r2)
        {
           
            gl.PushMatrix();
            gl.Translated(0, 0, thickness / 2);
            DrawCube(length, thickness, a);
            gl.Translated(0, 0, -thickness / 2);

            gl.Translated(0,-b/2,0);
            if (!isAngleUporDown)
            {
                gl.Translated(0, 0, -a / 2);
            }
            else
                 gl.Translated(0, 0, a / 2);
            DrawCube(length, b, thickness);
            gl.PopMatrix();
        }

        /// <summary>
        /// Draw a channel that has the center as tyhe origin (0,0,0)
        /// the channel is facing you if you are lookint is the direction of y axis.
        /// </summary>
        /// <param name="length">length of the channel</param>
        /// <param name="a">side 1 length</param>
        /// <param name="b">side 2 length</param>
        /// <param name="thickness">thickness</param>
        /// <param name="r1">curvature at the corner</param>
        /// <param name="r2">curvature at the terminals</param>
        public static void GlDrawChannel(double length, double a, double b, double thickness1,double thickness2,bool faceAorB,bool isAngleUporDown, double r1, double r2)
        {

            if (!faceAorB)
                gl.Rotated(90, 1, 0, 0);
            gl.PushMatrix();
            if (faceAorB)
                gl.Translated(0, 0, thickness1 / 2);
            else
                gl.Translated(0, 0, a / 2);

            DrawCube(length, thickness1, a);
            gl.Translated(0, 0, -thickness1 / 2);

            if (!faceAorB  &&isAngleUporDown)
            {
                gl.Scaled(1, -1, 1);
            }
            gl.Translated(0, -b / 2, 0);
           
                gl.Translated(0, 0, -a / 2);
                DrawCube(length, b, thickness2);
                gl.Translated(0, 0, a );
                DrawCube(length, b, thickness2);

            gl.PopMatrix();
        }

     
        public static void Torus(int numc, int numt,double innerR ,double outerR)
        {

            double r = innerR;
            double c = (innerR + outerR) / 2;
            double a = c-r;
            int i, j, k;
            double s, t, x, y, z, twopi;

            twopi = 2 * Math.PI;
            for (i = 0; i < numc; i++)
            {
                Vector3 lastPt1=null;
                Vector3 lastPt2 = null;
                Vector3 lastPt3 = null;

                gl.Begin(gl.QUAD_STRIP);
                for (j = 0; j <= numt; j++)
                {
                    for (k = 1; k >= 0; k--)
                    {
                        s = (i + k) % numc + 0.5;
                        t = j % numt;

                        x = (c + a * Math.Cos(s * twopi / numc)) * Math.Cos(t * twopi / numt);
                        y = (c + a * Math.Cos(s * twopi / numc)) * Math.Sin(t * twopi / numt);
                        z = a* Math.Sin(s * twopi / numc);
                        gl.Vertex3d(x, y, z);
                        lastPt3 = lastPt2;
                        lastPt2 = lastPt1;
                        lastPt1 = new Vector3(x,y,z);

                    }
                    if(j>0&&j%4==0)
                    {
                        Vector3 v1 = lastPt3 - lastPt2;
                        Vector3 v2 = lastPt1 - lastPt2;

                        Vector3 normal = (v1 ^ v2);

                        gl.Normal3d(normal.X, normal.Y, normal.Z);
                    }
                }
                gl.End();
            }
        }



    }
}
