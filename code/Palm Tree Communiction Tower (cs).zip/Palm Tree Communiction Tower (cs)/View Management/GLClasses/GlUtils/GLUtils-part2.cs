using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Geometry;
using OpenGL;
using SoftoriaPole.Math;
using System.Drawing;

namespace MainProgram.View_Management.Glu
{
    internal partial class GlUtils
    {
        const double lengthOfElement = .02;
        public static void DrawSquareHollow(double B, double r, double thickness)
        {

            int numCurvedElements = (int)System.Math.Ceiling(r * System.Math.PI / 2 / lengthOfElement);
            double stepAngle = System.Math.PI / 2 / numCurvedElements;

            gl.Begin(gl.QUADS);
            //right

            Vector3 v1 = new Vector3(B / 2, -(B - 2 * r) / 2, 0);
            Vector3 v2 = new Vector3(B / 2, (B - 2 * r) / 2, 0);
            Vector3 v3 = new Vector3(B / 2 - thickness, (B - 2 * r) / 2, 0);

            Vector3 normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);
            gl.Vertex3d(B / 2, -(B - 2 * r) / 2, 0);
            gl.Vertex3d(B / 2, (B - 2 * r) / 2, 0);
            gl.Vertex3d(B / 2 - thickness, (B - 2 * r) / 2, 0);
            gl.Vertex3d(B / 2 - thickness, -(B - 2 * r) / 2, 0);



            //top


            v1 = new Vector3(-(B - 2 * r) / 2, B / 2, 0);
            v2 = new Vector3((B - 2 * r) / 2, B / 2, 0);
            v3 = new Vector3((B - 2 * r) / 2, B / 2 - thickness, 0);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);
            gl.Vertex3d(-(B - 2 * r) / 2, B / 2, 0);
            gl.Vertex3d((B - 2 * r) / 2, B / 2, 0);
            gl.Vertex3d((B - 2 * r) / 2, B / 2 - thickness, 0);
            gl.Vertex3d(-(B - 2 * r) / 2, B / 2 - thickness, 0);


            //left
            v1 = new Vector3(-B / 2, -(B - 2 * r) / 2, 0);
            v2 = new Vector3(-B / 2, (B - 2 * r) / 2, 0);
            v3 = new Vector3(-(B / 2 - thickness), (B - 2 * r) / 2, 0);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);


            gl.Vertex3d(-B / 2, -(B - 2 * r) / 2, 0);
            gl.Vertex3d(-B / 2, (B - 2 * r) / 2, 0);
            gl.Vertex3d(-(B / 2 - thickness), (B - 2 * r) / 2, 0);
            gl.Vertex3d(-(B / 2 - thickness), -(B - 2 * r) / 2, 0);

            //down

            v1 = new Vector3(-(B - 2 * r) / 2, -B / 2, 0);
            v2 = new Vector3((B - 2 * r) / 2, -B / 2, 0);
            v3 = new Vector3((B - 2 * r) / 2, -(B / 2 - thickness), 0);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);

            gl.Vertex3d(-(B - 2 * r) / 2, -B / 2, 0);
            gl.Vertex3d((B - 2 * r) / 2, -B / 2, 0);
            gl.Vertex3d((B - 2 * r) / 2, -(B / 2 - thickness), 0);
            gl.Vertex3d(-(B - 2 * r) / 2, -(B / 2 - thickness), 0);


            gl.End();


            if (r != 0)
            {
                //TopRight
               
                gl.Begin(gl.QUADS);
              
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = stepAngle * i;
                    double angleiplus1 = stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    gl.Vertex3d(B / 2 - r + x1, B / 2 - r + y1, 0);
                    gl.Vertex3d(B / 2 - r + x2, B / 2 - r + y2, 0);
                    double x11 = (r - thickness) * System.Math.Cos(anglei);
                    double y11 = (r - thickness) * System.Math.Sin(anglei);
                    double x12 = (r - thickness) * System.Math.Cos(angleiplus1);
                    double y12 = (r - thickness) * System.Math.Sin(angleiplus1);

                    gl.Vertex3d(B / 2 - r + x12, B / 2 - r + y12, 0);
                    gl.Vertex3d(B / 2 - r + x11, B / 2 - r + y11, 0);

                }
                gl.End();
               
                //Topleft
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = System.Math.PI / 2 + stepAngle * i;
                    double angleiplus1 = System.Math.PI / 2 + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    gl.Vertex3d(-(B / 2 - r) + x1, B / 2 - r + y1, 0);
                    gl.Vertex3d(-(B / 2 - r) + x2, B / 2 - r + y2, 0);

                    double x11 = (r - thickness) * System.Math.Cos(anglei);
                    double y11 = (r - thickness) * System.Math.Sin(anglei);
                    double x12 = (r - thickness) * System.Math.Cos(angleiplus1);
                    double y12 = (r - thickness) * System.Math.Sin(angleiplus1);
                    gl.Vertex3d(-(B / 2 - r) + x12, B / 2 - r + y12, 0);
                    gl.Vertex3d(-(B / 2 - r) + x11, B / 2 - r + y11, 0);

                }
                gl.End();
               
                //BottomLeft
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = System.Math.PI + stepAngle * i;
                    double angleiplus1 = System.Math.PI + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);



                    gl.Vertex3d(-(B / 2 - r) + x1, -(B / 2 - r) + y1, 0);
                    gl.Vertex3d(-(B / 2 - r) + x2, -(B / 2 - r) + y2, 0);

                    double x11 = (r - thickness) * System.Math.Cos(anglei);
                    double y11 = (r - thickness) * System.Math.Sin(anglei);
                    double x12 = (r - thickness) * System.Math.Cos(angleiplus1);
                    double y12 = (r - thickness) * System.Math.Sin(angleiplus1);
                    gl.Vertex3d(-(B / 2 - r) + x12, -(B / 2 - r) + y12, 0);
                    gl.Vertex3d(-(B / 2 - r) + x11, -(B / 2 - r) + y11, 0);


                }
                gl.End();

                //BottomRight
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = 3 * System.Math.PI / 2 + stepAngle * i;
                    double angleiplus1 = 3 * System.Math.PI / 2 + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);


                    gl.Vertex3d(B / 2 - r + x1, -(B / 2 - r) + y1, 0);
                    gl.Vertex3d(B / 2 - r + x2, -(B / 2 - r) + y2, 0);

                    double x11 = (r - thickness) * System.Math.Cos(anglei);
                    double y11 = (r - thickness) * System.Math.Sin(anglei);
                    double x12 = (r - thickness) * System.Math.Cos(angleiplus1);
                    double y12 = (r - thickness) * System.Math.Sin(angleiplus1);
                    gl.Vertex3d(B / 2 - r + x12, -(B / 2 - r) + y12, 0);
                    gl.Vertex3d(B / 2 - r + x11, -(B / 2 - r) + y11, 0);
                }
                gl.End();
            }
            return;
            gl.End();

        }
        public static void DrawSquareSegment(double startB, double endB, double r, double length)
        {

            int numCurvedElements = (int)System.Math.Ceiling(r * System.Math.PI / 2 / lengthOfElement);
            double stepAngle = System.Math.PI / 2 / numCurvedElements;
            gl.Begin(gl.QUADS);
            //right

            Vector3 v1 = new Vector3(startB / 2, -(startB - 2 * r) / 2, 0);
            Vector3 v2 = new Vector3(startB / 2, (startB - 2 * r) / 2, 0);
            Vector3 v3 = new Vector3(endB / 2, (endB - 2 * r) / 2, length);

            Vector3 normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);
            gl.Vertex3d(startB / 2, -(startB - 2 * r) / 2, 0);
            gl.Vertex3d(startB / 2, (startB - 2 * r) / 2, 0);
            gl.Vertex3d(endB / 2, (endB - 2 * r) / 2, length);
            gl.Vertex3d(endB / 2, -(endB - 2 * r) / 2, length);



            //top
            v1 = new Vector3(-(startB - 2 * r) / 2, startB / 2, 0);
            v2 = new Vector3((startB - 2 * r) / 2, startB / 2, 0);
            v3 = new Vector3((endB - 2 * r) / 2, endB / 2, length);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);

            gl.Vertex3d(-(startB - 2 * r) / 2, startB / 2, 0);
            gl.Vertex3d((startB - 2 * r) / 2, startB / 2, 0);
            gl.Vertex3d((endB - 2 * r) / 2, endB / 2, length);
            gl.Vertex3d(-(endB - 2 * r) / 2, endB / 2, length);


            //left

            v1 = new Vector3(-startB / 2, -(startB - 2 * r) / 2, 0);
            v2 = new Vector3(-startB / 2, (startB - 2 * r) / 2, 0);
            v3 = new Vector3(-endB / 2, (endB - 2 * r) / 2, length);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);

            gl.Vertex3d(-startB / 2, -(startB - 2 * r) / 2, 0);


            gl.Vertex3d(-startB / 2, (startB - 2 * r) / 2, 0);
            gl.Vertex3d(-endB / 2, (endB - 2 * r) / 2, length);
            gl.Vertex3d(-endB / 2, -(endB - 2 * r) / 2, length);



            //down
            v1 = new Vector3(-(startB - 2 * r) / 2, -startB / 2, 0);
            v2 = new Vector3((startB - 2 * r) / 2, -startB / 2, 0);
            v3 = new Vector3((endB - 2 * r) / 2, -endB / 2, length);

            normal = (v1 - v2) ^ (v3 - v2);
            normal = -normal;
            gl.Normal3d(normal.X, normal.Y, normal.Z);
            gl.Vertex3d(-(startB - 2 * r) / 2, -startB / 2, 0);
            gl.Vertex3d((startB - 2 * r) / 2, -startB / 2, 0);
            gl.Vertex3d((endB - 2 * r) / 2, -endB / 2, length);
            gl.Vertex3d(-(endB - 2 * r) / 2, -endB / 2, length);


            gl.End();


            //Draw curves

            if (r != 0)
            {
                //TopRight
              
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = stepAngle * i;
                    double angleiplus1 = stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    v1 = new Vector3(startB / 2 - r + x1, startB / 2 - r + y1, 0);
                    v2 = new Vector3(startB / 2 - r + x2, startB / 2 - r + y2, 0);
                    v3 = new Vector3(endB / 2 - r + x2, endB / 2 - r + y2, length);

                    normal = (v1 - v2) ^ (v3 - v2);
                    normal = -normal;
                    gl.Normal3d(normal.X, normal.Y, normal.Z);

                    gl.Vertex3d(startB / 2 - r + x1, startB / 2 - r + y1, 0);
                    gl.Vertex3d(startB / 2 - r + x2, startB / 2 - r + y2, 0);

                    gl.Vertex3d(endB / 2 - r + x2, endB / 2 - r + y2, length);
                    gl.Vertex3d(endB / 2 - r + x1, endB / 2 - r + y1, length);


                }
                gl.End();

                //Topleft
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = System.Math.PI / 2 + stepAngle * i;
                    double angleiplus1 = System.Math.PI / 2 + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    v1 = new Vector3(-(startB / 2 - r) + x1, startB / 2 - r + y1, 0);
                    v2 = new Vector3(-(startB / 2 - r) + x2, startB / 2 - r + y2, 0);
                    v3 = new Vector3(-(endB / 2 - r) + x2, endB / 2 - r + y2, length);

                    normal = (v1 - v2) ^ (v3 - v2);
                    normal = -normal;
                    gl.Normal3d(normal.X, normal.Y, normal.Z);

                    gl.Vertex3d(-(startB / 2 - r) + x1, startB / 2 - r + y1, 0);
                    gl.Vertex3d(-(startB / 2 - r) + x2, startB / 2 - r + y2, 0);

                    gl.Vertex3d(-(endB / 2 - r) + x2, endB / 2 - r + y2, length);
                    gl.Vertex3d(-(endB / 2 - r) + x1, endB / 2 - r + y1, length);
                }
                gl.End();

                //BottomLeft
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = System.Math.PI + stepAngle * i;
                    double angleiplus1 = System.Math.PI + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    v1 = new Vector3(-(startB / 2 - r) + x1, -(startB / 2 - r) + y1, 0);
                    v2 = new Vector3(-(startB / 2 - r) + x2, -(startB / 2 - r) + y2, 0);
                    v3 = new Vector3(-(endB / 2 - r) + x2, -(endB / 2 - r) + y2, length);

                    normal = (v1 - v2) ^ (v3 - v2);
                    normal = -normal;
                    gl.Normal3d(normal.X, normal.Y, normal.Z);


                    gl.Vertex3d(-(startB / 2 - r) + x1, -(startB / 2 - r) + y1, 0);
                    gl.Vertex3d(-(startB / 2 - r) + x2, -(startB / 2 - r) + y2, 0);

                    gl.Vertex3d(-(endB / 2 - r) + x2, -(endB / 2 - r) + y2, length);
                    gl.Vertex3d(-(endB / 2 - r) + x1, -(endB / 2 - r) + y1, length);
                }
                gl.End();

                //BottomRight
                gl.Begin(gl.QUADS);
                for (int i = 0; i < numCurvedElements; i++)
                {
                    double anglei = 3 * System.Math.PI / 2 + stepAngle * i;
                    double angleiplus1 = 3 * System.Math.PI / 2 + stepAngle * (i + 1);

                    double x1 = r * System.Math.Cos(anglei);
                    double y1 = r * System.Math.Sin(anglei);
                    double x2 = r * System.Math.Cos(angleiplus1);
                    double y2 = r * System.Math.Sin(angleiplus1);

                    v1 = new Vector3(startB / 2 - r + x1, -(startB / 2 - r) + y1, 0);
                    v2 = new Vector3(startB / 2 - r + x2, -(startB / 2 - r) + y2, 0);
                    v3 = new Vector3(endB / 2 - r + x2, -(endB / 2 - r) + y2, length);

                    normal = (v1 - v2) ^ (v3 - v2);
                    normal = -normal;
                    gl.Normal3d(normal.X, normal.Y, normal.Z);

                    gl.Vertex3d(startB / 2 - r + x1, -(startB / 2 - r) + y1, 0);
                    gl.Vertex3d(startB / 2 - r + x2, -(startB / 2 - r) + y2, 0);

                    gl.Vertex3d(endB / 2 - r + x2, -(endB / 2 - r) + y2, length);
                    gl.Vertex3d(endB / 2 - r + x1, -(endB / 2 - r) + y1, length);

                }
                gl.End();
            }
        }

        
      
        public static void Orient(Vector3 startnodepos, Vector3 endnodepos)
        {

            SoftoriaPole.Math.Vector3 v1 = new SoftoriaPole.Math.Vector3(0, 0, 1);
            SoftoriaPole.Math.Vector3 v2 = endnodepos - startnodepos;

            double length = v2.Magnitude;


            double angle = VectorOperations.getangle(v1, v2);

            //gl.Translated(startnodepos.X, startnodepos.Y, startnodepos.Z);
            //rotate3d(angle3d.X, angle3d.Y, angle3d.Z);
            SoftoriaPole.Math.Vector3 norm = VectorOperations.Crossproduct(v1, v2);
            gl.Translated(startnodepos.X, startnodepos.Y, startnodepos.Z);
            norm.Normalize();
            //angle = -angle;
            if (norm.X != 0 || norm.Y != 0 || norm.Z != 0)
                gl.Rotated(angle, norm.X, norm.Y, norm.Z);
            else
                if (angle == 180)
                {
                    gl.Rotated(180, 0, 1, 0);
                }

            double adjustmentAngle = 0;

            Vector3 axialVector = endnodepos - startnodepos;
            adjustmentAngle = Math.Atan2(axialVector.Y, axialVector.X);

            gl.Rotated(90 + adjustmentAngle * 180 / Math.PI, 0, 0, 1);
        }
       

        private const int _circularNumSides = 22;
        private const int _loops = 16;

       public static double GetTheta(double  radious,double width)
        {
            return 2 * System.Math.Asin(width / 2 / radious);
        }


        public static void DrawCircularOpening(double startRadious, double endRadious, double openingLength, double width, double orientation)
        {
            double thetaBtm = GetTheta(startRadious, width);
            double thetaTop = GetTheta(endRadious, width);
            double startThetaBtm = orientation - thetaBtm / 2;
            double endThetaBtm = orientation + thetaBtm / 2;
            double startThetaTop = orientation - thetaTop / 2;
            double endThetaTop = orientation + thetaTop / 2;

            gl.Begin(gl.QUAD_STRIP);
            int N1 = (int)Math.Ceiling(_circularNumSides * startThetaBtm / 2 / System.Math.PI);
            int N2 = (int)Math.Ceiling(_circularNumSides * thetaTop / 2 / System.Math.PI); ;
            int N= System.Math.Max(N1, N2);
            double stepangleBtm = thetaBtm / (N);
            double stepangleTop = thetaTop / (N);

            Vector3 InitialBtmPt = new Vector3(startRadious * System.Math.Cos(endThetaBtm), startRadious * System.Math.Sin(endThetaBtm), 0);
            Vector3 InitialTopPt = new Vector3(endRadious * System.Math.Cos(endThetaTop), endRadious * System.Math.Sin(endThetaTop), openingLength);

            gl.Vertex3d(InitialBtmPt.X, InitialBtmPt.Y, InitialBtmPt.Z);	// Bottom Left Of The Quad (Bottom)
            gl.Vertex3d(InitialTopPt.X, InitialTopPt.Y, InitialTopPt.Z);	// Bottom Right Of The Quad (Bottom)

            for (int i = 0; i < N; i++)
            {

                Vector3 TopPt = VectorOperations.RotateAboutZ(InitialTopPt, -(i + 1) * stepangleTop);
                Vector3 BtmPt = VectorOperations.RotateAboutZ(InitialBtmPt, -(i + 1) * stepangleBtm);

                gl.Vertex3d(BtmPt.X, BtmPt.Y, BtmPt.Z);	// Bottom Left Of The Quad (Bottom)
                gl.Vertex3d(TopPt.X, TopPt.Y, TopPt.Z);	// Bottom Right Of The Quad (Bottom)

            }

            gl.End();
        }

        public static void DrawPolygonalOpening(double startRadious, double endRadious, double openingLength,  double width, double orientation,int sidesCount)
        {

            startRadious = startRadious / System.Math.Cos(2 * System.Math.PI / sidesCount / 2);
            endRadious = endRadious / System.Math.Cos(2 * System.Math.PI / sidesCount / 2);

            double thetaBtm = GetTheta(startRadious, width);
            double thetaTop = GetTheta(endRadious, width);
            double startThetaBtm = orientation - thetaBtm / 2;
            double endThetaBtm = orientation + thetaBtm / 2;
            double startThetaTop = orientation - thetaTop / 2;
            double endThetaTop = orientation + thetaTop / 2;

            gl.Begin(gl.QUAD_STRIP);
            int N1 = (int)Math.Ceiling(_circularNumSides * startThetaBtm / 2 / System.Math.PI);
            int N2 = (int)Math.Ceiling(_circularNumSides * thetaTop / 2 / System.Math.PI); ;
            int N = System.Math.Max(N1, N2);
            double stepangleBtm = thetaBtm / (N);
            double stepangleTop = thetaTop / (N);

            Vector3 InitialBtmPt = new Vector3(startRadious * System.Math.Cos(endThetaBtm), startRadious * System.Math.Sin(endThetaBtm), 0);
            Vector3 InitialTopPt = new Vector3(endRadious * System.Math.Cos(endThetaTop), endRadious * System.Math.Sin(endThetaTop), openingLength);

            gl.Vertex3d(InitialBtmPt.X, InitialBtmPt.Y, InitialBtmPt.Z);	// Bottom Left Of The Quad (Bottom)
            gl.Vertex3d(InitialTopPt.X, InitialTopPt.Y, InitialTopPt.Z);	// Bottom Right Of The Quad (Bottom)

            for (int i = 0; i < N; i++)
            {

                Vector3 TopPt = VectorOperations.RotateAboutZ(InitialTopPt, -(i + 1) * stepangleTop);
                Vector3 BtmPt = VectorOperations.RotateAboutZ(InitialBtmPt, -(i + 1) * stepangleBtm);

                gl.Vertex3d(BtmPt.X, BtmPt.Y, BtmPt.Z);	// Bottom Left Of The Quad (Bottom)
                gl.Vertex3d(TopPt.X, TopPt.Y, TopPt.Z);	// Bottom Right Of The Quad (Bottom)

            }

            gl.End();
        }

        internal static void DrawSquareOpening(object startB, object endB, double r, double openingLength, double p, double p_6)
        {
            throw new Exception("The method or operation is not implemented.");
        }
    }
}
