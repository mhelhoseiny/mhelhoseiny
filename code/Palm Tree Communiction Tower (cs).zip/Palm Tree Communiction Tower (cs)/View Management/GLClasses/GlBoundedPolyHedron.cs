﻿//=============================================================
// C# OpenGL Framework
// Copyright (c) 2005-2006 devDept.com
// All rights reserved.
//
// For more information on this program, please visit: 
// http://www.csharpGLEngine.com
//
// For licensing information, please visit: 
// http://www.csharpGLEngine.com/licensing.html
//=============================================================

using System;
using System.Collections.Generic;
using System.Text;
using OpenGL;
using System.Drawing;
using System.IO;
using System.Collections;
using System.ComponentModel;
using GLEngine.Core;
using GLEngine;
using GLEngine.Geometry;
using SoftoriaPole.Geometry;

namespace MainProgram.ViewManagement
{
    /// <summary>
    /// Line entity.
    /// </summary>
    [Serializable]
    public class GLBoundingPolyhedron : Entity
    {

        BoundingPolyhedron _boundedPolyHedron;

        public BoundingPolyhedron BoundedPolyHedron
        {
            get { return _boundedPolyHedron; }
            set { _boundedPolyHedron = value; }
        }
        bool DisableLight ;
        bool DisablePicking=false;
        public GLBoundingPolyhedron(BoundingPolyhedron boundedPolyHedron, Color color)
            : base(color)
        {
            _boundedPolyHedron = boundedPolyHedron;
            DisableLight = false;
            base.vertices = new float[2, 3];
            base.vertices2D = new float[2, 2];
            base.vertices[0, 0] = (float)_boundedPolyHedron.StartPosition.X;
            base.vertices[0, 1] = (float)_boundedPolyHedron.StartPosition.Y;
            base.vertices[0, 2] = (float)_boundedPolyHedron.StartPosition.Z;
            base.vertices[1, 0] = (float)_boundedPolyHedron.EndPosition.X;
            base.vertices[1, 1] = (float)_boundedPolyHedron.EndPosition.Y;
            base.vertices[1, 2] = (float)_boundedPolyHedron.EndPosition.Z;


        }
              

        
        public override void Draw()
        {

            SetOpenGLColor();
            DrawWithoutColor();

        }
       
        public override void DrawWithoutColor()
        {
            if (DisableLight)
              gl.Disable(gl.LIGHTING);
            else
                gl.Enable(gl.LIGHTING);

           int count = _boundedPolyHedron.TopPoints.Count;
            for(int i = 0;i< _boundedPolyHedron.TopPoints.Count ;i++ )
            {
                gl.Begin(gl.QUADS);

                float[] normal = Vector.Normal(new float[] { (float)_boundedPolyHedron.TopPoints[i].X, (float)_boundedPolyHedron.TopPoints[i].Y, (float)_boundedPolyHedron.TopPoints[i].Z },
                                         new float[] { (float)_boundedPolyHedron.TopPoints[(i + 1) % count].X, (float)_boundedPolyHedron.TopPoints[(i + 1) % count].Y, (float)_boundedPolyHedron.TopPoints[(i + 1) % count].Z },
                                         new float[] { (float)_boundedPolyHedron.BasePoints[(i + 1) % count].X, (float)_boundedPolyHedron.BasePoints[(i + 1) % count].Y, (float)_boundedPolyHedron.BasePoints[(i + 1) % count].Z });
                gl.Normal3fv(normal);

                gl.Vertex3d(_boundedPolyHedron.TopPoints[i].X, _boundedPolyHedron.TopPoints[i].Y, _boundedPolyHedron.TopPoints[i].Z);
                gl.Vertex3d(_boundedPolyHedron.TopPoints[(i + 1) % count].X, _boundedPolyHedron.TopPoints[(i + 1) % count].Y, _boundedPolyHedron.TopPoints[(i + 1) % count].Z);
                gl.Vertex3d(_boundedPolyHedron.BasePoints[(i + 1) % count].X, _boundedPolyHedron.BasePoints[(i + 1) % count].Y, _boundedPolyHedron.BasePoints[(i + 1) % count].Z);
                gl.Vertex3d(_boundedPolyHedron.BasePoints[i].X, _boundedPolyHedron.BasePoints[i].Y, _boundedPolyHedron.BasePoints[i].Z);
              
                gl.End();
           
            }
        }

        public override void DrawWireframe()
        {

           

        }

        #region Standard Edition functions

        public override void DrawForSelection(Color indexMappedColor)
        {

            // selection drawing: AS FAST AS POSSIBLE / NO LIGHTING / NO NEED OF NORMAL INFO
            if (DisablePicking)
                return;
            gl.Color3ub(indexMappedColor.R, indexMappedColor.G, indexMappedColor.B);

            DrawWithoutColor();

        }

      

        #endregion

        #region Professional Edition functions

        /*public override void AddIgesEntities(ArrayList igesEntities, ref int index)
        {

            Iges.Line line = new GLEngine.Iges.Line(vertices[0, 0], vertices[0, 1], vertices[0, 2],
                                                      vertices[1, 0], vertices[1, 1], vertices[1, 2], color);

            line.CreateChildren(ref index);

            line.AssignID(ref index);

            line.AddToTheList(igesEntities);

        }*/

        public override void WriteDXF(Dxf dxf, TextWriter tw)
        {

            //dxf.WriteLINE(vertices[0, 0], vertices[0, 1], vertices[0, 2],
            //                vertices[1, 0], vertices[1, 1], vertices[1, 2], color, tw);

        }

        #endregion


    }
}
