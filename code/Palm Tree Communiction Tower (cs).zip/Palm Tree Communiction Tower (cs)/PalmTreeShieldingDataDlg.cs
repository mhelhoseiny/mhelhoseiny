﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SoftoriaPole.Geometry;
using SoftoriaPole.Math;
using GLEngine;
using MainProgram.ViewManagement;
using MainProgram.Projects.Geometry_Project;
using MainProgram.App_Classes;
using MainProgram.Projects.Analysis;

namespace MainProgram.Dialogs.Menues.Testing
{
   
    public partial class PalmTreeShieldingDataDlg : Form
    {
        double KZmin ;
        double Alpha ;
        double Zg ;

        // Structure Data
        double V ;
        double I ;
        double Kd ;

        GeneralizedShieldingProcess shP;

        List<BoundingPolyhedron> boundingPolyHedrons  = new List<BoundingPolyhedron>();
        List<double> orientations = new List<double>();
        OGLControl _glControl;
        int glInitialCount;
        PalmTreeData _palmTreeData;

        public PalmTreeData palmTreeData
        {
            get { return _palmTreeData; }
        }
        public PalmTreeShieldingDataDlg(OGLControl glControl,PalmTreeData palmTreeData)
        {
            _glControl = glControl;
            glInitialCount = glControl.entities.Count;
            InitializeComponent();
            cmb_Class.SelectedIndex = 1;
            cmb_Category.SelectedIndex = 1;
            _palmTreeData = palmTreeData;
            LoadData();

        }

        private void LoadData()
        {
            if (_palmTreeData.BranchSpecs != null)
            {
                numC_L1.Value = (decimal)_palmTreeData.BranchSpecs.L1;
                numC_L2.Value = (decimal)_palmTreeData.BranchSpecs.L2;
                numC_L4.Value = (decimal)_palmTreeData.BranchSpecs.L4;

                numC_W1.Value = (decimal)_palmTreeData.BranchSpecs.W1;
                numC_W2.Value = (decimal)_palmTreeData.BranchSpecs.W2;
                numC_W3.Value = (decimal)_palmTreeData.BranchSpecs.W3;

                numC_T1.Value = (decimal)_palmTreeData.BranchSpecs.T1;
                numC_T2.Value = (decimal)_palmTreeData.BranchSpecs.T2;
                numC_T3.Value = (decimal)_palmTreeData.BranchSpecs.T3;

                numC_SL1.Value = (decimal)_palmTreeData.BranchSpecs.SL1;
                numC_SL2.Value = (decimal)_palmTreeData.BranchSpecs.SL2;
                numC_DeltaPhai.Value = (decimal)(_palmTreeData.BranchSpecs.DeltaPhai * 180 / System.Math.PI);
            }
            dgV_LevelSpecs.Rows.Clear();
            for (int i = 0; i < palmTreeData.BranchLevelSpecs.Count; i++)
            {
                int rowIndex = dgV_LevelSpecs.Rows.Add();
                dgV_LevelSpecs.Rows[rowIndex].Cells["LevelName"].Value = palmTreeData.BranchLevelSpecs[i].Name;
                dgV_LevelSpecs.Rows[rowIndex].Cells["Z"].Value = palmTreeData.BranchLevelSpecs[i].Z.ToString();
                dgV_LevelSpecs.Rows[rowIndex].Cells["R"].Value = palmTreeData.BranchLevelSpecs[i].R.ToString();
                dgV_LevelSpecs.Rows[rowIndex].Cells["BN"].Value = palmTreeData.BranchLevelSpecs[i].NumberOfBranches.ToString();
                dgV_LevelSpecs.Rows[rowIndex].Cells["Phai"].Value = (palmTreeData.BranchLevelSpecs[i].Phai * 180 / System.Math.PI).ToString();
                dgV_LevelSpecs.Rows[rowIndex].Cells["Theta0"].Value = (palmTreeData.BranchLevelSpecs[i].Theta0 * 180 / System.Math.PI).ToString();
                dgV_LevelSpecs.Rows[rowIndex].Cells["LSL3"].Value = (palmTreeData.BranchLevelSpecs[i].L3).ToString();
            }
            dgV_PipesAntennas.Rows.Clear();
            for (int i = 0; i < palmTreeData.PipesAndAnglesSpecs.Count; i++)
            {
                int rowIndex = dgV_PipesAntennas.Rows.Add();

                dgV_PipesAntennas.Rows[rowIndex].Cells["Name"].Value = palmTreeData.PipesAndAnglesSpecs[i].Name;
                dgV_PipesAntennas.Rows[rowIndex].Cells["W"].Value = palmTreeData.PipesAndAnglesSpecs[i].W.ToString();
                dgV_PipesAntennas.Rows[rowIndex].Cells["L"].Value = palmTreeData.PipesAndAnglesSpecs[i].L.ToString();
                dgV_PipesAntennas.Rows[rowIndex].Cells["T"].Value = palmTreeData.PipesAndAnglesSpecs[i].T.ToString();

                dgV_PipesAntennas.Rows[rowIndex].Cells["Radius"].Value = palmTreeData.PipesAndAnglesSpecs[i].R.ToString();
                dgV_PipesAntennas.Rows[rowIndex].Cells["Elev"].Value = palmTreeData.PipesAndAnglesSpecs[i].Z.ToString();
                dgV_PipesAntennas.Rows[rowIndex].Cells["TwistAngle"].Value = (palmTreeData.PipesAndAnglesSpecs[i].TwistAngle * 180 / System.Math.PI).ToString();

                dgV_PipesAntennas.Rows[rowIndex].Cells["Orientation"].Value = (palmTreeData.PipesAndAnglesSpecs[i].Theta * 180 / System.Math.PI).ToString();

            }
            if (palmTreeData.WindInformation != null)
            {
                num_V.Value = (decimal)palmTreeData.WindInformation.V;
                cmb_Class.SelectedIndex = (int)palmTreeData.WindInformation.Class;
                cmb_Category.SelectedIndex = (int)palmTreeData.WindInformation.Category;
                num_Gh.Value = (decimal)palmTreeData.WindInformation.Gh;
                num_Kd.Value = (decimal)palmTreeData.WindInformation.Kd;
                num_ShapeFactor.Value = (decimal)palmTreeData.WindInformation.ShapeFactor;
                numC_StepLength.Value = (decimal)palmTreeData.WindInformation.StepLength;
                numC_WindX.Value = (decimal)palmTreeData.WindInformation.WindDirection.X;
                numC_WindY.Value = (decimal)palmTreeData.WindInformation.WindDirection.Y;
                numC_WindZ.Value = (decimal)palmTreeData.WindInformation.WindDirection.Z;
                rdo_auto.Checked = palmTreeData.WindInformation.ShapeFactorMode == CalulationMode.Auto;
            }

            if (palmTreeData.LeafDesignSpecifications!=null)
            {
                num_MyC.Value = (decimal)palmTreeData.LeafDesignSpecifications.MyC;
                num_MzC.Value = (decimal)palmTreeData.LeafDesignSpecifications.MzC;
                num_WeightFactor.Value = (decimal)palmTreeData.LeafDesignSpecifications.Weightfactor;
                num_WindFactor.Value = (decimal)palmTreeData.LeafDesignSpecifications.WindFactor;
                num_XDist.Value = (decimal)palmTreeData.LeafDesignSpecifications.XDist;
                num_ShieldingFactor.Value = (decimal)palmTreeData.LeafDesignSpecifications.ManualShieldingFactor;
                rdo_shFAuto.Checked = palmTreeData.LeafDesignSpecifications.shieldingFactorMode== CalulationMode.Auto;
            }  
        }


        public void LoadWindData()
        {
            palmTreeData.WindInformation = new WindInfo();
            palmTreeData.WindInformation.V = (double)num_V.Value;
            palmTreeData.WindInformation.Class = (StructureClass)cmb_Class.SelectedIndex;
            palmTreeData.WindInformation.Category = (ExposureCategory)cmb_Category.SelectedIndex;
            palmTreeData.WindInformation.Gh = (double)num_Gh.Value;
            palmTreeData.WindInformation.Kd = (double)num_Kd.Value;
            palmTreeData.WindInformation.ShapeFactor = (double)num_ShapeFactor.Value;
            palmTreeData.WindInformation.StepLength = (double)numC_StepLength.Value;
            palmTreeData.WindInformation.WindDirection = new Vector3((double)numC_WindX.Value, (double)numC_WindY.Value, (double)numC_WindZ.Value);
            palmTreeData.WindInformation.ShapeFactorMode = (rdo_auto.Checked? CalulationMode.Auto: CalulationMode.Manual);
        }

        public void LoadLeafDesignSpecs()
        {
            palmTreeData.LeafDesignSpecifications = new LeafDesignSpecs() ;
            palmTreeData.LeafDesignSpecifications.MyC = (double)num_MyC.Value;
            palmTreeData.LeafDesignSpecifications.MzC = (double)num_MzC.Value;
            palmTreeData.LeafDesignSpecifications.Weightfactor = (double)num_WeightFactor.Value;
            palmTreeData.LeafDesignSpecifications.WindFactor = (double)num_WindFactor.Value;
            palmTreeData.LeafDesignSpecifications.XDist = (double)num_XDist.Value;
            palmTreeData.LeafDesignSpecifications.ManualShieldingFactor = (double)num_ShieldingFactor.Value;
            palmTreeData.LeafDesignSpecifications.shieldingFactorMode = rdo_shFAuto.Checked?CalulationMode.Auto: CalulationMode.Manual;
        }
        //Dictionary<string, Dictionary<KeyValuePair<double, int>, KeyValuePair<int, double>>> DictLeafsHolyHedron = new Dictionary<string, Dictionary<KeyValuePair<double, int>, KeyValuePair<int, double>>>();
        Dictionary<string, Dictionary<double, Dictionary<int, KeyValuePair<int, double> > >> DictLeafsPolyHedron = new Dictionary<string,Dictionary<double,Dictionary<int,KeyValuePair<int,double>>>>();
        Dictionary<string, int> DictAntennaAndPipes = new Dictionary<string, int>();
        List<List<double>> weights = new List<List<double>>();
        List<List<double>> npas = new List<List<double>>();
        List<double> shapeFactors = new List<double>();
        private void button1_Click(object sender, EventArgs e)
        {
            boundingPolyHedrons.Clear();
            npas.Clear();
            weights.Clear();
            shapeFactors.Clear();
            //if(_glControl.entities.Count !=glInitialCount )
            //{
            //    _glControl.entities.RemoveRange(glInitialCount, _glControl.entities.Count - glInitialCount); 
            
            //}

            _glControl.entities.Clear();
           
            AddLeafs();
            AddAntennaAndPipes();

            shP = new GeneralizedShieldingProcess(boundingPolyHedrons,(double)numC_StepLength.Value,0);
            _glControl.Refresh();
        }

        double L1;
        double L2;
        double L3;
        double L4;
        double W1;
        double W2;
        double W3;
        double T1;
        double T2;
        double T3;

        double SL1;
        double SL2;
        //Gust Factot
        double Gh;

        double DeltaPhai;
        private void AddLeafs()
        {
           
            DictLeafsPolyHedron.Clear();
            L1 = (double)numC_L1.Value;
            L2 = (double)numC_L2.Value;
       
            L4 = (double)numC_L4.Value;

            W1 = (double)numC_W1.Value;
            W2 = (double)numC_W2.Value;
            W3 = (double)numC_W3.Value;

            T1 = (double)numC_T1.Value;
            T2 = (double)numC_T2.Value;
            T3 = (double)numC_T3.Value;

            SL1 = (double)numC_SL1.Value;
            SL2 = (double)numC_SL2.Value;

            DeltaPhai = (double)numC_DeltaPhai.Value*System.Math.PI/180;
            palmTreeData.BranchSpecs = new BranchSpecs(L1, L2, L4, SL1, SL2, W1, W2, W3, T1, T2, T3, DeltaPhai, (double)num_RipDensity.Value, (double)num_LeafDensity.Value, (double)numC_WL.Value, (double)numC_Lth.Value);
            palmTreeData.BranchLevelSpecs.Clear();
            for (int i = 0; i < dgV_LevelSpecs.Rows.Count; i++)
            {
                string name = (string)dgV_LevelSpecs.Rows[i].Cells["LevelName"].Value;
                if (name == null)
                    continue;
                double Z = double.Parse((string)dgV_LevelSpecs.Rows[i].Cells["Z"].Value);
                double R = double.Parse((string)dgV_LevelSpecs.Rows[i].Cells["R"].Value);
                int BN = int.Parse((string)dgV_LevelSpecs.Rows[i].Cells["BN"].Value);
                double Phai = double.Parse((string)dgV_LevelSpecs.Rows[i].Cells["Phai"].Value)*System.Math.PI/180;
                double Theta0 = double.Parse((string)dgV_LevelSpecs.Rows[i].Cells["Theta0"].Value) * System.Math.PI / 180;
                L3 = double.Parse((string)dgV_LevelSpecs.Rows[i].Cells["LSL3"].Value);
                palmTreeData.BranchLevelSpecs.Add(new LevelSpecs(name,L3,Z,R,BN,Phai,Theta0));
                double stepAngle = 2*System.Math.PI/BN;

                DictLeafsPolyHedron[name] = new Dictionary<double,Dictionary<int,KeyValuePair<int,double>>>();
                for (int j = 0; j < BN; j++)
                {
                    double thetai = Theta0 + stepAngle * j;
                    AddSingleLeaf(name,j, Z, R, Phai, thetai, L1, L2, L3, L4, T1, T2, T3, W1, W2, W3, SL1, SL2, DeltaPhai);
                }
            }
        }

        private void AddSingleLeaf(string LevelName,int i, double Z, double R, double Phai, double thetai, double L1, double L2, double L3, double L4, double T1, double T2, double T3, double W1, double W2, double W3, double SL1, double SL2, double DeltaPhai)
        {
            
            DictLeafsPolyHedron[LevelName][thetai] = new Dictionary<int, KeyValuePair<int, double>>();

            Vector3 windDir = new Vector3((double)numC_WindX.Value,(double)numC_WindY.Value, (double)numC_WindZ.Value);
            double Lth = (double)numC_Lth.Value;
            double WL = (double)numC_WL.Value;
            Vector3 startPos = new Vector3(R*System.Math.Cos(thetai),R*System.Math.Sin(thetai),Z);
            Vector3 axial = ComputeVector(Phai, thetai);
            BoundingPolyhedron b1Rip = new BoundingPolyhedron(startPos, axial, L3, W1, W1, T1, T1);
            double area1 = GeneralizedShieldingProcess.GetProjectedArea(b1Rip, windDir, true);
            DictLeafsPolyHedron[LevelName][thetai].Add(1, new KeyValuePair<int, double>(boundingPolyHedrons.Count,area1));
            
            boundingPolyHedrons.Add(b1Rip);
            npas.Add(GetNPA(b1Rip,1,windDir,(double)numC_StepLength.Value));
            weights.Add(GetElementsWeights(b1Rip, (double)numC_StepLength.Value, (double)num_RipDensity.Value));

            double deltaL = L4;
            double t = deltaL / (L1 - L4);

            double W2_25 = (1 - t) * W2 + t * W3;
            double T2_25 = (1 - t) * T2 + t * T3;

            BoundingPolyhedron b2Rip = new BoundingPolyhedron(b1Rip.EndPosition, axial, L4, W2, W2_25, T2, T2_25);
            double Wr = b2Rip.DimensionAAt(.5);
            double WSpecial = (WL - Wr) / 2 + Wr;
            BoundingPolyhedron b2Leaf = new BoundingPolyhedron(b1Rip.EndPosition, axial, L4, WSpecial, WSpecial, Lth, Lth);
           

            double area2;
            bool ch2;
            BoundingPolyhedron b2 = DecidePolyHedron(b2Rip, b2Leaf, SL1, windDir, out ch2, out area2);
            DictLeafsPolyHedron[LevelName][thetai].Add(2, new KeyValuePair<int, double>(boundingPolyHedrons.Count, area2));
            boundingPolyHedrons.Add(b2);
            weights.Add(GetElementsRipLeafWeight(b2Rip, b2Leaf, (double)num_RipDensity.Value, (double)num_LeafDensity.Value , (double)numC_StepLength.Value));
            
            deltaL = L1-L2-L4;
            t = deltaL/(L1-L4);

            double W2_5 = (1 - t) * W2 + t * W3;
            double T2_5 = (1 - t) * T2 + t * T3;

            BoundingPolyhedron b3Rip = new BoundingPolyhedron(b2Rip.EndPosition, axial, deltaL, W2_25, W2_5, T2_25, T2_5);
            BoundingPolyhedron b3Leaf = new BoundingPolyhedron(b2Rip.EndPosition, axial, deltaL, WL, WL, Lth, Lth);
            double area3;
            bool ch3; 
            BoundingPolyhedron b3 = DecidePolyHedron(b3Rip, b3Leaf,SL1, windDir, out ch3,out area3);
            DictLeafsPolyHedron[LevelName][thetai].Add(3, new KeyValuePair<int, double>(boundingPolyHedrons.Count, area3));
            boundingPolyHedrons.Add(b3);
            weights.Add(GetElementsRipLeafWeight(b3Rip, b3Leaf, (double)num_RipDensity.Value, (double)num_LeafDensity.Value, (double)numC_StepLength.Value));

            Vector3 axial2 = ComputeVector(Phai-DeltaPhai, thetai);
            BoundingPolyhedron b4Rip = new BoundingPolyhedron(b3Rip.EndPosition, axial2, L2, W2_5, W3, T2_5, T3);
            BoundingPolyhedron b4Leaf = new BoundingPolyhedron(b3Rip.EndPosition, axial2, L2, WL, WL, Lth, Lth);
            bool ch4;
            double area4;
            BoundingPolyhedron b4 = DecidePolyHedron(b4Rip, b4Leaf,SL1, windDir, out ch4,out area4);
            DictLeafsPolyHedron[LevelName][thetai].Add(4, new KeyValuePair<int, double>(boundingPolyHedrons.Count, area4));
            boundingPolyHedrons.Add(b4);
            weights.Add(GetElementsRipLeafWeight(b4Rip, b4Leaf, (double)num_RipDensity.Value, (double)num_LeafDensity.Value, (double)numC_StepLength.Value));


            BoundingPolyhedron b5Leaf = new BoundingPolyhedron(b4Leaf.EndPosition, axial2, System.Math.PI* WL/8, WL, WL, Lth, Lth);
            double area5 = SL2 * GeneralizedShieldingProcess.GetProjectedArea(b5Leaf, windDir,true);
            DictLeafsPolyHedron[LevelName][thetai].Add(5, new KeyValuePair<int, double>(boundingPolyHedrons.Count, area5));
            boundingPolyHedrons.Add(b5Leaf);
            weights.Add(GetElementsWeights(b5Leaf, (double)numC_StepLength.Value, (double)num_LeafDensity.Value));
            npas.Add(GetNPA(b5Leaf, SL2, windDir, (double)numC_StepLength.Value));

            _glControl.entities.Add(new GLBoundingPolyhedron(b1Rip, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b2Rip, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b3Rip, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b4Rip, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b5Leaf, System.Drawing.Color.Green));


            _glControl.entities.Add(new GLBoundingPolyhedron(b2Leaf, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b3Leaf, System.Drawing.Color.Green));
            _glControl.entities.Add(new GLBoundingPolyhedron(b4Leaf, System.Drawing.Color.Green));


            
            //_glControl.entities.Add(new GLBoundingPolyhedron(b1Rip, System.Drawing.Color.Blue));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b2Rip, ch2 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b3Rip, ch3 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b4Rip, ch4 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b5Leaf, System.Drawing.Color.Blue));


            //_glControl.entities.Add(new GLBoundingPolyhedron(b2Leaf, !ch2 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b3Leaf, !ch3 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
            //_glControl.entities.Add(new GLBoundingPolyhedron(b4Leaf, !ch4 ? System.Drawing.Color.Blue : System.Drawing.Color.Red));
  
            



        }

        private List<double> GetElementsRipLeafWeight(BoundingPolyhedron bRip, BoundingPolyhedron bLeaf, double ripDensity, double leafDensity, double elementLength)
        {
            double length  = bRip.Length;
            double N = System.Math.Ceiling( bRip.Length / elementLength);
            List<double> weights = new List<double>();
            for (int i = 0; i < N; i++)
            {
                double t0 = i * elementLength / length;
                double t1 = System.Math.Min((i + 1) * elementLength / length, 1);
                BoundingPolyhedron subBRip = bRip.SubBoundingPolyhedron(t0, t1);
                BoundingPolyhedron subBLeaf = bLeaf.SubBoundingPolyhedron(t0, t1);

                double weight = (subBLeaf.Volume - subBLeaf.DimensionBAt(.5) * subBRip.DimensionAAt(.5) * subBRip.Length) * leafDensity + subBRip.Volume * ripDensity;
                weights.Add(weight);
            }
            return weights;
        }

        private List<double> GetElementsWeights(BoundingPolyhedron b, double elementLength,double density)
        {
            double length = b.Length;
            double N = System.Math.Ceiling(b.Length / elementLength);
            List<double> weights = new List<double>();
            for (int i = 0; i < N; i++)
            {
                double t0 = i * elementLength / length;
                double t1 = System.Math.Min((i + 1) * elementLength / length, 1);
                BoundingPolyhedron subB = b.SubBoundingPolyhedron(t0, t1);
                weights.Add(subB.Volume * density);
            }
            return weights;
        }

       
        BoundingPolyhedron  DecidePolyHedron(BoundingPolyhedron bRip, BoundingPolyhedron bLeaf,double solidityRatio, Vector3 winddir,out bool FirstOrSecond,out double EArea)
        {
            double area1 = GeneralizedShieldingProcess.GetProjectedArea(bRip, winddir,true);
            double area2 = GeneralizedShieldingProcess.GetProjectedArea(bLeaf, winddir,true);
           
            if (area1 > area2)
            {
                FirstOrSecond = true;
                EArea = area1;
                npas.Add(GetNPA(bRip,bLeaf,solidityRatio,winddir,(double)numC_StepLength.Value,true));
                return bRip;
            }
            else
            {
                EArea = (area2-area1)*solidityRatio+area1;
                npas.Add(GetNPA(bRip, bLeaf, solidityRatio, winddir, (double)numC_StepLength.Value, false));
                FirstOrSecond = false;
                return bLeaf;
            }
            
        }

        private List<double> GetNPA(BoundingPolyhedron bRip, BoundingPolyhedron bLeaf, double solidityRatio, Vector3 winddir, double elementLength, bool FirstOrSecond)
        {
            List<double> ElementNpas = new List<double>();
            double length = bRip.Length;
            double N = System.Math.Ceiling(bRip.Length / elementLength);
            for (int i = 0; i < N; i++)
            {
                double t0 = i * elementLength / length;
                double t1 = System.Math.Min((i + 1) * elementLength / length, 1);
                BoundingPolyhedron subBRip = bRip.SubBoundingPolyhedron(t0, t1);
              
                double area1 = GeneralizedShieldingProcess.GetProjectedArea(subBRip, winddir, true);
                if (FirstOrSecond)
                {
                    ElementNpas.Add(area1);
                }
                else
                {
                    BoundingPolyhedron SubbLeaf = bLeaf.SubBoundingPolyhedron(t0, t1);
                    double area2 = GeneralizedShieldingProcess.GetProjectedArea(SubbLeaf, winddir, true);
                    ElementNpas.Add((area2 - area1) * solidityRatio + area1);
                }
            }
            return ElementNpas;
        }

        private List<double> GetNPA(BoundingPolyhedron b, double solidityRatio, Vector3 winddir, double elementLength)
        {
            List<double> ElementNpas = new List<double>();
            double length = b.Length;
            double N = System.Math.Ceiling(b.Length / elementLength);
            for (int i = 0; i < N; i++)
            {
                double t0 = i * elementLength / length;
                double t1 = System.Math.Min((i + 1) * elementLength / length, 1);
                BoundingPolyhedron subB  = b.SubBoundingPolyhedron(t0, t1);

                double area = GeneralizedShieldingProcess.GetProjectedArea(subB, winddir, true);
                ElementNpas.Add(solidityRatio*area);
            }
            return ElementNpas;

        }

        

        static Vector3 ComputeVector(double Phai, double Theta)
        {
            return new Vector3(System.Math.Cos(Theta) * System.Math.Cos(Phai), System.Math.Sin(Theta) * System.Math.Cos(Phai), System.Math.Sin(Phai));
        }

        private void AddAntennaAndPipes()
        {
            palmTreeData.PipesAndAnglesSpecs.Clear();
            DictAntennaAndPipes.Clear();
             Vector3 windDir = new Vector3((double)numC_WindX.Value, (double)numC_WindY.Value, (double)numC_WindZ.Value);
             palmTreeData.PipesAndAnglesSpecs.Clear();
            for (int i = 0; i < dgV_PipesAntennas.Rows.Count; i++)
            {
                    string name = (string)dgV_PipesAntennas.Rows[i].Cells["Name"].Value;
                    if (name == null)
                        continue;
                    double W = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["W"].Value);
                    double L = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["L"].Value);
                    double T = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["T"].Value);
                    double R = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["Radius"].Value);
                    double Z = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["Elev"].Value);
                    double TwistAngle = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["TwistAngle"].Value)* System.Math.PI/180;
                    double Orientation = double.Parse((string)dgV_PipesAntennas.Rows[i].Cells["Orientation"].Value) * System.Math.PI / 180;
                    palmTreeData.PipesAndAnglesSpecs.Add(new PipeAndAngleSpecs(name,Z,W,T,L,R,Orientation,TwistAngle));
                
                    int index = boundingPolyHedrons.Count;
                    Vector3 startPos = new Vector3(R * System.Math.Cos(Orientation), R * System.Math.Sin(Orientation), Z);
                    orientations.Add(TwistAngle);


                    BoundingPolyhedron b = new BoundingPolyhedron(startPos, new Vector3(0, 0, 1), L, T, T, W, W, TwistAngle);
                    boundingPolyHedrons.Add(b);
                    weights.Add(GetElementsWeights(b,(double)numC_StepLength.Value,PipesAntennaDensity()));
                    npas.Add(GetNPA(b, 1, windDir, (double)numC_StepLength.Value));
                    if (name.ToUpper()[0] == 'P')
                    {

                        _glControl.entities.Add(new GLBoundingPolyhedron(boundingPolyHedrons[boundingPolyHedrons.Count - 1], System.Drawing.Color.FromArgb(132,66,0 )));
                    }
                else
                        if (name.ToUpper()[0] == 'A')
                        {

                            _glControl.entities.Add(new GLBoundingPolyhedron(boundingPolyHedrons[boundingPolyHedrons.Count - 1], System.Drawing.Color.White));
                        }
                        else
                        {
                            _glControl.entities.Add(new GLBoundingPolyhedron(boundingPolyHedrons[boundingPolyHedrons.Count - 1], System.Drawing.Color.Blue));
 
                        }
                    DictAntennaAndPipes.Add(name, index);
               
            }
        }

        private double PipesAntennaDensity()
        {
            return 1000;
        }
        GeneralizedShieldingResult shr;
        private void button2_Click(object sender, EventArgs e)
        {
            LoadWindData();
            if (boundingPolyHedrons.Count != 0)
            {
                CalculateConstants();
                _glControl.entities.Clear();
                Vector3 windDir = new Vector3((double)numC_WindX.Value, (double)numC_WindY.Value, (double)numC_WindZ.Value);
                shP = new GeneralizedShieldingProcess(boundingPolyHedrons, (double)numC_StepLength.Value, 0,true);
                shr = shP.StartShielding(windDir);
               DGV_LeafsResults.Rows.Clear();
               DGV_PipesAntennaResults.Rows.Clear();
               shapeFactors.Clear();
                foreach(KeyValuePair<string,int> kvPair in DictAntennaAndPipes)
                {
                    
                    int rowIndex =  DGV_PipesAntennaResults.Rows.Add();
                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[0].Value = kvPair.Key;
                    int resIndex =  kvPair.Value;
                   
                    double D = shr.Ds[resIndex];
                    double Z = .5 * boundingPolyHedrons[resIndex].StartPosition.Z + .5 * boundingPolyHedrons[resIndex].EndPosition.Z;
                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[1].Value = shr.ShieldingFactors[resIndex];
                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[2].Value = shr.ProjectedAreas[resIndex];
                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[3].Value = Z;
                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[4].Value = D;

                    double Kz = 2.01 * System.Math.Pow(Z / Zg, 2.0 / Alpha);
                    Kz = Kz >= 2.01 ? 2.01 : Kz <= KZmin ? KZmin : Kz;
                    double qz = .613 * V * V * I * Kz * Kd; //show it

                    DGV_PipesAntennaResults.Rows[rowIndex].Cells[5].Value = qz;
                    _glControl.entities.Add(new GLBoundingPolyhedron(boundingPolyHedrons[resIndex], DecideColor(shr.ShieldingFactors[resIndex])));
                   
                }

                double sumF = 0;
                double sumM = 0;
                double ManualShapeFactor = (double)num_ShapeFactor.Value;
                foreach (KeyValuePair<string, Dictionary<double, Dictionary<int, KeyValuePair<int, double>>>> kvLevel in DictLeafsPolyHedron)
                {
                    string levelname = kvLevel.Key;
                   
                    foreach (KeyValuePair<double, Dictionary<int, KeyValuePair<int, double>>> kvBranch in kvLevel.Value)
                    {
                        double theta = kvBranch.Key;
                        double theta60 = theta * 180 / System.Math.PI;
                        if (theta60 >= 360) theta60 -= 360;

                        int p3ResIndex = kvBranch.Value[3].Key;
                        double D = shr.Ds[p3ResIndex];
                        //c calcuations
                        double aspectRatio = (L1) / D;

                        //Show shape factor
                        double ShapeFactor ;

                        if (rdo_auto.Checked)
                            ShapeFactor = aspectRatio < 2.5 ? 1.2 : aspectRatio > 25 ? 2 : aspectRatio > 2.5 && aspectRatio < 7 ? ((aspectRatio - 2.5) / 4.5 * .2 + 1.2) : ((aspectRatio - 7) / 18 * .6 + 1.4);
                        else
                            ShapeFactor = ManualShapeFactor;
               
                        foreach (KeyValuePair<int, KeyValuePair<int, double>> kvPart in kvBranch.Value)
                        {
                            shapeFactors.Add(ShapeFactor);
                            int rowIndex = DGV_LeafsResults.Rows.Add();
                            double partNo = kvPart.Key;
                            int resIndex = kvPart.Value.Key;
                            double npa = kvPart.Value.Value;
                           
                            double Z = .5 * boundingPolyHedrons[resIndex].StartPosition.Z + .5 * boundingPolyHedrons[resIndex].EndPosition.Z;
                            DGV_LeafsResults.Rows[rowIndex].Cells[0].Value = levelname;
                            
                            DGV_LeafsResults.Rows[rowIndex].Cells[1].Value = theta60;
                            DGV_LeafsResults.Rows[rowIndex].Cells[2].Value = partNo;
                            DGV_LeafsResults.Rows[rowIndex].Cells[3].Value = System.Math.Round(shr.ShieldingFactors[resIndex], 3);
                            DGV_LeafsResults.Rows[rowIndex].Cells[4].Value = System.Math.Round(shr.ProjectedAreas[resIndex], 3);
                            DGV_LeafsResults.Rows[rowIndex].Cells[5].Value = System.Math.Round(npa, 3);
                            DGV_LeafsResults.Rows[rowIndex].Cells[6].Value = Z;
                            DGV_LeafsResults.Rows[rowIndex].Cells[7].Value = D;

                            //q calcuations
                            double Kz = 2.01 * System.Math.Pow(Z / Zg, 2.0 / Alpha);
                            Kz = Kz >= 2.01 ? 2.01 : Kz <= KZmin ? KZmin : Kz;
                            double qz = .613 * V * V * I * Kz * Kd; //show it

                           
                            //show F
                            double F = shr.ShieldingFactors[resIndex] * ShapeFactor * npa * qz * Gh;
                            sumF += F;

                            //show M
                            double M = F * Z;
                            sumM += M;

                            DGV_LeafsResults.Rows[rowIndex].Cells[8].Value = qz;
                            DGV_LeafsResults.Rows[rowIndex].Cells[9].Value = ShapeFactor;
                            DGV_LeafsResults.Rows[rowIndex].Cells[10].Value = F;
                            DGV_LeafsResults.Rows[rowIndex].Cells[11].Value = M;
                            _glControl.entities.Add(new GLBoundingPolyhedron(boundingPolyHedrons[resIndex], DecideColor(shr.ShieldingFactors[resIndex])));
                        }
                    }
                }
                numC_sumF.Value = (decimal)sumF/1000;
                numC_sumM.Value = (decimal)sumM/1000;

            }
            _glControl.Refresh();
        }

        private void CalculateConstants()
        {
            switch (cmb_Class.SelectedIndex)
            { 
                case 0://I
                    I = .87;
                    break;
                case 1://II
                    I = 1.0;
                    break;
                case 2://III
                    I = 1.15;
                    break;

            }


            switch (cmb_Category.SelectedIndex)
            {
                case 0://B
                    KZmin = .7;
                    Alpha = 7.0;
                    Zg = 366;
                    break;
                case 1://C
                    KZmin = .85;
                    Alpha = 9.5;
                    Zg = 274;
                    break;
                case 2://D
                    KZmin = 1.03;
                    Alpha = 11.5;
                    Zg = 213;
                    break;

            }

                    
            // Structure Data
            V = (double)num_V.Value;
            Kd = (double)num_Kd.Value;
            Gh = (double)num_Gh.Value;
          
        }

        ColorInterPolator ci = new ColorInterPolator(new List<Color>() { Color.White, Color.White, Color.White, Color.White, Color.Red, Color.Red, Color.Yellow, Color.Yellow, Color.FromArgb(0, 255, 255), Color.FromArgb(0, 255, 255),Color.Green });
        private Color DecideColor(double shieldingFactor)
        {
            return ci.GetInterpolatedColor(System.Math.Floor(shieldingFactor * 10) / 10);
           
        }

        private void dgV_LevelSpecs_KeyDown(object sender, KeyEventArgs e)
        {
            AddLines(e, dgV_LevelSpecs);
        }


        public void AddLines(KeyEventArgs e,DataGridView datagridView )
        {
            if (e.Control && e.KeyCode == Keys.C)
            {
                DataObject d = datagridView.GetClipboardContent();
                Clipboard.SetDataObject(d);
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.V)
            {
                string s = Clipboard.GetText();
                string[] lines = s.Split('\n');
                int row = datagridView.CurrentCell.RowIndex;
                int col = datagridView.CurrentCell.ColumnIndex;
                foreach (string line in lines)
                {
                    if (row >= datagridView.RowCount)
                    {
                        datagridView.Rows.Add();
                    }

                    if (row < datagridView.RowCount && line.Length > 0)
                    {
                        string[] cells = line.Split('\t');
                        for (int i = 0; i < cells.GetLength(0); ++i)
                        {
                            if (col + i <
this.dgV_LevelSpecs.ColumnCount)
                            {
                                datagridView[col + i, row].Value =
Convert.ChangeType(cells[i], datagridView[col + i, row].ValueType);
                            }
                            else
                            {
                                break;
                            }
                        }
                        row++;
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        private void dgV_PipesAntennas_KeyDown(object sender, KeyEventArgs e)
        {
            AddLines(e, dgV_PipesAntennas);
        }

        private void rdo_manual_CheckedChanged(object sender, EventArgs e)
        {
            if (rdo_manual.Checked)
            {
                num_ShapeFactor.Enabled = true;
            }
            else
            {
                num_ShapeFactor.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadWindData();
            LoadLeafDesignSpecs();
            Vector3 windDir = new Vector3((double)numC_WindX.Value, (double)numC_WindY.Value, (double)numC_WindZ.Value);
            PalmTreeBranchAnalyzer analyzer = new PalmTreeBranchAnalyzer( shP,shr, DictLeafsPolyHedron, (double)num_RipDensity.Value,
                (double)num_LeafDensity.Value, weights, npas, shapeFactors, (double)num_ShieldingFactor.Value);
            analyzer.AutoOrManual = rdo_shFAuto.Checked ;
            DGV_AnalysisResults.Rows.Clear();
            DGV_Branches_Results.Rows.Clear();
            AnalysisResults totalanalysisResults  = analyzer.PerformAnalysis(windDir, (double)num_XDist.Value, (double)num_MyC.Value, (double)num_MzC.Value, (double)num_WeightFactor.Value, (double)num_WindFactor.Value, Zg, Alpha, KZmin, V, I, Kd, Gh);

            List<List<AnalysisElementResult>> analysisElementResults = totalanalysisResults.AnalysisElementResults;

            List<AnalysisBranchResult> branchResults = totalanalysisResults.AnalysisBranchResults;
            int brIndex = 0;
            foreach (KeyValuePair<string, Dictionary<double, Dictionary<int, KeyValuePair<int, double>>>> kvLevel in DictLeafsPolyHedron)
            {
                string levelname = kvLevel.Key;

                foreach (KeyValuePair<double, Dictionary<int, KeyValuePair<int, double>>> kvBranch in kvLevel.Value)
                {
                    double theta = kvBranch.Key;
                    double theta60 = theta * 180 / System.Math.PI;
                    if (theta60 >= 360) theta60 -= 360;

                    int BrRowIndex =DGV_Branches_Results.Rows.Add();
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[0].Value = levelname;
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[1].Value = theta60;
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[2].Value = System.Math.Round( branchResults[brIndex].WeightF,1);
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[3].Value = System.Math.Round( branchResults[brIndex].WindF,1);
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[4].Value = System.Math.Round( branchResults[brIndex].NPA,3);
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[5].Value =  System.Math.Round(branchResults[brIndex].M.X,1).ToString();
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[6].Value = System.Math.Round(branchResults[brIndex].M.Y,1).ToString();
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[7].Value = System.Math.Round(branchResults[brIndex].M.Z,1).ToString();
                    DGV_Branches_Results.Rows[BrRowIndex].Cells[8].Value = System.Math.Round(branchResults[brIndex].UtilizationFactor,3);
                    brIndex++;
                    foreach (KeyValuePair<int, KeyValuePair<int, double>> kvPart in kvBranch.Value)
                    {
                        double partNo = kvPart.Key;
                        int segmentIndex = kvPart.Value.Key;
  

                        List<AnalysisElementResult> segmentResult =analysisElementResults[segmentIndex];

                        for (int i = 0; i < segmentResult.Count; i++)
                        {
                            int rowIndex = DGV_AnalysisResults.Rows.Add();

                            DGV_AnalysisResults.Rows[rowIndex].Cells[0].Value = levelname;
                            DGV_AnalysisResults.Rows[rowIndex].Cells[1].Value = theta60;
                            DGV_AnalysisResults.Rows[rowIndex].Cells[2].Value = partNo;
                            DGV_AnalysisResults.Rows[rowIndex].Cells[3].Value = segmentResult[i].ElementIndex;
                            DGV_AnalysisResults.Rows[rowIndex].Cells[4].Value = System.Math.Round(npas[segmentIndex][i], 3);
                            DGV_AnalysisResults.Rows[rowIndex].Cells[5].Value = System.Math.Round(segmentResult[i].ShieldingFactor, 3);
                            DGV_AnalysisResults.Rows[rowIndex].Cells[6].Value = System.Math.Round(segmentResult[i].WindF, 1);
                            DGV_AnalysisResults.Rows[rowIndex].Cells[7].Value = System.Math.Round(segmentResult[i].WeightF, 1);
                        
                            Vector3 RoundedMoment = new Vector3(
                                System.Math.Round(segmentResult[i].M.X, 1),
                                System.Math.Round(segmentResult[i].M.Y, 1),
                                System.Math.Round(segmentResult[i].M.Z, 1));

                            DGV_AnalysisResults.Rows[rowIndex].Cells[8].Value = RoundedMoment.ToString();
                            //DGV_AnalysisResults.Rows[rowIndex].Cells[8].Value = segmentResult[i].UtilizationFactor;
                        
                        }
                    }
                }
            }

            num_MaxUF.Value = (decimal)totalanalysisResults.MaximumBranchUtilizationFactor; 
        }
    }
}
