﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using SoftoriaPole.Geometry.Utils;
using MainProgram;
using GpcWrapper;
using System.Drawing.Drawing2D;
using System.Collections;
using SoftoriaPole.Utilities;

namespace SoftoriaPole.Geometry
{
    [Serializable]
    public class KiAreaiComparer : IComparer<KeyValuePair<List<ConvexPolygon>, double>>
    {
        #region IComparer<KeyValuePair<List<ConvexPolygon>,double>> Members

        public int Compare(KeyValuePair<List<ConvexPolygon>, double> x, KeyValuePair<List<ConvexPolygon>, double> y)
        {
            return x.Value.CompareTo(y.Value);

        }

        #endregion
    }
    public class GeneralizedShieldingResult
    {


        public GeneralizedShieldingResult(List<double> shieldingFactors,List<double> projectedAreas,List<double> ds)
        {

            _shieldingFactors = shieldingFactors;
            _ProjectedAreas = projectedAreas;
            _Ds = ds;
        }

        public GeneralizedShieldingResult(List<double> shieldingFactors, List<List<double>> elementsShieldingFactors, List<double> projectedAreas, List<double> ds)
            : this(shieldingFactors, projectedAreas, ds)
        {
            _elementsShieldingFactors = elementsShieldingFactors;
        }
        private List<double> _shieldingFactors = new List<double>();

        public List<double> ShieldingFactors
        {
            get { return _shieldingFactors; }
        }


        private List<List<double>> _elementsShieldingFactors = new List<List<double>>();

        public List<List<double>> ElementsShieldingFactors
        {
            get { return _elementsShieldingFactors; }
            set { _elementsShieldingFactors = value; }
        }

       
        private List<double> _ProjectedAreas = new List<double>();

        public List<double> ProjectedAreas
        {
            get { return _ProjectedAreas; }
        }


        List<double> _Ds = new List<double>();

        public List<double> Ds
        {
            get { return _Ds; }
        }

    }

    [Serializable]
    public class GeneralizedShieldingProcess
    {
        bool _IgnoreBases = false;

        public bool IgnoreBases
        {
            get { return _IgnoreBases; }
            set { _IgnoreBases = value; }
        }
        private double _stepLength;

        public double StepLength
        {
            get { return _stepLength; }
        }
        private List<BoundingPolyhedron> _segmentBoundingPolyhedron = new List<BoundingPolyhedron>();
        private List<Vector3> _LocalAxisX = new List<Vector3>();

        public List<Vector3> LocalAxisX
        {
            get { return _LocalAxisX; }
        }
        private List<Vector3> _LocalAxisY = new List<Vector3>();

        public List<Vector3> LocalAxisY
        {
            get { return _LocalAxisY; }
        }
        private List<Vector3> _LocalAxisZ = new List<Vector3>();

        public List<Vector3> LocalAxisZ
        {
            get { return _LocalAxisZ; }
        }
        private List<List<BoundingPolyhedron>> _partionedSegmentBoundingPolyhedron = new List<List<BoundingPolyhedron>>();


        /// <summary>
        /// Elements of each segment as list of Bounding Polyhedrons
        /// </summary>
        public List<List<BoundingPolyhedron>> SegmentElements
        {
            get { return _partionedSegmentBoundingPolyhedron; }
            set { _partionedSegmentBoundingPolyhedron = value; }
        }
       
        

        public List<BoundingPolyhedron> SegmentBoundingPolyhedron
        {
            get { return _segmentBoundingPolyhedron; }
        } 

        #region Dependent on WindDirection

        List<double> _Ds = new List<double>();
        private List<ProjectionInfo[]> _segmentProjectedPolygons = new List<ProjectionInfo[]>();
        private List<ProjectionInfo> _baseSegmentProjectedPolygons = new List<ProjectionInfo>();

        private List<List<ProjectionInfo[]>> _partionedSegmentProjectedPolygons = new List<List<ProjectionInfo[]>>();


        private List<List<double>> _segmenttoSegmentIntersectionArea = new List<List<double>>();

        #endregion

        #region Independent of Wind Direction
       

       


        private double _minimumShieldingValue;

        public double MinimumShieldingValue
        {
            get { return _minimumShieldingValue; }
            set { _minimumShieldingValue = value; }
        }

        public GeneralizedShieldingProcess(List<BoundingPolyhedron> segmentsBoundingPolyHenrons, double steplength, double minimumShieldingValue,bool ignoreBases):this(segmentsBoundingPolyHenrons,steplength,minimumShieldingValue)
        {
            _IgnoreBases = ignoreBases;
        }
       
        public GeneralizedShieldingProcess(List<BoundingPolyhedron> segmentsBoundingPolyHenrons, double steplength, double minimumShieldingValue)
        {
            _segmentBoundingPolyhedron = segmentsBoundingPolyHenrons;
            _stepLength = steplength;
            _minimumShieldingValue = minimumShieldingValue;
            foreach (BoundingPolyhedron b in _segmentBoundingPolyhedron)
            {
                List<BoundingPolyhedron> segPartionedBoundingBox = new List<BoundingPolyhedron>(); ;
                for (double length = 0; length < b.Length; length += steplength)
                {
                    if (length + steplength < b.Length)
                    {
                        segPartionedBoundingBox.Add(b.SubBoundingPolyhedron(length / b.Length, (length + steplength) / b.Length));
                    }
                    else
                    {
                        segPartionedBoundingBox.Add(b.SubBoundingPolyhedron(length / b.Length, 1));

                    }
                }
                _partionedSegmentBoundingPolyhedron.Add(segPartionedBoundingBox);
            }
        }
      
        
        #endregion

        private void GenerateProjections(Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            int l = 0;
            foreach (BoundingPolyhedron sb in _segmentBoundingPolyhedron)
            {
                List<KeyValuePair<BoundingPolyhedronPlaneType, int>> facingPlanes = sb.GetFacingPlanes(localZ);
                List<int> indices = new List<int>();
                List<int> baseIndices = new List<int>();

                foreach (KeyValuePair<BoundingPolyhedronPlaneType, int> facingPlane in facingPlanes)
                {
                    if (facingPlane.Key == BoundingPolyhedronPlaneType.SidePlane)
                    {
                        indices.Add(facingPlane.Value);
                    }
                    else
                    {
                        baseIndices.Add(facingPlane.Value);
                    }


                }
                _segmentProjectedPolygons.Add(sb.LocalProjectTo(indices, localX, localY, localZ));
                _baseSegmentProjectedPolygons.Add(sb.LocalProjectTo(baseIndices[0], localX, localY, localZ));

                l++;
            }

            

            //fill intersection areas of sgment to segment
            for (int i = 0; i < _segmentProjectedPolygons.Count; i++)
            {
                List<double> intersectionAreas = new List<double>();
                for (int j = 0; j < _segmentProjectedPolygons.Count; j++)
                {
                    double area = 0;

                    if (i != j)
                    {
                        area += ConvexPolygon.IntersectingArea(_segmentProjectedPolygons[i][0].Polygon,
                            _segmentProjectedPolygons[j][0].Polygon);

                        area += ConvexPolygon.IntersectingArea(_segmentProjectedPolygons[i][0].Polygon,
                           _segmentProjectedPolygons[j][1].Polygon);

                        area += ConvexPolygon.IntersectingArea(_segmentProjectedPolygons[i][1].Polygon,
                           _segmentProjectedPolygons[j][0].Polygon);

                        area += ConvexPolygon.IntersectingArea(_segmentProjectedPolygons[i][1].Polygon,
                           _segmentProjectedPolygons[j][1].Polygon);
                    }
                    else
                    {
                        area = _segmentProjectedPolygons[i][0].Polygon.Area + _segmentProjectedPolygons[i][1].Polygon.Area;
                    }

                    intersectionAreas.Add(area);
                }
                _segmenttoSegmentIntersectionArea.Add(intersectionAreas);
            }

           


            //project partioned segments
            foreach (List<BoundingPolyhedron> listPartsb in _partionedSegmentBoundingPolyhedron)
            {
                List<ProjectionInfo[]> segmentPartionsProjections = new List<ProjectionInfo[]>();
                foreach (BoundingPolyhedron partsb in listPartsb)
                {
                    List<KeyValuePair<BoundingPolyhedronPlaneType, int>> facingPlanes = partsb.GetFacingPlanes(localZ);
                    List<int> indices = new List<int>();
                    foreach (KeyValuePair<BoundingPolyhedronPlaneType, int> facingPlane in facingPlanes)
                    {
                        if (facingPlane.Key == BoundingPolyhedronPlaneType.SidePlane)
                        {
                            indices.Add(facingPlane.Value);
                        }

                    }

                    segmentPartionsProjections.Add(partsb.LocalProjectTo(indices, localX, localY, localZ));
                }
                _partionedSegmentProjectedPolygons.Add(segmentPartionsProjections);
            }


            
        }

        public GeneralizedShieldingResult StartShielding(Vector3 windDirection)
        {
            List<double> shr = new List<double>();
            List<List<double>> shrelements = new List<List<double>>();
            List<double> projectedAreas = new List<double>();
            ClearPreviousData();
            double[][] localFrame = VectorOperations.ComputeFrame(windDirection,0);
            Vector3 localx = Converter.ToVector3(localFrame[2]);
            Vector3 localy = Converter.ToVector3(localFrame[1]);
            Vector3 localz = Converter.ToVector3(localFrame[0]);

          

            GenerateProjections(localx,localy,localz);
            CalculateDs();
            for (int i = 0; i < _segmentBoundingPolyhedron.Count; i++)
            {
                _LocalAxisX.Add(_segmentBoundingPolyhedron[i].LocalX);
                _LocalAxisY.Add(_segmentBoundingPolyhedron[i].LocalY);
                _LocalAxisZ.Add(_segmentBoundingPolyhedron[i].LocalZ);

                List<double> ElementsShielding;
                shr.Add(ComputeSegmentShielding(i, windDirection, localx, localy, localz, out ElementsShielding));
                shrelements.Add(ElementsShielding);
                double area = CalculateArea(_segmentProjectedPolygons[i]);
                if(!_IgnoreBases)
                    area += _baseSegmentProjectedPolygons[i].Polygon.Area;
                projectedAreas.Add(area);
               
            }

       
            
            return new GeneralizedShieldingResult(shr, shrelements,projectedAreas, _Ds);
        }

       
        private bool isSegmentInterSectWithSegment(int segment1Index ,int segment2Index)
        {
            return _segmenttoSegmentIntersectionArea[segment1Index][segment2Index] > 0.001;
        }

       

        private double CalculateK(double x,double d)
        {
            double value = (x - 2 * d) / (2 * d);
            if (value < 0)
                return 0;
            if (value > 1)
                return 1;
            return value;
        }

        private void CalculateDs()
        {
            for (int i = 0; i < _segmentProjectedPolygons.Count; i++)
            {
                VectorD pt11 =null;
                VectorD pt12 = null;
                VectorD pt21 = null;
                VectorD pt22 = null;
                ProjectionInfo[] segPInfo = _segmentProjectedPolygons[i] ;
                bool intersected = false;
                for (int j = 0; j < segPInfo.Length; j++)
                {

                   for (int k = j+1; k < segPInfo.Length; k++)
                   {

                       for(int l = 0;l<segPInfo[j].Polygon.Count;l++)
                       {
                           VectorD ptl1 = segPInfo[j].Polygon[l];
                           VectorD ptl2 = segPInfo[j].Polygon[(l + 1) % segPInfo[j].Polygon.Count];
                           VectorD ptlmid = .5*ptl1+.5*ptl2;
                            for(int m = 0;m<segPInfo[k].Polygon.Count;m++)
                            {
                                VectorD ptm1 = segPInfo[k].Polygon[m];
                                VectorD ptm2 = segPInfo[k].Polygon[(m + 1) % segPInfo[k].Polygon.Count];
                                VectorD ptmmid = .5*ptm1+.5*ptm2;

                                VectorD dptlm = ptlmid - ptmmid;

                                if (dptlm.Magnitude < 1E-5)
                                {
                                    pt11 = segPInfo[j].Polygon[(l + 2) % segPInfo[j].Polygon.Count];
                                    pt12 = segPInfo[j].Polygon[(l + 3) % segPInfo[j].Polygon.Count];
                                    pt21 = segPInfo[k].Polygon[(m + 2) % segPInfo[k].Polygon.Count];
                                    pt22 = segPInfo[k].Polygon[(m + 3) % segPInfo[k].Polygon.Count];
                                    intersected = true;
                                    goto L4;
                                }
                            }
                       }
                   }

                }
                goto L4;
            L4:
                if (intersected)
                {
                    VectorD midpt1 = .5 * (pt11 + pt12);
                    double a, b, c;
                    GetLineEquation(pt21, pt22, out a, out b, out c);
                    double d =System.Math.Abs(GetProjectionDist(a, b, c, midpt1.X, midpt1.Y)); 
                    _Ds.Add(d);
                }
            }
 
        }

        private void GetLineEquation(VectorD pt21, VectorD pt22, out double a, out double b, out double c)
        {
            VectorD axial = pt22-pt21;
            double angle  = System.Math.Atan2(axial.Y,axial.X);

            VectorD normal = VectorD.CreateFromPolar(1, angle+System.Math.PI/2);
            a = normal.X;
            b = normal.Y;

            c = -(a * pt21.X + b * pt21.Y);
        }

        public static  double GetProjectionDist(double a,double b,double c,double ptx,double pty)
        {
            return (a * ptx + b * pty + c ) / (a * a + b * b);
        }

        private double ComputeSegmentShielding(int segmentIndex, Vector3 windDirection, Vector3 localX, Vector3 localY, Vector3 localZ,out List<double> ElementsShielding)
        {
            double shieldValue = 0;
            double totalSegmentArea = _segmenttoSegmentIntersectionArea[segmentIndex][segmentIndex];


            ElementsShielding = new List<double>();
            double sumAreai = 0;
            BoundingPolyhedron segmentBoundingPolyhedron = _segmentBoundingPolyhedron[segmentIndex];
            int partIndex = 0;
            foreach (ProjectionInfo[] pInfo in _partionedSegmentProjectedPolygons[segmentIndex])
            {

                List<KeyValuePair<List<ConvexPolygon>, double>> kshieldValues = new List<KeyValuePair<List<ConvexPolygon>, double>>();
                List<ConvexPolygon> baseProjections = new List<ConvexPolygon>();
                double areaPart = pInfo[0].Polygon.Area + pInfo[1].Polygon.Area;
                sumAreai += areaPart;
                double kpartAreaPart = areaPart;
                for (int i = 0; i < _segmentProjectedPolygons.Count; i++)
                {
                    double kpartareaparti = areaPart;//Initialize it with the maxinum value
                    if (i != segmentIndex && isSegmentInterSectWithSegment(segmentIndex, i))
                    {
                        ProjectionInfo[] segPInfo = _segmentProjectedPolygons[i];
                        //Modified at 27/7/2010 by Mohammad Hamdy
                        //Because It causes errorious results
                        //if ((pInfo[0].AverageHeight + pInfo[1].AverageHeight) / 2 > (System.Math.Max(segPInfo[0].MaximumHeight, segPInfo[1].MaximumHeight)))
                        //if (System.Math.Max(pInfo[0].MaximumHeight, pInfo[1].MaximumHeight) > (System.Math.Max(segPInfo[0].MaximumHeight, segPInfo[1].MaximumHeight)))

                        {
                            ConvexPolygon intersectPolygon1, intersectPolygon2, intersectPolygon3, intersectPolygon4;
                            double interArea1 = ConvexPolygon.IntersectingArea(pInfo[0].Polygon, segPInfo[0].Polygon, out intersectPolygon1);
                            double interArea2 = ConvexPolygon.IntersectingArea(pInfo[0].Polygon, segPInfo[1].Polygon, out intersectPolygon2);
                            double interArea3 = ConvexPolygon.IntersectingArea(pInfo[1].Polygon, segPInfo[0].Polygon, out intersectPolygon3);
                            double interArea4 = ConvexPolygon.IntersectingArea(pInfo[1].Polygon, segPInfo[1].Polygon, out intersectPolygon4);
                            
                            double interArea = interArea1 + interArea2 + interArea3 + interArea4;

                            if (interArea != 0)
                            {
                                double ds = 0;
                                VectorD midpoint = new VectorD(0, 0);
                                VectorD pointOn = new VectorD(0, 0);

                                double areaInter = 0;

                                int count = 0;
                                List<ConvexPolygon> listpolygon = new List<ConvexPolygon>();
                                if (intersectPolygon1.Count > 0)
                                {
                                    ds += intersectPolygon1.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon1);
                                    midpoint += interArea1 * intersectPolygon1.MidPoint;
                                    if (interArea1 > areaInter)
                                    {
                                        areaInter = interArea1;
                                        pointOn = intersectPolygon1.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon2.Count > 0)
                                {
                                    ds += intersectPolygon2.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon2);

                                    midpoint += interArea2 * intersectPolygon2.MidPoint;
                                    if (interArea2 > areaInter)
                                    {
                                        areaInter = interArea2;
                                        pointOn = intersectPolygon2.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon3.Count > 0)
                                {
                                    ds += intersectPolygon3.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon3);

                                    midpoint += interArea3 * intersectPolygon3.MidPoint;
                                    if (interArea3 > areaInter)
                                    {
                                        areaInter = interArea3;
                                        pointOn = intersectPolygon3.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon4.Count > 0)
                                {
                                    ds += intersectPolygon4.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon4);
                                    midpoint += interArea4 * intersectPolygon4.MidPoint;
                                    if (interArea4 > areaInter)
                                    {
                                        areaInter = interArea4;
                                        pointOn = intersectPolygon4.MidPoint;
                                    }
                                    count++;
                                }
                                ds = System.Math.Min(_segmentBoundingPolyhedron[i].DimensionAAt(.5), _segmentBoundingPolyhedron[i].DimensionBAt(.5)); //_pole.Segments[i].Diameter(0.5);
                               
                                ds = _Ds[i];
                                //ds = _pole.Segments[i].Diameter(0.5);
                                midpoint = (1.0 / interArea) * midpoint;
                                midpoint = pointOn;

                                //VectorD midpoint = 0.25*(intersectPolygon1.MidPoint+intersectPolygon2.MidPoint+intersectPolygon3.MidPoint+intersectPolygon4.MidPoint);
                                Vector3 midpoint3 = new Vector3(midpoint.X, midpoint.Y, 0);

                                Vector3 v = VectorOperations.FromLocalToGlobal(midpoint3, localX, localY, localZ);

                                //v = VectorOperations.FromLocalToGlobal(midpoint3, localX, localY, localZ);
                                //double x = segmentBoundingPolyhedron.TraceRay(v ,windDirection);
                                //double x = (pInfo[0].AverageHeight + pInfo[1].AverageHeight) / 2 - segmentBoundingPolyhedron.TraceRay(v, windDirection);
                                double x1 = _partionedSegmentBoundingPolyhedron[segmentIndex][partIndex].TraceMinRay(v, windDirection);

                                //double x2 = segmentBoundingPolyhedron.TraceRay(v, windDirection);
                                double x2 = _segmentBoundingPolyhedron[i].TraceRay(v, windDirection);
                                double x = x1 - x2;
                               
                                if (x < 0)
                                {
                                    continue;
                                }
                                //double ratio = area;
                                double ki = CalculateK(x, ds);

                                kshieldValues.Add(new KeyValuePair<List<ConvexPolygon>, double>(listpolygon, ki));
                                baseProjections.Add(_baseSegmentProjectedPolygons[i].Polygon);
                                kpartareaparti = ki * interArea + (areaPart - interArea);

                            }
                        }
                    }

                    kpartAreaPart = System.Math.Min(kpartAreaPart, kpartareaparti);

                }

               
                partIndex++;

                double kpart;
                double calculatedLiAreai = CalculateKiAreaiShieldValue(kshieldValues, areaPart, baseProjections, _baseSegmentProjectedPolygons[segmentIndex].Polygon,out kpart);
                ElementsShielding.Add(kpart);
                if (segmentIndex == 1 && calculatedLiAreai != kpartAreaPart)
                {
                    int x = 1;
                }
                shieldValue += calculatedLiAreai;
                //shieldValue += kpartAreaPart;
            }

            //return shieldValue / totalSegmentArea;
            return System.Math.Max(shieldValue / sumAreai, _minimumShieldingValue);
        }

        private double ComputeSegmentShieldingOld(int segmentIndex,Vector3 windDirection,Vector3 localX,Vector3 localY,Vector3 localZ)
        {
            double shieldValue = 0;
            double totalSegmentArea = _segmenttoSegmentIntersectionArea[segmentIndex][segmentIndex];

            

            double sumAreai = 0;
            BoundingPolyhedron segmentBoundingPolyhedron =  _segmentBoundingPolyhedron[segmentIndex];
            int partIndex = 0;
            foreach (ProjectionInfo[] pInfo in _partionedSegmentProjectedPolygons[segmentIndex])
            {

                List<KeyValuePair< List<ConvexPolygon>, double>> kshieldValues = new List<KeyValuePair< List<ConvexPolygon>, double>>();
                List<ConvexPolygon> baseProjections = new List<ConvexPolygon>();
                double areaPart = pInfo[0].Polygon.Area + pInfo[1].Polygon.Area;
                sumAreai += areaPart; 
                double kpartAreaPart = areaPart; 
                for (int i = 0; i < _segmentProjectedPolygons.Count; i++)
                {
                    double kpartareaparti= areaPart;//Initialize it with the maxinum value
                    if (i != segmentIndex && isSegmentInterSectWithSegment(segmentIndex, i))
                    {
                        ProjectionInfo[] segPInfo = _segmentProjectedPolygons[i];
                        //Modified at 27/7/2010 by Mohammad Hamdy
                        //
                        //if ((pInfo[0].AverageHeight + pInfo[1].AverageHeight) / 2 > (System.Math.Max(segPInfo[0].MaximumHeight, segPInfo[1].MaximumHeight)))
                        //if (System.Math.Max(pInfo[0].MaximumHeight, pInfo[1].MaximumHeight) > (System.Math.Max(segPInfo[0].MaximumHeight, segPInfo[1].MaximumHeight)))
                        
                        {
                            ConvexPolygon intersectPolygon1, intersectPolygon2, intersectPolygon3, intersectPolygon4;
                            double interArea1 = ConvexPolygon.IntersectingArea(pInfo[0].Polygon, segPInfo[0].Polygon, out intersectPolygon1);
                            double interArea2 = ConvexPolygon.IntersectingArea(pInfo[0].Polygon, segPInfo[1].Polygon, out intersectPolygon2);
                            double interArea3 = ConvexPolygon.IntersectingArea(pInfo[1].Polygon, segPInfo[0].Polygon, out intersectPolygon3);
                            double interArea4 = ConvexPolygon.IntersectingArea(pInfo[1].Polygon, segPInfo[1].Polygon, out intersectPolygon4);
                            double interArea = interArea1+interArea2+interArea3+interArea4;
                            
                            if (interArea != 0)
                            {
                                double ds= 0;
                                VectorD midpoint =  new VectorD(0,0);
                                VectorD pointOn = new VectorD(0, 0);

                                double areaInter = 0;

                                int count = 0;
                                List<ConvexPolygon> listpolygon =  new List<ConvexPolygon>();
                                if (intersectPolygon1.Count > 0)
                                {
                                    ds += intersectPolygon1.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon1);
                                    midpoint += interArea1*intersectPolygon1.MidPoint;
                                    if (interArea1 > areaInter)
                                    {
                                        areaInter = interArea1;
                                        pointOn = intersectPolygon1.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon2.Count > 0)
                                {
                                    ds += intersectPolygon2.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon2);

                                    midpoint += interArea2* intersectPolygon2.MidPoint;
                                    if (interArea2 > areaInter)
                                    {
                                        areaInter = interArea2;
                                        pointOn = intersectPolygon2.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon3.Count > 0)
                                {
                                    ds += intersectPolygon3.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon3);

                                    midpoint += interArea3 * intersectPolygon3.MidPoint;
                                    if (interArea3 > areaInter)
                                    {
                                        areaInter = interArea3;
                                        pointOn = intersectPolygon3.MidPoint;
                                    }
                                    count++;
                                }
                                if (intersectPolygon4.Count > 0)
                                {
                                    ds += intersectPolygon4.BoundingRectangleSize.DimensionB;
                                    listpolygon.Add(intersectPolygon4);
                                    midpoint += interArea4 * intersectPolygon4.MidPoint;
                                    if (interArea4 > areaInter)
                                    {
                                        areaInter = interArea4;
                                        pointOn = intersectPolygon4.MidPoint;
                                    }
                                    count++;
                                }
                                ds = ds = System.Math.Min(_segmentBoundingPolyhedron[i].DimensionAAt(.5), _segmentBoundingPolyhedron[i].DimensionBAt(.5)); //_pole.Segments[i].Diameter(0.5);
                                midpoint =  (1.0/interArea)*midpoint;
                                midpoint = pointOn;

                                //VectorD midpoint = 0.25*(intersectPolygon1.MidPoint+intersectPolygon2.MidPoint+intersectPolygon3.MidPoint+intersectPolygon4.MidPoint);
                                Vector3 midpoint3 = new Vector3(midpoint.X,midpoint.Y,0);

                                Vector3 v = VectorOperations.FromLocalToGlobal(midpoint3, localX, localY, localZ);

                                //v = VectorOperations.FromLocalToGlobal(midpoint3, localX, localY, localZ);
                                //double x = segmentBoundingPolyhedron.TraceRay(v ,windDirection);
                                //double x = (pInfo[0].AverageHeight + pInfo[1].AverageHeight) / 2 - segmentBoundingPolyhedron.TraceRay(v, windDirection);
                                double x1 = _partionedSegmentBoundingPolyhedron[segmentIndex][partIndex].TraceRay(v, windDirection);
                                
                                //double x2 = segmentBoundingPolyhedron.TraceRay(v, windDirection);
                                double x2 = _segmentBoundingPolyhedron[i].TraceRay(v, windDirection);
                                double x = x1 - x2;
                                if (i == 9)
                                {
                                    int gfgfgf = 0;
                                }
                                if (x < 0)
                                {
                                    continue;                                
                                }
                                //double ratio = area;
                                double ki = CalculateK(x,ds);

                                kshieldValues.Add(new KeyValuePair<List<ConvexPolygon>,double>( listpolygon, ki));
                                baseProjections.Add(_baseSegmentProjectedPolygons[i].Polygon);
                                kpartareaparti = ki * interArea + (areaPart - interArea);

                            }
                        }
                    }
                    
                    kpartAreaPart = System.Math.Min(kpartAreaPart, kpartareaparti);

                }

               
                partIndex++;

                double kpart;
                double calculatedLiAreai = CalculateKiAreaiShieldValue(kshieldValues, areaPart, baseProjections, _baseSegmentProjectedPolygons[segmentIndex].Polygon, out kpart);
                if (segmentIndex == 1 && calculatedLiAreai != kpartAreaPart)
                {
                    int x = 1;
                }
                shieldValue += calculatedLiAreai;
                //shieldValue += kpartAreaPart;
            }

            //return shieldValue / totalSegmentArea;
            return System.Math.Max( shieldValue / sumAreai,_minimumShieldingValue);
        }

        private double CalculateKiAreaiShieldValue(List<KeyValuePair< List<ConvexPolygon>, double>> kshieldValuesList,double partArea,List<ConvexPolygon> baseProjectionsList,ConvexPolygon baseProjectionI,out double kpart)
        {
            if (kshieldValuesList.Count == 0)
            {
                kpart = 1;
                return partArea;
            }
            List<int> indices = new List<int>();
            KeyValuePair<List<ConvexPolygon>, double>[] kshieldValues = kshieldValuesList.ToArray();
            ConvexPolygon[] baseProjections = baseProjectionsList.ToArray();
            KiAreaiComparer kiAreaiComparer = new KiAreaiComparer();

            Array.Sort(kshieldValues, baseProjections, kiAreaiComparer);

            //kshieldValues.Sort(kiAreaiComparer);
            List<double> ki = new List<double>();
            List<double> areai = new List<double>();

            //double area = 0;
            //foreach(ConvexPolygon polygon in kshieldValues[0].Key)
            //{
            //    area+=polygon.Area;
            //}
            //ki.Add(kshieldValues[0].Value);
            //areai.Add(area);

            for (int i = 0; i < kshieldValuesList.Count; i++)
            {

                if (kshieldValues[i].Value != 1)
                {
                    Polygon accumulatedPolygon = new Polygon();


                    foreach (ConvexPolygon polygon in kshieldValues[i].Key)
                    {
                        accumulatedPolygon.AddContour(polygon.ToVertexList(), false);

                    }
                    bool breakIt  = false;
                    for (int j = 0; j < i; j++)
                    {

                        foreach (ConvexPolygon polygon1 in kshieldValues[j].Key)
                        {

                            accumulatedPolygon = accumulatedPolygon.Clip(GpcOperation.Difference, polygon1.ToPolygon());
                            if (accumulatedPolygon.Contour == null)
                            {
                                breakIt = true;
                                break;
                            }
                        }

                        if (breakIt)
                        {
                            break;
                        }
                        if (!IgnoreBases)
                        {
                            accumulatedPolygon = accumulatedPolygon.Clip(GpcOperation.Difference, baseProjections[j].ToPolygon());
                            if (accumulatedPolygon.Contour == null)
                            {
                                breakIt = true;
                                break;
                            }
                        }

                    }
                    if (breakIt == false && !_IgnoreBases)
                    {
                        accumulatedPolygon = accumulatedPolygon.Clip(GpcOperation.Difference, baseProjections[i].ToPolygon());
                        if (accumulatedPolygon.Contour == null)
                        {
                            accumulatedPolygon = accumulatedPolygon.Clip(GpcOperation.Difference, baseProjectionI.ToPolygon());
                            
                        }
                    }

                    double areaK = PolygonUtils.Area(accumulatedPolygon);
                    ki.Add(kshieldValues[i].Value);
                    areai.Add(areaK);
                }
                else
                    break;
              
            }

            double summationArea = 0;
            double sumKiAreai = 0;
            for(int i = 0;i<ki.Count;i++)
            {
                summationArea+=areai[i];
                sumKiAreai +=ki[i]*areai[i];
            }
            sumKiAreai += (partArea - summationArea);
            kpart = sumKiAreai / partArea;
            if (sumKiAreai < 0)
                return 0;
            return sumKiAreai;
        }



      
        private void ClearPreviousData()
        {
            _segmentProjectedPolygons.Clear();
            _partionedSegmentProjectedPolygons.Clear();
            _segmenttoSegmentIntersectionArea.Clear();
            _Ds.Clear();
        }
        public static double GetProjectedArea(BoundingPolyhedron b, Vector3 winddir)
        {
            return GetProjectedArea(b, winddir, false);
        }
        public static double GetProjectedArea(BoundingPolyhedron b, Vector3 winddir,bool ignoreFacingPlates)
        {
            double[][] localFrame = VectorOperations.ComputeFrame(winddir, 0);
            Vector3 localX = Converter.ToVector3(localFrame[2]);
            Vector3 localY = Converter.ToVector3(localFrame[1]);
            Vector3 localZ = Converter.ToVector3(localFrame[0]);

            List<KeyValuePair<BoundingPolyhedronPlaneType, int>> facingPlanes = b.GetFacingPlanes(localZ);
            List<int> indices = new List<int>();
            List<int> baseIndices = new List<int>();

            foreach (KeyValuePair<BoundingPolyhedronPlaneType, int> facingPlane in facingPlanes)
            {
                if(!ignoreFacingPlates || facingPlane.Key == BoundingPolyhedronPlaneType.SidePlane)
                    indices.Add(facingPlane.Value);
            }

           
            ProjectionInfo[] Pis = b.LocalProjectTo(indices, localX, localY, localZ);
            return CalculateArea(Pis);
           

        }

        private static double CalculateArea(ProjectionInfo[] Pis)
        {
            double area = 0;
            for (int i = 0; i < Pis.Length; i++)
            {
                area += Pis[i].Polygon.Area;
            }
            return area;
        }
    }
}
