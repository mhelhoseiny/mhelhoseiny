﻿using System;
using System.Collections.Generic;
using System.Text;
using MainProgram.Projects.Analysis;

namespace MainProgram.App_Classes
{
    [Serializable]
    public class PalmTreeData
    {
        public PalmTreeData()
        {
 
        }
        public PalmTreeData(BranchSpecs bSpecs, List<LevelSpecs> levels, List<PipeAndAngleSpecs> pipesAndAngleSPecs, WindInfo windInfo)
        {
            _branchSpecs = bSpecs;
            _branchLevelSpecs = levels;
            _pipesAndAnglesSpecs = pipesAndAngleSPecs;
        }
        BranchSpecs _branchSpecs;

        public BranchSpecs BranchSpecs
        {
            get { return _branchSpecs; }
            set { _branchSpecs = value; }
        }

        List<LevelSpecs> _branchLevelSpecs = new List<LevelSpecs>();

        public List<LevelSpecs> BranchLevelSpecs
        {
            get { return _branchLevelSpecs; }
            set { _branchLevelSpecs = value; }
        }        

        private List<PipeAndAngleSpecs> _pipesAndAnglesSpecs = new List<PipeAndAngleSpecs>();

        public List<PipeAndAngleSpecs> PipesAndAnglesSpecs
        {
            get { return _pipesAndAnglesSpecs; }
            set { _pipesAndAnglesSpecs = value; }
        }



        private WindInfo _windInformation;
        public WindInfo WindInformation
        {
            get { return _windInformation; }
            set { _windInformation = value; }
        }
        private LeafDesignSpecs _LeafDesignSpecs;

        public LeafDesignSpecs LeafDesignSpecifications
        {
            get { return _LeafDesignSpecs; }
            set { _LeafDesignSpecs = value; }
        }
    }
}
