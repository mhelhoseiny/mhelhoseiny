﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;

namespace MainProgram.App_Classes
{
    public enum StructureClass
    {
        I = 0,
        II=1,
        III=2
    }

    public enum ExposureCategory
    {
        B=0,
        C=1,
        D=2
    }

    public enum CalulationMode
    {
        Manual,
        Auto
    }
    [Serializable]
    public class WindInfo
    {
        public double V
        {
            get;
            set;
        }

        public StructureClass Class
        {
            get;
            set;
        }

        public ExposureCategory Category
        {
            get;
            set;
        }

        /// <summary>
        /// Gust Factor
        /// </summary>
        public double Gh
        {
            get;
            set;
        }

        /// <summary>
        /// Direction Probability Factor
        /// </summary>
        public double Kd
        {
            get;
            set;
        }


        public Vector3 WindDirection
        {
            get;
            set;
        }

        public double StepLength
        {
            get;
            set;
        }

        private double _shapeFactor;
        public double ShapeFactor
        {
            get
            {
                if(ShapeFactorMode == CalulationMode.Manual)
                    return _shapeFactor;
                throw new Exception("Shape Factor is not accessible for Auto Mode");
            }
            set
            {
                if (ShapeFactorMode == CalulationMode.Manual)
                    _shapeFactor = value;
                else
                    throw new Exception("Shape Factor can not be set for Auto Mode");
            }
        }

        public CalulationMode ShapeFactorMode
        {
            get;
            set;
        }
    }
}
