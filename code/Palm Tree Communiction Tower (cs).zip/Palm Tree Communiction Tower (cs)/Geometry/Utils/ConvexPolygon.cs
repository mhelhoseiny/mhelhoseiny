﻿using System;
using System.Collections.Generic;
using System.Text;
using GLEngine.Geometry;
using GpcWrapper;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SoftoriaPole.Geometry.Utils
{
    [Serializable]
    public class PolygonUtils
    {
        /// <summary>
        /// area of the given polygon
        /// </summary>
        /// <param name="polygon">given polygon</param>
        /// <returns>the area</returns>
        public static double Area(Polygon polygon)
        {
            if (polygon.Contour==null|| polygon.Contour.Length == 0)
                return 0;
            Tristrip ts = polygon.ToTristrip();
            double area = 0;
            foreach (VertexList vl in ts.Strip)
            {
                if (vl.Vertex.Length > 2)
                {

                   
                    for(int i = 0;i<vl.Vertex.Length-2;i++)
                    {
                        VectorD v1 = new VectorD(vl.Vertex[i].X, vl.Vertex[i].Y);
                        VectorD v2 = new VectorD(vl.Vertex[i + 1].X, vl.Vertex[i + 1].Y);
                        VectorD v3 = new VectorD(vl.Vertex[i + 2].X, vl.Vertex[i + 2].Y);

                        area += Area(v1, v2, v3);
                    }

                 
                }
            }
            return area;
        }

        /// <summary>
        /// returns area of triangle with given 3 points
        /// </summary>
        /// <param name="v1">first point</param>
        /// <param name="v2">second point</param>
        /// <param name="v3">thirds point</param>
        /// <returns>the area of the triangle</returns>
        public static double Area(VectorD v1, VectorD v2, VectorD v3)
        {
            return System.Math.Abs(((v2 - v1) ^ (v3 - v1)) / 2);
        }

    }
    [Serializable]
    public class ConvexPolygon
    {


        public VertexList ToVertexList()
        {
         
            PointF[] PointFArr = new PointF[_points.Count];
            for (int i = 0;i<_points.Count;i++)
            {
                VectorD point = _points[i];
                
                PointFArr[i] =  new PointF((float)point.X,(float)point.Y);

            }
            VertexList vl = new VertexList(PointFArr);
            return vl;
            
        }

        public Polygon ToPolygon()
        {

            PointF[] PointFArr = new PointF[_points.Count];
            for (int i = 0; i < _points.Count; i++)
            {
                VectorD point = _points[i];

                PointFArr[i] = new PointF((float)point.X, (float)point.Y);

            }
            VertexList vl = new VertexList(PointFArr);
            Polygon p = new Polygon();
            p.AddContour(vl, false);
            return p;

        }
        public ConvexPolygon(VectorD[] points)
        {
            foreach (VectorD point in points)
            {
                _points.Add(point);
            }
        }
        private static double PolygonArea(Polygon polygon)
        {
            if (polygon.Contour == null || polygon.Contour.Length == 0)
            {
                return 0;
            }
            double sum = 0;
            for (int i = 0; i < polygon.Contour[0].NofVertices - 1; i++)
            {
                Vertex vi = polygon.Contour[0].Vertex[i];
                Vertex viplus1 = polygon.Contour[0].Vertex[i + 1];
                sum += vi.X * viplus1.Y;
                sum -= vi.Y * viplus1.X;
            }
            sum += polygon.Contour[0].Vertex[polygon.Contour[0].NofVertices - 1].X * polygon.Contour[0].Vertex[0].Y;
            sum -= polygon.Contour[0].Vertex[polygon.Contour[0].NofVertices - 1].Y * polygon.Contour[0].Vertex[0].X;
            return System.Math.Abs(0.5 * sum);

        }

        public static double IntersectingArea(ConvexPolygon polygon1, ConvexPolygon polygon2)
        {
            List<VectorD> polygon1List = new List<VectorD>();
            foreach (VectorD v in polygon1._points)
            {
                polygon1List.Add(v);

            }

            List<VectorD> polygon2List = new List<VectorD>();
            foreach (VectorD v in polygon2._points)
            {
                polygon2List.Add(v);

            }
            return IntersectingArea(polygon1List, polygon2List);
        }
        public static double IntersectingArea(ConvexPolygon polygon1, ConvexPolygon polygon2,out ConvexPolygon intersectingPolygon)
        {
            List<VectorD> polygon1List = new List<VectorD>();
            foreach (VectorD v in polygon1._points)
            {
                polygon1List.Add(v);

            }

            List<VectorD> polygon2List = new List<VectorD>();
            foreach (VectorD v in polygon2._points)
            {
                polygon2List.Add(v);

            }

            if (polygon1.Area == 0 )
            {
                intersectingPolygon = polygon1;
                return 0;
            }
            else if (polygon2.Area == 0)
            {
                intersectingPolygon = polygon2;
                return 0;
            }

            return IntersectingArea(polygon1List, polygon2List, out intersectingPolygon);
 
        }
        public static double IntersectingArea(List<VectorD> polygon1, List<VectorD> polygon2,out ConvexPolygon intersectingPolygon)
        {
            Polygon pa = new Polygon();
            PointF[] points1 = new PointF[polygon1.Count];
            for (int i = 0; i < points1.Length; i++)
            {
                points1[i] = new PointF((float)polygon1[i].X, (float)polygon1[i].Y);
            }

            VertexList v1 = new VertexList(points1);
            pa.AddContour(v1, false);


            PointF[] points2 = new PointF[polygon2.Count];
            for (int i = 0; i < points1.Length; i++)
            {
                points2[i] = new PointF((float)polygon2[i].X, (float)polygon2[i].Y);
            }

            VertexList v2 = new VertexList(points2);
            Polygon pb = new Polygon();

            pb.AddContour(v2, false);
           
            Polygon polygon;
            try
            {
                polygon = pa.Clip(GpcOperation.Intersection, pb
                   );
            }
            catch (ArgumentNullException)
            {
                polygon = new Polygon();
            }
            catch (IndexOutOfRangeException)
            {
                polygon = new Polygon();
            }

            

            intersectingPolygon= new ConvexPolygon(polygon);
            return PolygonArea(polygon);

        }

        public static double IntersectingArea(List<VectorD> polygon1, List<VectorD> polygon2)
        {
            Polygon pa = new Polygon();
            PointF[] points1 = new PointF[polygon1.Count];
            for (int i = 0; i < points1.Length; i++)
            {
                points1[i] = new PointF((float)polygon1[i].X, (float)polygon1[i].Y);
            }

            VertexList v1 = new VertexList(points1);
            pa.AddContour(v1, true);


            PointF[] points2 = new PointF[polygon2.Count];
            for (int i = 0; i < points2.Length; i++)
            {
                points2[i] = new PointF((float)polygon2[i].X, (float)polygon2[i].Y);
            }

            VertexList v2 = new VertexList(points2);
            Polygon pb = new Polygon();

            pb.AddContour(v2, true);


            try
            {
                Polygon polygon = pa.Clip(GpcOperation.Intersection, pb
                   );
                return PolygonArea(polygon);
            }
            catch (ArgumentNullException)
            {
                return 0;
            }
            

        }

        public ConvexPolygon(Polygon polygon)
        {
            if (polygon.Contour!=null &&polygon.Contour.Length > 0)
            {
                for (int i = 0; i < polygon.Contour[0].NofVertices; i++)
                {
                    Vertex vi = polygon.Contour[0].Vertex[i];
                    _points.Add(new VectorD(vi.X, vi.Y));
                }
            }
 
        }

        List<VectorD> _points =  new List<VectorD>();

        public VectorD this[int index]
        {
            get
            {
                return _points[index];
            }
        }

        public int Count
        {
            get
            {
                return _points.Count;
            }
        }

        public bool PointInPolygon(VectorD point)
        {

            //PointF[] ArrPoint = new PointF[_points.Count];

            //for (int i = 0; i < _points.Count; i++)
            //{
            //    ArrPoint[_points.Count-i-1] = new PointF((float)_points[i].X, (float)_points[i].Y);
            //}
            //GraphicsPath _path = new GraphicsPath();

            //_path.Reset();//do not forget!!!
            
            //_path.AddPolygon(ArrPoint); //you add to polygonPoint Array to it.


            //bool inpolygon = 
            //_path.IsVisible((float)point.X, (float)point.Y);


            double reference = (_points[1] - _points[0]) ^ (point - _points[0]);

            for (int i = 1; i < _points.Count ; i++)
            {
                double value = (_points[(i + 1)%_points.Count] - _points[i]) ^ (point - _points[i]);
                if (value != 0)
                {
                    if (reference == 0)
                    {
                        reference = value;
                    }
                    if (System.Math.Sign(value) != System.Math.Sign(reference))
                        return false;
                }
            }

            return true;

            //int loop;
            //int num_verts = _points.Count;
            //double nx, ny;
            ////	Clockwise order.
            //bool clockwiseIn = true;
            //for (loop = 0; loop < num_verts; loop++)
            //{
            //    //	generate a 2d normal ( no need to normalise ).
            //    nx = _points[(loop + 1) % num_verts].Y - _points[loop].Y;
            //    ny = _points[loop].X - _points[(loop + 1) % num_verts].X;

            //    double x = point.X - _points[loop].X;
            //    double y = point.Y - _points[loop].Y;

            //    //	Dot with edge normal to find side.
            //    if ((x * nx) + (y * ny) > 0)
            //    {
            //        clockwiseIn = false;
            //        break;
            //    }
            //}
            //if (clockwiseIn)
            //    return true;
            //else
            //{

            //    for (loop = num_verts - 1; loop >= 0; loop--)
            //    {
            //        //	generate a 2d normal ( no need to normalise ).
            //        nx = _points[(loop + 1) % num_verts].Y - _points[loop].Y;
            //        ny = _points[loop].X - _points[(loop + 1) % num_verts].X;

            //        double x = point.X - _points[loop].X;
            //        double y = point.Y - _points[loop].Y;

            //        //	Dot with edge normal to find side.
            //        if ((x * nx) + (y * ny) > 0)
            //        {
            //            return false;
            //        }
            //    }
            //    return true;

            //}

            
        }

     
        public void AddPoint(VectorD point)
        {
            _points.Add(point);
        }

        public ConvexPolygon()
        {
            _points = new List<VectorD>();
        }


        public double Area
        {
            get
            {
                double sum = 0;

                for (int i = 0; i < _points.Count-1; i++)
                {
                    sum += _points[i].X * _points[i + 1].Y;
                    sum -= _points[i].Y * _points[i + 1].X;
                }
                sum += _points[_points.Count - 1].X * _points[0].Y;
                sum -= _points[_points.Count - 1].Y * _points[0].X;
                return  System.Math.Abs( 0.5*sum);
            }

        }

        public VectorD MidPoint
        {
            get
            {
                double sumX=0;
                double sumY=0;

                for (int i = 0; i < _points.Count; i++)
                {
                    sumX += _points[i].X;
                    sumY += _points[i].Y;
                }
                return new VectorD(sumX / _points.Count, sumY / _points.Count);
            }

        }
        public SizeD BoundingRectangleSize
        {
            get
            {
                double minX = double.MaxValue, minY = double.MaxValue, maxX = double.MinValue, maxY = double.MinValue;
                for (int i = 0; i < this.Count; i++)
                {
                    if (this[i].X < minX)
                    {
                        minX = this[i].X;
                    }

                    if (this[i].X > maxX)
                    {
                        maxX = this[i].X;
                    }

                    if (this[i].Y < minY)
                    {
                        minY = this[i].Y;
                    }

                    if (this[i].Y > maxY)
                    {
                        maxY = this[i].Y;
                    }

                }
                return new SizeD(maxX - minX, minY - minY);
            }
        }



        public void Clear()
        {
            _points.Clear();
        }
    }
}
