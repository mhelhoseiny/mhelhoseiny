﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace SoftoriaPole.Geometry.Utils
{
    public enum Quadric
    {
        First,
        Second,
        Third,
        Fourth
    }
    [Serializable]
    public abstract class Ordered
    {
        public abstract bool Less(Ordered that);
    }

    [Serializable]
    public class VectorD : Ordered, ICloneable
    {
        private double _x;
        public VectorD()
        {
            _x = 0;
            _y = 0;
        }
        public VectorD(double x,double y)
        {
            _x = x;
            _y = y;
        }
        public double X
        {
            get { return _x; }
            set { _x = value; }
        }
        private double _y;

        public double Y
        {
            get { return _y; }
            set { _y = value; }
        }
        public void Rotate(double theta)
        {
 
        }
        public static VectorD CreateFromPolar(double r,double theta)
        {
            return new VectorD(r * System.Math.Cos(theta), r * System.Math.Sin(theta));
        }

        public static VectorD Rotate(VectorD rotatingPt, double theta)
        {
            return Rotate(rotatingPt, theta, new VectorD(0, 0));
        }
        public static VectorD Rotate(VectorD rotatingPt, double theta, VectorD rotatedPt)
        {
            VectorD v = rotatingPt - rotatedPt;
            double s = System.Math.Sin(theta);
            double c = System.Math.Cos(theta);
            VectorD result = new VectorD();
            result.X = v.X * c - v.Y * s;
            result.Y = v.X * s + v.Y * c;

            return result + rotatedPt;

        }

        public void Normalize()
        {
            double d =System.Math.Sqrt(_x * _x + _y * _y); 
            _x /= d;
            _y /= d;
            
        }
        public static VectorD operator+ (VectorD v1,VectorD v2)
        {
            VectorD v= new VectorD(v1.X + v2.X, v1.Y + v2.Y);
            return v;
        }
        public static VectorD operator -(VectorD v1, VectorD v2)
        {
            VectorD v = new VectorD(v1.X - v2.X, v1.Y - v2.Y);
            return v;
        }
        public static VectorD operator -( VectorD v)
        {
            return new VectorD(-v.X,-v.Y);
        }
        public static VectorD operator *(double scalar, VectorD v)
        {
            VectorD mulv = new VectorD(scalar*v.X, scalar *v.Y);
            return mulv;
        }

        /// <summary>
        /// cross product between two vectors
        /// </summary>
        /// <param name="v1">first vector</param>
        /// <param name="v2">second vector</param>
        /// <returns>the resultant vector (i.e. cross product)</returns>
        public static double operator ^(VectorD v1, VectorD v2)
        {
            return v1.X * v2.Y - v1.Y * v2.X;
        }

        /// <summary>
        /// dot product between two vectors
        /// </summary>
        /// <param name="v1">first vector</param>
        /// <param name="v2">second vector</param>
        /// <returns>the resultant vector (i.e. dot product)</returns>
        public static double operator |(VectorD v1, VectorD v2)
        {
            return v1.X * v2.X + v1.Y * v2.Y;
        }

        public bool Equals(VectorD p)
        {
            return _x == p._x && _y == p._y;
        }

        public override bool Less(Ordered o2)
        {
            VectorD p2 = (VectorD)o2;
            return _x < p2._x || _x == p2._x && _y < p2._y;
        }

        // Twice the signed area of the triangle (p0, p1, p2)
        public static double Area2(VectorD p0, VectorD p1, VectorD p2)
        {
            return p0._x * (p1._y - p2._y) + p1._x * (p2._y - p0._y) + p2._x * (p0._y - p1._y);
        }


        public double Magnitude
        {
            get
            {
                return System.Math.Sqrt(_x * _x + _y * _y);
            }
        }

        public Quadric Quadric
        {
            get 
            {
                if (_x >= 0 && _y >= 0)
                    return Quadric.First;
                else if (_x <= 0 && _y >= 0)
                    return Quadric.Second;
                else if (_x <= 0 && _y <= 0)
                    return Quadric.Third;
                //else if (_x <= 0 && _y >= 0)
                return Quadric.Fourth;
            }
        }


        #region ICloneable Members

        object ICloneable.Clone()
        {
            return this.Clone();
        }
        public VectorD Clone()
        {
            return new VectorD(_x,_y);
        }

        #endregion
    }
    /// <summary>
    /// Line class determiened by equation of y = mx+b;
    /// </summary>
    [Serializable]
    public class Line
    {
        double _m, _b;

        public bool IsHorzontal
        {
            get 
            {
                return _m == 0;
            }
        }
        public bool IsVertical
        {
            get 
            {
                return _m == double.MaxValue;
            }
        }

        public VectorD AxialVector
        {
            get 
            {
                if (!IsVertical)
                {
                    VectorD v = new VectorD(1,_m);
                    v.Normalize();
                    return v;
                }
                //VectorD v = new VectorD(1,0);
                //v.Normalize();
                return new VectorD(0, 1);
            }
        }
        public double Y(double x)
        {
            if(IsVertical)
            {
               return _point.Y;
            }
            return  _m * x + _b;
        }

        public double X(double y)
        {
            if (IsHorzontal)
            {
                return _point.X;
            }
            return (y - _b) / _m;
        }
        private VectorD _point;
        public double M
        {
            get { return _m; }
            set { _m = value; }
        }

        public double B
        {
            get { return _b; }
            set { _b = value; }
        }

        /// <summary>
        /// Create line given a point on it and orientation vector
        /// </summary>
        /// <param name="point">point</param>
        /// <param name="orientation">orientation</param>
        public Line(VectorD point, VectorD orientation)
        {
            _point = point;
           
            if (orientation.X == 0)
            {
                _m = double.MaxValue;
            }
            else
                _m = orientation.Y / orientation.X;
            _b = point.Y - _m * point.X;

        }
        public Line(VectorD point, double orientation)
        {
            _point = point;
            if (orientation == System.Math.PI / 2 || orientation == 3 * System.Math.PI / 2)
            {
                _m = double.MaxValue;
            }
            else
            {
                _m = System.Math.Sin(orientation) / System.Math.Cos(orientation);
            
            }
            _b = point.Y - _m * point.X;
        }

        public void Shift(VectorD vector, double shift)
        {
            vector.Normalize();
            vector = shift * vector;
            if (IsVertical)
            {
                _point.X += vector.X;
            }
            _b += vector.Y;
            _point.Y += vector.Y;
        }


        /// <summary>
        /// returns a position vector of the intersecting point between two lines
        /// if no no intersection it returns new VectorD(double.MinValue, double.MinValue);
        /// if line1 is the same as line2 (i.e. same m and b)
        /// it returns return new VectorD(double.MaxValue, double.MaxValue);
        /// </summary>
        /// <param name="line1">line1</param>
        /// <param name="line2">line1</param>
        /// <returns></returns>
        public static VectorD LinesCross(Line line1, Line line2)
        {
            VectorD intersection = new VectorD();
            if (line1.M == line2.M)
            {
                if (line2.B == line1.B)
                {
                    return new VectorD(double.MaxValue, double.MaxValue);
                }
                else
                {
                    return new VectorD(double.MinValue, double.MinValue);
                }
            }
            if (line1.IsVertical)
            {
                intersection.X = line1._point.X;
                intersection.Y = line2._m * intersection.X + line2.B;
                return intersection;
            }
            else if (line2.IsVertical)
            {
                intersection.X = line2._point.X;
                intersection.Y = line1._m * intersection.X + line1.B;
                return intersection;
            }
            intersection.X = (line2.B-line1.B)/(line1.M-line2.M);
            intersection.Y = line2.M * intersection.X + line2.B;
            return intersection;
        }

        public VectorD UpNormalVector
        {
            get
            {
                return -DownNormalVector;
            }
        }
        public VectorD DownNormalVector
        {
            get
            {
                if (IsVertical)
                {
                    return new VectorD(-1, 0);
                }
                else if (IsHorzontal)
                {
                    return new VectorD(0, -1);
                }else
                return new VectorD(_m, -1);
            }
        }
    }
}



