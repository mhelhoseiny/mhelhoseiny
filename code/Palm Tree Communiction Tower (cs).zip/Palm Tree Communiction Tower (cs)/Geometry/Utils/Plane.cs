﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using MainProgram;
using SoftoriaPole.Utilities;

namespace SoftoriaPole.Geometry.Utils
{
    [Serializable]
    public class Plane
    {
        const double _Eps = 0.0001;
        protected Vector3 _normal;

        public virtual Vector3 Normal
        {
            get { return _normal; }
            set { _normal = value; }
        }
        protected Vector3 _point;

        public virtual Vector3 Point
        {
            get { return _point; }
            set { _point = value; }
        }
        public Plane(Vector3 normal, Vector3 point)
        {
            _normal = normal;
            _point = point;
        }
        public Vector3 Project(Vector3 point)
        {
            return Project(_normal, _point, point);
        }

        public static Vector3 Project(Vector3 planeNormal, Vector3 planePoint, Vector3 point)
        {
            planeNormal.Normalize();
            double distance = VectorOperations.Dotproduct(planeNormal, point - planePoint);
            return point - distance * planeNormal;
        }

        public bool PointOnPlane(Vector3 point)
        {
            Vector3 p = point - _point;

            return VectorOperations.Dotproduct(_normal, p) < _Eps;
        }

        public Vector3[] LocalFrame
        {
            get
            {
                double[][] localFrame = VectorOperations.ComputeFrame(_normal, 0);
                Vector3[] localframeVecArr = new Vector3[3];
                localframeVecArr[2] = Converter.ToVector3(localFrame[0]);
                localframeVecArr[1] = Converter.ToVector3(localFrame[1]);
                localframeVecArr[0] = Converter.ToVector3(localFrame[2]);
                return localframeVecArr;
            }
        }
        private const double Eps = 0.001;
        /// <summary>
        /// Trace a ray in a plane
        /// All vectors must be unitVectors
        /// </summary>
        /// <param name="plane">given plane</param>
        /// <param name="point">ray point</param>
        /// <param name="direction">ray direction</param>
        /// <returns>
        /// bool determine whether ray hit the plane or not
        /// double determines the distance
        /// a plane is defined by normal an p0
        /// normal|(point-p0) = 0 ;where point is a point on the plane
        /// Ray is defined by pt(position vector) and v (ray vector)
        /// we want to get a point = pt+c*v;
        /// =>normal|(pt+c*v-p0) = 0
        /// =>c = (normal|(p0-pt))/(normal|v)
        /// where c is scalar value.
        /// normal,p0,pt,v are vectors in 3d
        /// </returns>
        public static KeyValuePair<bool, double> TracePlane(Plane plane, Vector3 point, Vector3 direction)
        {
            Vector3 normal = plane.Normal;
            Vector3 p0 = plane.Point;
            Vector3 pt = point;
            Vector3 v = direction;

            if (System.Math.Abs(normal | v) > Eps)
            {
                double c = (normal | (p0 - pt)) / (normal | v);
                Vector3 pointOnPlane = pt + c * v;
                //bool ispointOnPlane = plane.PointOnBoundedPlane(pointOnPlane);
                KeyValuePair<bool, double> res = new KeyValuePair<bool, double>(true, c);
                return res;
            }
            else
            {
                return new KeyValuePair<bool, double>(false, 0);
            }
        }
    }
    [Serializable]
    public class ConvexBoundedPlane:Plane
    {

        protected List<Vector3> _convexPlanarPolygon;

        public List<Vector3> ConvexPlanarPolygon
        {
            get { return _convexPlanarPolygon; }
        }

        protected ConvexPolygon _localConvexPolygon =  new ConvexPolygon();

        public ConvexPolygon LocalConvexPolygon
        {
            get { return _localConvexPolygon; }
        }

        public ConvexBoundedPlane(Vector3 normal, Vector3 point, List<Vector3> convexPlanarPolygon)
            : base(normal, point)
        {
            _convexPlanarPolygon= convexPlanarPolygon;

            CalulateLocalConvexPolygon();
        }

        private void CalulateLocalConvexPolygon()
        {
            _localConvexPolygon.Clear();

            Vector3[] localFrame = LocalFrame;
            for (int i = 0; i < _convexPlanarPolygon.Count; i++)
            {
                Vector3 v = VectorOperations.FromGlobalToLocal(_convexPlanarPolygon[i],localFrame[0],localFrame[1],localFrame[2]);
                VectorD vlocalonPlane = new VectorD(v.X,v.Y);
                _localConvexPolygon.AddPoint(vlocalonPlane );
            }

        }

        public override Vector3 Normal
        {
            get
            {
                return base.Normal;
            }
            set
            {
                throw new Exception();
            }
        }
        public override Vector3 Point
        {
            get
            {
                return base.Point;
            }
            set
            {
                throw new Exception();
            }
        }

        public bool PointOnBoundedPlane(Vector3 point)
        {
            if (PointOnPlane(point))
            {
                Vector3[] localFrame = LocalFrame;
                Vector3 v = VectorOperations.FromGlobalToLocal(point, localFrame[0], localFrame[1], localFrame[2]);
                VectorD vlocalonPlane = new VectorD(v.X, v.Y);
                return _localConvexPolygon.PointInPolygon(vlocalonPlane);
            }
            else
                return false;
            
        }
        
    }
}
