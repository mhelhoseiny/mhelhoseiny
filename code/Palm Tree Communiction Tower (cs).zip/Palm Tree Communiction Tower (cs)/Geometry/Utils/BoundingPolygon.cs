﻿using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using MainProgram;
using SoftoriaPole.Geometry.Utils;
using System.Drawing;
using SoftoriaPole.Utilities;

namespace SoftoriaPole.Geometry
{
    [Serializable]
    public class ProjectionInfo
    {
        private ConvexPolygon _polygon;

        public ConvexPolygon Polygon
        {
            get { return _polygon; }
        }

        List<Vector3> _localPoints =  new List<Vector3>();

       
        private double _averageHeight;

        public double AverageHeight
        {
          get { return _averageHeight; }
        }

        private double _minimumHeight;

        public double MinimumHeight
        {
            get { return _minimumHeight; }
            set { _minimumHeight = value; }
        }

        private double _maximumHeight;

        public double MaximumHeight
        {
            get { return _maximumHeight; }
            set { _maximumHeight = value; }
        }


        
       
        public ProjectionInfo(ConvexPolygon polygon, double averageHeight,double minimumHeight,double maximumHeight)
        {
            _polygon = polygon;
            _averageHeight = averageHeight;
            _minimumHeight = minimumHeight;
            _maximumHeight = maximumHeight;
        }
    }
    [Serializable]
    public struct SizeD
    {
        private double _dimensionA;

        public double DimensionA
        {
            get { return _dimensionA; }
            set { _dimensionA = value; }
        }
        private double _dimensionB;

        public double DimensionB
        {
            get { return _dimensionB; }
            set { _dimensionB = value; }
        }
        public SizeD(double dimensionA, double dimensionB)
        {
            _dimensionA = dimensionA;
            _dimensionB = dimensionB;

        }
    }

    public enum BoundingPolyhedronPlaneType
    {
        SidePlane,
        TopPlane,
        BottomPlane,
    }
    [Serializable]
    public class BoundingPolyhedron
    {

        private Vector3 _startPosition;

        public Vector3 StartPosition
        {
            get { return _startPosition.Clone(); }
        }

        public Vector3 CenterPosition
        {
            get { return .5*(StartPosition+EndPosition); }
        }

        private Vector3 _axial;
        private Vector3 Axial
        {
            get
            {
                return _axial.Clone();
            }
 
        }

        public Vector3 EndPosition
        {
            get
            {
                return _startPosition + Length * Axial;
            }
        }

        private List<Vector3> _basePoints =  new List<Vector3>();

        public List<Vector3> BasePoints
        {
            get { return _basePoints; }
        }
        private List<Vector3> _topPoints =  new List<Vector3>();

        public List<Vector3> TopPoints
        {
            get { return _topPoints; }
        }
        private double _length;

        public double Length
        {
            get { return _length; }
        }

        public double StartDimensionA
        {
            get
            {
                return (_basePoints[0]-_basePoints[1]).Magnitude;
            }
        }

        public double EndDimensionA
        {
            get
            {
                return (_topPoints[0] - _topPoints[1]).Magnitude; ;
            }
        }


        public double StartDimensionB
        {
            get
            {
                return (_basePoints[1] - _basePoints[2]).Magnitude;
            }
        }

        public double EndDimensionB
        {
            get
            {
                return (_topPoints[1] - _topPoints[2]).Magnitude; ;
            }
        }

        public double DimensionAAt(double t)
        {

            return (1-t)*StartDimensionA+t*EndDimensionA;
        }

        public double DimensionBAt(double t)
        {
            return (1 - t) * StartDimensionB + t * EndDimensionB;

        }


        public double Volume
        {
            get
            {
                return DimensionAAt(.5) * DimensionBAt(.5) * Length;
            }
        }
        double _twistAngle = double.MinValue;
        Vector3 _localX;

        public Vector3 LocalX
        {
            get { return _localX.Clone(); }
        }
        Vector3 _localY;

        public Vector3 LocalY
        {
            get { return _localY.Clone(); }
        }
        Vector3 _localZ;

        public Vector3 LocalZ
        {
            get { return _localZ.Clone(); }
        }
        internal BoundingPolyhedron(Vector3 position, Vector3 axial, double length, double startDimensionA, double endDiemensionA, double startDimensionB, double endDiemensionB,double twistAngle)
        {
            _twistAngle = twistAngle;
            _startPosition = position;
            _axial = axial;
            _length = length;
            double[][] localframe = VectorOperations.ComputeFrame(axial, 0);
            _localX = Converter.ToVector3(localframe[0]);
            _localY = Converter.ToVector3(localframe[1]);
            _localY=VectorOperations.Rotate(_localY, _localX, _twistAngle);
            _localZ = Converter.ToVector3(localframe[2]);
            _localZ=VectorOperations.Rotate(_localZ, _localX, _twistAngle);
            _localX.Normalize();
            _localY.Normalize();
            _localZ.Normalize();

            _basePoints.Add(position + (startDimensionA / 2) * _localY + (startDimensionB / 2) * _localZ);
            _basePoints.Add(position - (startDimensionA / 2) * _localY + (startDimensionB / 2) * _localZ);
            _basePoints.Add(position - (startDimensionA / 2) * _localY - (startDimensionB / 2) * _localZ);
            _basePoints.Add(position + (startDimensionA / 2) * _localY - (startDimensionB / 2) * _localZ);

            Vector3 position1 = position + length * _localX;
            _topPoints.Add(position1 + (endDiemensionA / 2) * _localY + (endDiemensionB / 2) * _localZ);
            _topPoints.Add(position1 - (endDiemensionA / 2) * _localY + (endDiemensionB / 2) * _localZ);
            _topPoints.Add(position1 - (endDiemensionA / 2) * _localY - (endDiemensionB / 2) * _localZ);
            _topPoints.Add(position1 + (endDiemensionA / 2) * _localY - (endDiemensionB / 2) * _localZ);


        }

        internal BoundingPolyhedron(Vector3 position, Vector3 axial, double length, double startDimensionA, double endDiemensionA, double startDimensionB, double endDiemensionB):this(position,axial,length,startDimensionA,endDiemensionA,startDimensionB,endDiemensionB,0)
        {
           
        }
        private BoundingPolyhedron(Vector3 axial)
        {
            _axial = axial;
        }

        public BoundingPolyhedron SubBoundingPolyhedron(double t0 ,double t1)
        {
            if (t0 < 0 || t0 > 1 || t1 < 0 || t1 > 1)
                throw new Exception("invalid t values");

            BoundingPolyhedron b =  new BoundingPolyhedron(t0<t1?_axial:-_axial);
            b._length = System.Math.Abs(t1 - t0) * _length;
          
            b._startPosition = _startPosition + (t0<t1?t0:t1) * Length * _axial; 
            b._basePoints.Add((1-t0)*_basePoints[0] + t0*_topPoints[0]);
            b._basePoints.Add( (1-t0)*_basePoints[1] + t0*_topPoints[1]);
            b._basePoints.Add((1-t0)*_basePoints[2] + t0*_topPoints[2]);
            b._basePoints.Add( (1-t0)*_basePoints[3] + t0*_topPoints[3]);


            b._topPoints.Add( (1 - t1) * _basePoints[0] + t1 * _topPoints[0]);
            b._topPoints.Add((1 - t1) * _basePoints[1] + t1 * _topPoints[1]);
            b._topPoints.Add( (1 - t1) * _basePoints[2] + t1 * _topPoints[2]);
            b._topPoints.Add( (1 - t1) * _basePoints[3] + t1 * _topPoints[3]);
            return b;
        }


        public ProjectionInfo LocalProjectTo(Vector3 position,Vector3 localX,Vector3 localY,Vector3 localZ)
        {
            List<Vector3> projectedTopPoints = new List<Vector3>();
            foreach (Vector3 point3 in _topPoints)
            {
                projectedTopPoints.Add(Plane.Project(localZ, position,point3));
            }

            List<Vector3> projectedBasePoints = new List<Vector3>();
            foreach (Vector3 point3 in _basePoints)
            {
                projectedBasePoints.Add(Plane.Project(localZ, position, point3));
            }

            VectorD[] result = new VectorD[_topPoints.Count+_basePoints.Count];
            double averageZ = 0;
            double minimumZ = double.MaxValue;
            double maximumZ = double.MinValue;
            int i=0;
            foreach (Vector3 point3 in projectedTopPoints)
            {
                Vector3 localVector = new Vector3(localX | point3, localY | point3, localZ | point3);
                averageZ += localVector.Z;
                maximumZ = System.Math.Max(maximumZ, localVector.Z);
                minimumZ = System.Math.Min(minimumZ, localVector.Z);
                VectorD point2 = new VectorD(localVector.X, localVector.Y);
                result[i] = point2;
                i++;
            }

            foreach (Vector3 point3 in projectedBasePoints)
            {
                Vector3 localVector = new Vector3(localX | point3, localY | point3, localZ | point3);
                averageZ += localVector.Z;
                maximumZ = System.Math.Max(maximumZ,localVector.Z);
                minimumZ = System.Math.Min(minimumZ, localVector.Z);

                VectorD point2 = new VectorD(localVector.X, localVector.Y);
                result[i] = point2;
                i++;
            }

            averageZ /= (_basePoints.Count+_topPoints.Count);

            //TODO :is it accurate
            averageZ-=(StartDimensionA+StartDimensionB+EndDimensionA+EndDimensionB)/8;
            
            VectorD[] res =  Convexhull.convexhull(result);
            return new ProjectionInfo(new ConvexPolygon(res),averageZ,minimumZ,maximumZ);
        }

        public ProjectionInfo[] LocalProjectTo(List<int> planeIndices, Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            return LocalProjectTo(planeIndices, new Vector3(0, 0, 0), localX, localY, localZ);
        }

        public ProjectionInfo LocalProjectTo(int planeIndex,Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            return LocalProjectTo(planeIndex, new Vector3(0, 0, 0), localX, localY, localZ);
        }
        public ProjectionInfo LocalProjectTo(int planeIndex, Vector3 position, Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            ConvexBoundedPlane plane = Planes[planeIndex];
            List<Vector3> polygon = plane.ConvexPlanarPolygon;

            List<Vector3> projectedPoints = polygon;


            VectorD[] result = new VectorD[polygon.Count];
            double averageZ = 0;
            double minimumZ = double.MaxValue;
            double maximumZ = double.MinValue;
            int i = 0;
            foreach (Vector3 point3 in projectedPoints)
            {
                Vector3 localVector = new Vector3(localX | point3, localY | point3, localZ | point3);
                averageZ += localVector.Z;

                minimumZ = System.Math.Min(minimumZ, localVector.Z);
                maximumZ = System.Math.Max(maximumZ, localVector.Z);

                VectorD point2 = new VectorD(localVector.X, localVector.Y);
                result[i] = point2;
                i++;
            }

            averageZ /= polygon.Count;

            return new ProjectionInfo(new ConvexPolygon(result), averageZ, minimumZ, maximumZ);

        }
        public ProjectionInfo[] LocalProjectTo(List<int> planeIndices, Vector3 position, Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            ProjectionInfo[] projectionsInfo = new ProjectionInfo[planeIndices.Count];

            int planeIndex = 0;
            foreach (int index in planeIndices)
            {
                projectionsInfo[planeIndex] = LocalProjectTo(index, position, localX, localY, localZ);
                planeIndex++;
            }
            return projectionsInfo;
        }



        public ProjectionInfo LocalProjectTo(Vector3 localX, Vector3 localY, Vector3 localZ)
        {
            return LocalProjectTo(new Vector3(0, 0, 0), localX, localY, localZ);
        }



       

        public ConvexBoundedPlane Plane0
        {
            get
            {
                Vector3 v1 = _topPoints[0] - _basePoints[0];
                Vector3 v2 = _basePoints[1] - _basePoints[0];
                Vector3 point = _topPoints[0].Clone();
                List<Vector3> convexPolygon =  new List<Vector3>();
                convexPolygon.Add(_basePoints[0].Clone());
                convexPolygon.Add(_basePoints[1].Clone());
                convexPolygon.Add(_topPoints[1].Clone());
                convexPolygon.Add(_topPoints[0].Clone());

                ConvexBoundedPlane plane = new ConvexBoundedPlane(v1 ^ v2, point,convexPolygon);
                return plane;
            }
        }

        public ConvexBoundedPlane Plane1
        {
            get
            {
                Vector3 v1 = _topPoints[1] - _basePoints[1];
                Vector3 v2 = _basePoints[2] - _basePoints[1];
                Vector3 point = _topPoints[1].Clone();
                List<Vector3> convexPolygon =  new List<Vector3>();

                convexPolygon.Add(_basePoints[1].Clone());
                convexPolygon.Add(_basePoints[2].Clone());
                convexPolygon.Add(_topPoints[2].Clone());
                convexPolygon.Add(_topPoints[1].Clone());

                ConvexBoundedPlane plane =new  ConvexBoundedPlane(v1 ^ v2, point,convexPolygon);
                return plane;

            }
        }

        public ConvexBoundedPlane Plane2
        {
            get
            {
                Vector3 v1 = _topPoints[2] - _basePoints[2];
                Vector3 v2 = _basePoints[3] - _basePoints[2];
                Vector3 point = _topPoints[2].Clone() ;

                List<Vector3> convexPolygon = new List<Vector3>();
                convexPolygon.Add(_basePoints[2].Clone());
                convexPolygon.Add(_basePoints[3].Clone());
                convexPolygon.Add(_topPoints[3].Clone());
                convexPolygon.Add(_topPoints[2].Clone());

                ConvexBoundedPlane plane = new ConvexBoundedPlane(v1 ^ v2, point, convexPolygon);
                return plane;

            }
        }


        public ConvexBoundedPlane Plane3
        {
            get
            {
                Vector3 v1 = _topPoints[3] - _basePoints[3];
                Vector3 v2 = _basePoints[0] - _basePoints[3];
                Vector3 point = _topPoints[3].Clone();
                List<Vector3> convexPolygon = new List<Vector3>();

                convexPolygon.Add(_basePoints[3].Clone());
                convexPolygon.Add(_basePoints[0].Clone());
                convexPolygon.Add(_topPoints[0].Clone());
                convexPolygon.Add(_topPoints[3].Clone());

                ConvexBoundedPlane plane = new ConvexBoundedPlane(v1 ^ v2, point, convexPolygon);
                return plane;

            }
        }

        public ConvexBoundedPlane Plane4
        {
            get
            {
                Vector3 v1 = _basePoints[3] - _basePoints[0];
                Vector3 v2 = _basePoints[1] - _basePoints[0];
                Vector3 point = _basePoints[3].Clone();
                List<Vector3> convexPolygon = new List<Vector3>();
                convexPolygon.Add(_basePoints[0].Clone());
                convexPolygon.Add(_basePoints[1].Clone());
                convexPolygon.Add(_basePoints[2].Clone());
                convexPolygon.Add(_basePoints[3].Clone());
                ConvexBoundedPlane plane = new ConvexBoundedPlane(v1 ^ v2, point, convexPolygon);
                return plane;

            }
        }

        public ConvexBoundedPlane Plane5
        {
            get
            {
                Vector3 v1 = _topPoints[3] - _topPoints[0];
                Vector3 v2 = _topPoints[1] - _topPoints[0];
                Vector3 point = _topPoints[3].Clone();
                List<Vector3> convexPolygon = new List<Vector3>();
                convexPolygon.Add(_topPoints[0].Clone());
                convexPolygon.Add(_topPoints[1].Clone());
                convexPolygon.Add(_topPoints[2].Clone());
                convexPolygon.Add(_topPoints[3].Clone());
                ConvexBoundedPlane plane = new ConvexBoundedPlane(v1 ^ v2, point, convexPolygon);
                return plane;
            }
        }

        public ConvexBoundedPlane[] SidePlanes
        {
            get
            {
                ConvexBoundedPlane[] planes = new ConvexBoundedPlane[4];
                planes[0] = Plane0;
                planes[1] = Plane1;
                planes[2] = Plane2;
                planes[3] = Plane3;

                return planes;
            }
        }

        public ConvexBoundedPlane TopPlane
        {
            get
            {
                return Planes[5];
            }
        }

        public ConvexBoundedPlane BottomPlane
        {
            get
            {
                return Planes[4];
            }
        }

        public ConvexBoundedPlane[] Planes
        {
            get
            {
                ConvexBoundedPlane[] planes = new ConvexBoundedPlane[6];
                planes[0] = Plane0;
                planes[1] = Plane1;
                planes[2] = Plane2;
                planes[3] = Plane3;
                planes[4] = Plane4;
                planes[5] = Plane5;

                return planes;

            }
        }
        private const double Eps = 0.001;

        /// <summary>
        /// Trace a ray in a plane
        /// All vectors must be unitVectors
        /// </summary>
        /// <param name="plane">given plane</param>
        /// <param name="point">ray point</param>
        /// <param name="direction">ray direction</param>
        /// <returns>
        /// bool determine whether ray hit the plane or not
        /// double determines the distance
        /// a plane is defined by normal an p0
        /// normal|(point-p0) = 0 ;where point is a point on the plane
        /// Ray is defined by pt(position vector) and v (ray vector)
        /// we want to get a point = pt+c*v;
        /// =>normal|(pt+c*v-p0) = 0
        /// =>c = (normal|(p0-pt))/(normal|v)
        /// where c is scalar value.
        /// normal,p0,pt,v are vectors in 3d
        /// </returns>
        public KeyValuePair<bool,double> TracePlane(ConvexBoundedPlane plane, Vector3 point, Vector3 direction)
        {
            Vector3 normal = plane.Normal;
            Vector3 p0 = plane.Point;
            Vector3 pt = point;
            Vector3 v = direction;

            if (System.Math.Abs(normal | v) > Eps)
            {
                double c = (normal | (p0 - pt)) / (normal | v);
                Vector3 pointOnPlane = pt + c * v;
                bool ispointOnPlane = plane.PointOnBoundedPlane(pointOnPlane);
                KeyValuePair<bool, double> res = new KeyValuePair<bool, double>(ispointOnPlane,c);
                return res;
            }
            else
            {
                return new KeyValuePair<bool, double>(false, 0);
            }
        }
        /// <summary>
        /// Trace Ray on the BoundingPolyhedron 
        /// (i.e. trace all planes of the cube)
        /// and returns maxiumum distance intersecting the cube
        /// </summary>
        /// <param name="postion"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        public double TraceRay(Vector3 postion, Vector3 direction)
        {

            ConvexBoundedPlane[] planes = Planes;
            double maxDistance = double.MinValue; 
            foreach (ConvexBoundedPlane p in planes)
            {
                KeyValuePair<bool, double> res = TracePlane(p, postion, direction);
                if(res.Key==true)
                {
                    maxDistance = System.Math.Max(maxDistance,res.Value);
                }
            }
            return maxDistance;

        }

        /// <summary>
        /// Trace Ray on the BoundingPolyhedron 
        /// (i.e. trace all planes of the cube)
        /// and returns minimum distance intersecting the cube
        /// </summary>
        /// <param name="postion"></param>
        /// <param name="direction"></param>
        /// <returns></returns>
        public double TraceMinRay(Vector3 postion, Vector3 direction)
        {

            ConvexBoundedPlane[] planes = Planes;
            double minDistance = double.MaxValue;
            foreach (ConvexBoundedPlane p in planes)
            {
                KeyValuePair<bool, double> res = TracePlane(p, postion, direction);
                if (res.Key == true)
                {
                    minDistance = System.Math.Min(minDistance, res.Value);
                }
            }
            return minDistance;

        }

        /// <summary>
        /// Gets planes facing given direction  in the bounding polyhedron
        /// </summary>
        /// <param name="direction">the direction</param>
        /// <returns>
        /// list of key value pairs
        /// Key is the type of the plane (side ,top,bottom)
        /// Value is the index of plane in the planes array
        /// of the planes of the  bounding polyhedron
        /// </returns>
        public List<KeyValuePair<BoundingPolyhedronPlaneType,int>> GetFacingPlanes(Vector3 direction)
        {
            direction.Normalize();
            bool isbase = true;
            int index = -1;
            double minDistance  = double.MaxValue;
            for (int i = 0; i < _basePoints.Count; i++)
            {
                Vector3 projectedPt = Plane.Project(direction, new Vector3(0, 0, 0), _basePoints[i]);
                Vector3 translationVector =  _basePoints[i] - projectedPt;
                double distance = VectorOperations.Dotproduct(direction, translationVector);
                if (distance < minDistance)
                {
                    isbase = true ;
                    index = i;
                    minDistance = distance; 
                }
            }

            for (int i = 0; i < _topPoints.Count; i++)
            {
                Vector3 projectedPt = Plane.Project(direction, new Vector3(0, 0, 0), _topPoints[i]);
                Vector3 translationVector = _topPoints[i] - projectedPt;
                double distance = VectorOperations.Dotproduct(direction, translationVector);
                if (distance < minDistance)
                {
                    isbase = false;
                    index = i;
                    minDistance = distance;
                }
            }

            List<KeyValuePair<BoundingPolyhedronPlaneType, int>> res = new  List<KeyValuePair<BoundingPolyhedronPlaneType,int>>();
            res.Add(new KeyValuePair<BoundingPolyhedronPlaneType, int>(BoundingPolyhedronPlaneType.SidePlane, (index - 1 + 4) % 4));
            res.Add(new KeyValuePair<BoundingPolyhedronPlaneType, int>(BoundingPolyhedronPlaneType.SidePlane, index));
                
            if (isbase)
            {
                res.Add(new KeyValuePair<BoundingPolyhedronPlaneType,int>(BoundingPolyhedronPlaneType.BottomPlane,4)); 
            }
            else
            {
                res.Add(new KeyValuePair<BoundingPolyhedronPlaneType, int>(BoundingPolyhedronPlaneType.TopPlane, 5)); 
                
            }

            return res;

        }
    }
}
