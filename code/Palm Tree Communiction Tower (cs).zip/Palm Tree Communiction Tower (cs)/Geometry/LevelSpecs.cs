﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram.App_Classes
{
    [Serializable]
    public class LevelSpecs
    {
        public LevelSpecs(string name, double l3, double z,double r, int numberOfBranches,double phai, double theta0)
        {
            Name = name;
            L3 = l3;
            Z = z;
            R = r;
            NumberOfBranches = numberOfBranches;
            Phai = phai;
            Theta0 = theta0;
        }

        public string Name
        {
            get;
            set;
        }

        public double L3
        {
            get;
            set;
        }

        public double Z
        {
            get;
            set;
        }

        public double R
        {
            get;
            set;
        }

        public int NumberOfBranches
        {
            get;
            set;
        }

       /// <summary>
       /// Rise Angle
       /// </summary>
        public double Phai
        {
            get;
            set;
        }
        /// <summary>
        /// First Orientation
        /// </summary>
        public double Theta0
        {
            get;
            set;
        }
    }
}
