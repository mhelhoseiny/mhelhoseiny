﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram.App_Classes
{
    [Serializable]
    public class BranchSpecs
    {
        public BranchSpecs(double l1,double l2,double l4, double sl1, double sl2, double w1, double w2, double w3,double t1,double t2,double t3,double deltaPhai, double ripDensity, double leafDensity, double leafWidth, double leafThickness)
        {
            L1 = l1;
            L2 = l2;
            L4 = l4;
            SL1 = sl1;
            SL2 = sl2;
            W1 = w1;
            W2 = w2;
            W3 = w3;
            T1 = t1;
            T2 = t2;
            T3 = t3;
            DeltaPhai = deltaPhai;
            LeafDensity = leafDensity;
            LeafWidth = leafWidth;
            LeafThickness = leafThickness;

        }
        public double L1
        {
            get;
            set;
        }
        public double L2
        {
            get;
            set;
        }
        public double L4
        {
            get;
            set;
        }

        public double SL1
        {
            get;
            set;
        }

        public double SL2
        {
            get;
            set;
        }

        public double W1
        {
            get;
            set;
        }

        public double W2
        {
            get;
            set;
        }

        public double W3
        {
            get;
            set;
        }

        public double T1
        {
            get;
            set;
        }

        public double T2
        {
            get;
            set;
        }

        public double T3
        {
            get;
            set;
        }

        public double DeltaPhai
        {
            get;
            set;
        }

        public double RipDensity
        {
            get;
            set;
        }

        public double LeafDensity
        {
            get;
            set;
        }

        public double LeafWidth
        {
            get;
            set;
        }

        public double LeafThickness
        {
            get;
            set;
        }
    }
}
