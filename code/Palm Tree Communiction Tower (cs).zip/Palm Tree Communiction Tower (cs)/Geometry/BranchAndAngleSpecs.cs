﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MainProgram.App_Classes
{
    [Serializable]
    public class PipeAndAngleSpecs
    {
        public PipeAndAngleSpecs(string name, double z, double w, double t,double l , double r,double theta,double twistAngle)
        {
            Name = name;
            Z = z;
            W = w;
            T = t;
            L = l;
            R = r;
            Theta = theta;
            TwistAngle = twistAngle;
        }

        public string Name
        {
            get;
            set;
        }

        public double Z
        {
            get;
            set;
        }

        public double W
        {
            get;
            set;
        }

        public double T
        {
            get;
            set;
        }

        public double L
        {
            get;
            set;
        }

        public double R
        {
            get;
            set;
        }

        /// <summary>
        /// Orientation
        /// </summary>
        public double Theta
        {
            get;
            set;
        }

        public double TwistAngle
        {
            get;
            set;
        }
    }
}
