using System;
using System.Collections.Generic;
using System.Text;
using SoftoriaPole.Math;
using Mapack;

namespace SoftoriaPole.Utilities
{
    [Serializable]
    public class Converter
    {
        /// <summary>
        /// This class is static.
        /// </summary>
        private Converter()
        { }

        /// <summary>
        /// Converts the given vector into an array of floats containing the
        /// coordinates of the vector.
        /// </summary>
        public static float[] ToArray3(Vector3 vec)
        {
            return new float[] { (float)vec.X, (float)vec.Y, (float)vec.Z };
        }

        /// <summary>
        /// Converts the given vector into an array of doubles containing the
        /// coordinates of the vector.
        /// </summary>
        public static double[] ToArray3D(Vector3 vec)
        {
            return new double[] { vec.X, vec.Y, vec.Z };
        }

        public static Vector3 ToVector3(double[] arr)
        {
            if (arr == null || arr.Length < 3)
                return null;
            return new Vector3(arr[0], arr[1], arr[2]);
        }

        /// <summary>
        /// Converts the first 3x1 subvector of the provided matrix into a Vector3.
        /// </summary>
        /// <param name="vec"></param>
        /// <returns></returns>
        public static Vector3 ToVector3(Mapack.Matrix vec)
        {
            if (vec == null || vec.Rows < 3 || vec.Columns < 1)
                return null;
            Vector3 retval = new Vector3(
                vec[0, 0], vec[1, 0], vec[2, 0]);
            return retval;
        }

        /// <summary>
        /// Converts the 3x1 subvector of the cth column of the provided matrix into a Vector3.
        /// </summary>
        /// <param name="vec"></param>
        /// <returns></returns>
        public static Vector3 ToVector3(Mapack.Matrix mtx, int c)
        {
            if (c < 0 || mtx == null || mtx.Rows < 3 || mtx.Columns < c + 1)
                return null;
            Vector3 retval = new Vector3(
                mtx[0, c], mtx[1, c], mtx[2, c]);
            return retval;
        }

        /// <summary>
        /// Converts the provided Vector3 into a 3x1 Mapack.Matrix.
        /// </summary>
        /// <param name="vec"></param>
        /// <returns></returns>
        public static Mapack.Matrix ToMapackMatrix(Vector3 vec)
        {
            Matrix retval = new Matrix(3, 1, vec.X);
            retval[1, 0] = vec.Y;
            retval[2, 0] = vec.Z;
            return retval;
        }
    }
}
