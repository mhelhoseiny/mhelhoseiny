This is written in Pascal

This is my implementation of watershed algorithm which I used in combination with the snake model (Active contour) to do some medical image processing task. The I used Level set segmentation that gave me better results.