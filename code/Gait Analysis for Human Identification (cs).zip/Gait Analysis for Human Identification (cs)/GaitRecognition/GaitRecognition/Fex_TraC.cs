﻿using System;
using System.Collections.Generic;
using System.Text;
using Mapack;
using Emgu.CV;

namespace GaitRecognition
{
    public class Fex_TraC
    {
        /// <summary>
        /// Reset images
        /// </summary>
        /// <param name="label"></param>
        public static void resetgait(int label)
        {
            humanFrames[label.ToString()].Clear();
            framesIntensity[label.ToString()].Clear();
        }


        // Feature Extraction 
        Fex fex;
        // Training or Classification
        TraC trac;
        // frames of the current person.
        static Dictionary<string, List<Image<Gray, Byte>>> humanFrames;
        // intensities for frames of the current person.
        static Dictionary<string, List<double>> framesIntensity;

        // gallery GEIs with Masks applied
        public List<Image<Gray, Byte>> _maskedGEIs;
        // gallery labels of gallery GEIs
        public List<string> _labels;
   
        // masks of the gallery GEIs
        //Image<Gray, Byte>[] _masks;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="galleryGEIs">all Gait Energy Images stored in Gallery.</param>
        /// <param name="galleryLabels">labels of Gallery GEIs</param>
        public Fex_TraC(List<Image<Gray, Byte>> galleryGEIs, List<string> galleryLabels)
        {
            // initialization.
            fex = new Fex();
            trac = new TraC();
            humanFrames = new Dictionary<string, List<Image<Gray, byte>>>();
            framesIntensity = new Dictionary<string, List<double>>();
            // setting data.
            _labels = galleryLabels;
            _maskedGEIs = galleryGEIs;
            
            // Resizing & Mask generation.
            //_masks = new Image<Gray, Byte>[_GEIs.Count];
            for (int i = 0; i < _maskedGEIs.Count; i++)
            {
                // Resize Gallery GEIs to be the same size.
                _maskedGEIs[i] = _maskedGEIs[i].Resize(imageSize.Width, imageSize.Height);
                // Generate feature selction mask.
                //_masks[i] = fex.GenerateFeatureMask_i(_GEIs[i]);
            }
        }
        
        /// <summary>
        /// Start Feature Extraction & Classification process. 
        /// </summary>
        /// <param name="currentFrame">current frame.</param>
        /// <param name="currentLabel">label of current frame.</param>
        /// <returns>Result of Recognition.</returns>
        public RecognitionResult Run(Image<Gray, Byte> currentFrame, string currentLabel)
        {
            RecognitionResult ReRe = new RecognitionResult();
            //*****************************************************************\\
            #region // Store the current frame & its intensity
            if (humanFrames.ContainsKey(currentLabel))
                humanFrames[currentLabel].Add(currentFrame);
            else
                humanFrames.Add(currentLabel, new List<Image<Gray, byte>> { currentFrame });
            
            //humanFrames.Add(currentFrame);

            if (framesIntensity.ContainsKey(currentLabel))
                framesIntensity[currentLabel].Add(currentFrame.GetSum().Intensity);
            else
                framesIntensity.Add(currentLabel, new List<double> { currentFrame.GetSum().Intensity });

            //framesIntensity.Add(currentFrame.GetSum().Intensity);
            #endregion
            //*****************************************************************\\
            #region // Detect Cycles for the current human
            List<Image<Gray, Byte>> cycle = null;
            if (humanFrames.Count > 0)
                cycle = fex.DetectOneCycle(humanFrames[currentLabel], framesIntensity[currentLabel]);
            #endregion
            //*****************************************************************\\
            // if Cycle detected
            if (cycle != null)
            {
                ReRe.CycleDetected = true;
                //
                #region // Generate GEI for the current cycle
                Image<Gray, Byte> probeGEI = fex.GenerateGEI(cycle);
                #endregion
                //*****************************************************************\\
                #region Generate Mask for Probe GEI only
                Image<Gray, Byte> ProbeMask = fex.GenerateFeatureMask_i(probeGEI);
                #endregion
                //*****************************************************************\\
                #region // X(i,j) maskedGEIs (by applying masks to galleryGEIs).
                Image<Gray, Byte>[] maskedGalleryGEIs = new Image<Gray, Byte>[_maskedGEIs.Count];
                for (int i = 0; i < _maskedGEIs.Count; i++)
                    maskedGalleryGEIs[i] = _maskedGEIs[i].And(ProbeMask);
                #endregion
                //*****************************************************************\\
                #region // E(i,j) eigenGEIs (by applying PCA). 
                // using OpenCv
                Image<Gray, float>[] eigenGEIs = trac.PrincipalComponentAnalysis_OpenCV(maskedGalleryGEIs);
                #endregion
                //*****************************************************************\\
                #region // fill the dictionary with labels only.
                Dictionary<string, List<Matrix>> dic = new Dictionary<string, List<Matrix>>();
                for (int i = 0; i < maskedGalleryGEIs.Length; i++)
                {
                    if (!dic.ContainsKey(_labels[i]))
                    {
                        dic.Add(_labels[i], new List<Matrix>());
                    }
                }
                #endregion
                //*****************************************************************\\
                #region // get the highest 2*C eigenGEIs only.
                Image<Gray, float>[] principalComponents;
                int NumOfPrincipalComponents = 2 * dic.Count; 
                
                if (eigenGEIs.Length > NumOfPrincipalComponents)
                {
                    principalComponents = new Image<Gray, float>[NumOfPrincipalComponents];
                    for (int i = 0; i < NumOfPrincipalComponents; i++)
                        principalComponents[i] = eigenGEIs[i];
                }
                else
                {
                    principalComponents = new Image<Gray, float>[eigenGEIs.Length];
                    for (int i = 0; i < eigenGEIs.Length; i++)
                        principalComponents[i] = eigenGEIs[i];
                }
                #endregion
                //*****************************************************************\\
                #region // Y(i,j) featureVector (E(i,j) multiplied by X(i,j))
                double[][] PCA_featureVectors = new double[maskedGalleryGEIs.Length][];
                Image<Gray, float> tempGEI;
                for (int i = 0; i < maskedGalleryGEIs.Length; i++)
                {
                    PCA_featureVectors[i] = new double[principalComponents.Length];
                    for (int p = 0; p < principalComponents.Length; p++)
                    {
                        PCA_featureVectors[i][p] = 
                            principalComponents[p].DotProduct(maskedGalleryGEIs[i].Convert<Gray, float>());
                    }
                }

                // feature vector  for probe GeI only.
                double[] PCA_probe_featureVector = new double[principalComponents.Length];
                for (int p = 0; p < principalComponents.Length; p++)
                {
                    PCA_probe_featureVector[p] = 
                        principalComponents[p].DotProduct(probeGEI.And(ProbeMask).Convert<Gray,float>());
                }
                #endregion
                //*****************************************************************\\
                #region // fill the dictionary with classes(persons).
                Matrix featureVector;
                for (int i = 0; i < maskedGalleryGEIs.Length; i++)
                {
                    featureVector = new Matrix(principalComponents.Length, 1);
                    for (int j = 0; j < principalComponents.Length; j++)
                    {
                        featureVector[j, 0] = PCA_featureVectors[i][j];
                    }

                    dic[_labels[i]].Add(featureVector);
                }
                #endregion
                #region MDA
                //*****************************************************************\\
                #region // Calculate SW & SB
                Matrix SB, SW;
                trac.GenerateSwSbMatrices(dic, principalComponents.Length, out SW, out SB);
                #endregion
                //*****************************************************************\\
                #region // convert SB to double[,]
                double[,] A = new double[SB.Rows, SB.Columns];
                for (int row = 0; row < SB.Rows; row++)
                {
                    for (int col = 0; col < SB.Columns; col++)
                    {
                        A[row, col] = SB[row, col];
                    }
                }
                #endregion
                //*****************************************************************\\
                #region // convert SW to double[,]
                double[,] B = new double[SW.Rows, SW.Columns];
                for (int row = 0; row < SW.Rows; row++)
                {
                    for (int col = 0; col < SW.Columns; col++)
                    {
                        B[row, col] = SW[row, col];
                    }
                }
                #endregion
                //*****************************************************************\\
                #region // Solve the linear sytem A*X = Lamda*B*X
                // EigenValues
                double[] D = new double[principalComponents.Length];
                // EigenVectors
                double[,] V = new double[principalComponents.Length, principalComponents.Length]; 

                // 11) A*X = Lamda*B*X (A:SB, B:SW). Calculate Lamda EigenVectors. 
                bool Solved = spdgevd.smatrixgevd(A, principalComponents.Length, true, ref B, true, 1, 1, ref D, ref V);
                #endregion
                //*****************************************************************\\
                
                #region // Final Results
                if (Solved)
                {
                    ReRe.SystemSolved = true;
                    //
                    #region // convert EigenVectors(V) to Matrix
                    Matrix Lamda = new Matrix(principalComponents.Length, principalComponents.Length - 1);
                    for (int row = 0; row < Lamda.Rows; row++)
                    {
                        for (int col = 0; col < Lamda.Columns; col++)
                        {
                            Lamda[row, col] = V[row, col];
                        }
                    }
                    #endregion
                    //*****************************************************************\\
                    #region // convert featureVector to Matrix.
                    Matrix Y = new Matrix(PCA_featureVectors);
                    #endregion
                    //*****************************************************************\\
                    #region // convert probe feature vector to Matrix
                    Matrix Y_probe = new Matrix(1, principalComponents.Length);
                    for (int col = 0; col < principalComponents.Length; col++)
                    {
                        Y_probe[0, col] = PCA_probe_featureVector[col];
                    }
                    #endregion
                    //*****************************************************************\\
                    #region // Calculate Z(i,j)
                    Matrix Z = Matrix.Multiply(Y, Lamda);
                    Matrix Z_probe = Matrix.Multiply(Y_probe,Lamda);
                    #endregion
                    //*****************************************************************\\
                    #region // Calculate distance between Probe & Gallery vectors
                    double sum = 0.0;

                    #region // calculate the distance of the 1st feature vector.
                    for (int col = 0; col < principalComponents.Length-1; col++)
                    {
                        sum += Math.Pow(Z[0, col] - Z_probe[0, col], 2);
                    }
                    double minDistance = Math.Sqrt(sum);
                    int minIndex = 0;
                    #endregion

                    #region // calculate the min distance & its index.
                    for (int row = 1; row < maskedGalleryGEIs.Length; row++)
                    {
                        sum = 0.0;
                        for (int col = 0; col < principalComponents.Length-1; col++)
                        {
                            sum += Math.Pow(Z[row, col] - Z_probe[0, col], 2);
                        }
                        sum = Math.Sqrt(sum);
                        if (sum < minDistance)
                        {
                            minDistance = sum;
                            minIndex = row;
                        }
                    }
                    #endregion

                    ReRe.MinIndex = minIndex;
                    ReRe.MinDistance = minDistance;
                    
                    #endregion
                }
                #endregion
                #endregion

            }
            return ReRe;
         
        }
    }
}
