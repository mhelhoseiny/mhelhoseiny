using System;
using System.Collections.Generic;
using System.Text;

namespace GaitRecognition
{
    public class imageSize
    {
        public static int Width = 100, Height = 150;
    }
}
