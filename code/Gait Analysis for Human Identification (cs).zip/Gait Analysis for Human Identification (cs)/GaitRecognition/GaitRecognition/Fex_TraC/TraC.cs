using System;
using System.Collections.Generic;
using System.Text;
// OpenCV
using Emgu.CV;
// MaPack
using Mapack;

namespace GaitRecognition
{
    public class TraC
    {
        /// <summary>
        /// Get Principal Components by Calculating EigenVectors using OpenCV.
        /// </summary>
        /// <param name="galleryGEIs">Gait Enegy Images stored in Gallery.</param>
        /// <returns>Principal Components.</returns>
        public Image<Gray, float>[] PrincipalComponentAnalysis_OpenCV(Image<Gray, Byte>[] galleryGEIs)
        {
            MCvTermCriteria m = new MCvTermCriteria(double.Epsilon);
            EigenObjectRecognizer obj = new EigenObjectRecognizer(galleryGEIs, ref m);
            return obj.EigenImages;
        }

        /// <summary>
        /// Calculate Within-class SW & Between-class scatter matrices SB.
        /// </summary>
        /// <param name="dic">dictionary of classes & their data.</param>
        /// <param name="vectorSize">number of Principal Components (2*C).</param>
        /// <param name="SW">Within-class scatter matrix SW.</param>
        /// <param name="SB">Between-class scatter matrix SB.</param>
        public void GenerateSwSbMatrices(Dictionary<string, List<Matrix>> dic, int vectorSize,
            out Matrix SW,out Matrix SB)
        {
            // Within-class scatter matrix
            SW = new Matrix(vectorSize, vectorSize);
            // Between-class scatter matrix
            SB = new Matrix(vectorSize, vectorSize); 

            #region // 0) calc the Mean (m) of samples in all classes
            Matrix totalS = new Matrix(vectorSize, 1);
            int SampleCount = 0;
            foreach (KeyValuePair<string, List<Matrix>> k in dic)
            {
                foreach (Matrix ma in k.Value)
                {
                    totalS = Matrix.Add(totalS, ma);
                    SampleCount++;
                }
            }
            Matrix totalM = Matrix.Multiply(totalS, 1.0 / SampleCount);
            #endregion

            Matrix sum, Mi;
            
            foreach (KeyValuePair<string, List<Matrix>> iClass in dic)
            {
                #region // 1) calculte Average of Matrices for one class (Mi).
                sum = new Matrix(vectorSize, 1);
                foreach (Matrix mat in iClass.Value)    // Sum of all matrices for one class
                    sum = Matrix.Add(sum, mat);
                Mi = Matrix.Multiply(sum, 1.0 / iClass.Value.Count);   // Matrices Average
                #endregion
                
                #region // 2) subtract average matrix from all matrices (X - Mi).
                Matrix[] mats = new Matrix[iClass.Value.Count];
                for (int i = 0; i < iClass.Value.Count; i++)
                    mats[i] = Matrix.Subtract(iClass.Value[i], Mi);
                #endregion

                #region // 3) Final steps to Calculate Si
                Matrix Si = new Matrix(vectorSize, vectorSize);
                for (int i = 0; i < mats.Length; i++)
                {
                    // 3) get Transpose of (X - Mi), and multiply them (X - Mi)*(X - Mi)T .
                    // 4) then, Add the result to ScatterMatrix(Si) of current class.
                    Si = Matrix.Add(Si, Matrix.Multiply(mats[i], mats[i].Transpose()));
                }
                #endregion

                #region // 4) add Si to SW
                SW = Matrix.Add(SW, Si);
                #endregion

                #region // 5) calc SB = Sum[ni*(mi - m)*(mi - m)T]
                Matrix sub = Matrix.Subtract(Mi, totalM);
                sub = Matrix.Multiply(Matrix.Multiply(sub, sub.Transpose()), iClass.Value.Count);
                #endregion

                #region // 7) add to SB
                SB = Matrix.Add(SB, sub);
                #endregion
            }
        }
    }
}
