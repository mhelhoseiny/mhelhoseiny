﻿using System;
using System.Collections.Generic;
using System.Text;

//OpenCV
using Emgu.CV;

namespace GaitRecognition
{
    public class Fex
    {

        #region Variables
        
        public double threshold1 = 127;
        public double threshold2 = 230;

        #endregion
  
        
        /// <summary>
        /// Detect one cycle according to silhouette Intensity.
        /// </summary>
        /// <param name="frames">list of all frames for the current human.</param>
        /// <param name="Intensity">list of intensities for each frame in frames list.</param>
        /// <returns>list of frames in one cycle only.</returns>
        public List<Image<Gray, Byte>> DetectOneCycle(List<Image<Gray, Byte>> frames, List<double> Intensity)
        {
            #region get Image with Maximum Intensity
            Image<Gray, Byte> maxImage = frames[0];
            int maxIndex = 0;

            for (int i = 1; i < frames.Count; i++)
            {
                if (GetAvgIntensity(i,Intensity) > GetAvgIntensity(maxIndex,Intensity))
                {
                    maxImage = frames[i];
                    maxIndex = i;
                }
                else
                    break;
            }
            #endregion

            #region get the next frames in the cycle
            List<Image<Gray, byte>> currentCycle = new List<Image<Gray, byte>>();

            currentCycle.Add(maxImage);
            for (int j = maxIndex + 1; j < frames.Count; j++)
            {
                currentCycle.Add(frames[j]);
                if (GetAvgIntensity(j,Intensity) > GetAvgIntensity(j - 1,Intensity))
                {
                    if (j != frames.Count - 1)
                        if (GetAvgIntensity(j,Intensity) > GetAvgIntensity(j + 1,Intensity))
                        {
                            frames.RemoveRange(0, j);
                            Intensity.RemoveRange(0, j);
                            return currentCycle;
                        }
                }

            }
            #endregion
            return null;
        }

        /// <summary>
        /// Get the average intensity of any image by calculating average pixels intensities. 
        /// </summary>
        /// <param name="currentIndex">index of the current frame.</param>
        /// <param name="myIntensity">list containing intensities of all frames.</param>
        /// <returns>average intensity of current frame.</returns>
        private double GetAvgIntensity(int currentIndex, List<double> myIntensity)
        {
            double I1, I2, I3;
            if (currentIndex == 0)
            {
                I1 = 0; I2 = 0;
            }
            else if (currentIndex == 1)
            {
                I1 = 0; I2 = myIntensity[0];
            }
            else
            {
                I1 = myIntensity[currentIndex - 2];
                I2 = myIntensity[currentIndex - 1];
            }
            I3 = myIntensity[currentIndex];

            return (I1 + I2 + I3) / 3;

        }

        /// <summary>
        /// Generate Gait Energy Image (GEI) for a sequence of images.
        /// </summary>
        /// <param name="listOfImages">sequence of frames in one cycle.</param>
        /// <returns>Gait Energy Image (GEI).</returns>
        public Image<Gray, Byte> GenerateGEI(List<Image<Gray, Byte>> listOfImages)
        {
            // make Size Normalization for all images
            listOfImages = SizeNormalization(listOfImages);

            double framesCount = listOfImages.Count;
            // to get the Average of all images
            listOfImages[0]._Mul(1 / framesCount); 
            Image<Gray, Byte> GEI = listOfImages[0];

            for (int i = 1; i < listOfImages.Count; i++)
            {
                listOfImages[i]._Mul(1 / framesCount);
                GEI = GEI.Add(listOfImages[i]);
            }

            return GEI;
        }
        
        /// <summary>
        /// Normalize all silhouette frames to be the same Width & Height.
        /// </summary>
        /// <param name="frames">sequence of frames in one cycle.</param>
        /// <returns>normalized sequence of frames.</returns>
        private List<Image<Gray, Byte>> SizeNormalization(List<Image<Gray, Byte>> frames)
        {
            // get the max width & height
            int maxWidth = frames[0].Width;
            int maxHeight = frames[0].Height;
            for (int i = 0; i < frames.Count; i++)
            {
                if (frames[i].Height > maxHeight)
                    maxHeight = frames[i].Height;
                if (frames[i].Width > maxWidth)
                    maxWidth = frames[i].Width;
            }

            // Normalize Width & Height
            Image<Gray, Byte> temp, currentFrame;
            int diff, frameWidth;
            for (int i = 0; i < frames.Count; i++)
            {
                temp = new Image<Gray, byte>(maxWidth, maxHeight);
                currentFrame = frames[i];
                frameWidth = currentFrame.Width;
                currentFrame = currentFrame.Resize(frameWidth, maxHeight);
                // difference between maxWidth and current frame width divided by 2
                diff = (maxWidth - frameWidth) / 2; 

                for (int row = 0; row < currentFrame.Height; row++)
                {
                    for (int col = 0; col < frameWidth; col++)
                    {
                        temp[row, col + diff] = currentFrame[row, col];
                    }
                }
                // Resize all images to be the same width & height
                frames[i] = temp.Resize(imageSize.Width, imageSize.Height);
            }

            return frames;
        }

        /// <summary>
        /// Generate Feature Selection Mask for a single GEI 
        /// with the selected thresholds(threshold1, threshold2).
        /// </summary>
        /// <param name="grayGEI">Gait Energy Image from which Mask is generated.</param>
        /// <returns>Feature Selection Mask</returns>
        public Image<Gray, Byte> GenerateFeatureMask_i(Image<Gray, Byte> grayGEI)
        {
            Image<Gray, Byte> mask = new Image<Gray, Byte>(grayGEI.Width, grayGEI.Height);
            int len = (mask.Height * 2) / 3;
            double I;

            unsafe
            {
                int imgIndex = 0;
                fixed (byte* img_ptr = grayGEI.Data, msk_ptr = mask.Data)
                {
                    for (int row = 0; row < mask.Height; row++)
                    {
                        for (int col = 0; col < mask.Width; col++)
                        {
                            I = (double)*(img_ptr + imgIndex);
                            
                            if (row < len && I < threshold1)
                                *(msk_ptr + imgIndex) = (byte)255;
                            else if (row >= len && I > threshold2)
                                *(msk_ptr + imgIndex) = (byte)0;
                            else
                            {
                                if (row < len)
                                    *(msk_ptr + imgIndex) = (byte)0;
                                else
                                    *(msk_ptr + imgIndex) = (byte)255;
                            }
                            imgIndex++;

                        }
                    }
                }
            }
            return mask;
        }

        /// <summary>
        /// Generate Feature Selection Mask for a pair of Gallery and Probe GEIs. 
        /// </summary>
        /// <param name="galleryGEI">Gait Energy Image stored in Galley.</param>
        /// <param name="probeGEI">Gait Energy Image for the new person.</param>
        /// <returns>Feature Selection Mask for 2 GEIs.</returns>
        public Image<Gray, byte> GenerateFeatureMask_ij(Image<Gray, byte> galleryGEI,
            Image<Gray, byte> probeGEI)
        {
            return (GenerateFeatureMask_i(galleryGEI).And(GenerateFeatureMask_i(probeGEI)));
        }

    }
}
