﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GaitRecognition
{
    public class RecognitionResult
    {
        public bool CycleDetected = false, SystemSolved = false;
        public int MinIndex = -1;
        public double MinDistance;
        
    }
}
