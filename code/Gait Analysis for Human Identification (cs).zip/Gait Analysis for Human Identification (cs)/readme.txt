This are the essential component of GAHI project

1) Human Detection and Tracking, which conists of background subtraction model, tracking module, human classification based on contours module.
2) Gait recogniition(Fex_TraC.cs): which detect human gait cycle, generate Gait energy image, do PCA followed by MDA(Muliple Discriminat Analysis) 