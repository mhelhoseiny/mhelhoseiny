using System;
using System.Collections.Generic;
using System.Text;

using Emgu.CV;
using Emgu.Util;

namespace HumanDetectionAndTracking
{
    public class MovingObjectDetectio_Gaussian
    {
        #region variables
        Image<Gray, Byte> _meanImage, _medianImage, _intensityHistogram;
        Image<Gray, Byte> _diffImage;
        double _alpha = .9;
        double _TD = 5;
        double _Gat = 50;
        double _MID = 0;
        Image<Gray, Byte> _segma;
        Image<Gray, Byte> _mu;
        Image<Ycc, Byte> _YUVbackground;
        Image<Ycc, Byte> _YUVcurrentImage;
        Image<Gray, Byte> _grayBackground;
        Image<Gray, Byte> _grayCurrent;

        public Image<Gray, Byte> TH1;
        public Image<Gray, Byte> TH2;
        #endregion

        /// <summary>
        /// Constractor
        /// </summary>
        /// <param name="background">backgournd image</param>
        public MovingObjectDetectio_Gaussian(Image<Ycc, Byte> background)
        {
            _YUVbackground = background.Clone();
            _grayBackground = background.Convert<Gray, Byte>();
            _mu = _grayBackground.Clone();
            _segma = _grayBackground.Clone();
        }

        /// <summary>
        /// Segment moving object from background
        /// </summary>
        /// <param name="currentImage">current frame in YUV format</param>
        /// <returns>binary Image contain only forground object(s)</returns>
        public Image<Gray, byte> GenerateBinaryImage(Image<Ycc, Byte> currentImage)
        {
            _YUVcurrentImage = currentImage.Clone();
            _grayCurrent = currentImage.Convert<Gray, Byte>();


            _intensityHistogram = GetMn(_grayBackground.Clone());
            _meanImage = GetBnMean(_grayBackground.Clone());
            _medianImage = GetPnMedian(_grayCurrent.Clone());

            Image<Gray, Byte> sub1 = _medianImage.AbsDiff(_intensityHistogram.Clone());
            Image<Gray, Byte> sub2 = _medianImage.AbsDiff(_meanImage.Clone());
            Image<Gray, Byte> sub3 = _medianImage.AbsDiff(_grayBackground.Clone());

            sub2 = sub2.Min(sub1);
            sub3 = sub3.Min(sub2);
            _diffImage = sub3.Clone();
            _MID = GetMID(_diffImage.Clone());

            TH1 = GetTH1(_segma.Clone());
            TH2 = GetTH2(TH1.Clone());

            _alpha = GetAlpha();

            Image<Gray, Byte> Mask = GetMask(_diffImage.Clone(), TH1.Clone(), TH2.Clone());
            //Image<Gray, Byte> diffImage2 = _diffImage.Clone();
            Image<Gray, Byte> diffImage2 = _meanImage.Clone();
            
            _diffImage = _diffImage.Mul(Mask);

            _diffImage = _diffImage.Mul(255);

            _grayBackground = _mu.Clone();
            _YUVbackground = _YUVcurrentImage.Clone();

            _mu = GetRunningAvg(_mu.Clone(), _grayCurrent.Clone());
            _segma = GetStandardDeviation(_grayCurrent.Clone(), _mu.Clone());
           

          return diffImage2;
           

            return _diffImage.Clone();
        }

        /// <summary>
        /// Intensity value Mn
        /// </summary>
        /// <param name="background">Backgound Image</param>
        /// <returns>Mn represented in image</returns>
        unsafe Image<Gray, Byte> GetMn(Image<Gray, Byte> background)
        {
            #region //vars
            Image<Gray, Byte> intensity_histogram = new Image<Gray, byte>(background.Width, background.Height);
            int[] colors = new int[256];
            int temp = 0;
            int Mn = 0;
            int max = 0;
            #endregion

            #region //Code of Histogram
            fixed (int* ptr_colors = colors)
            {
                fixed (Byte* ptr_Back = background.Data)
                {
                    fixed (Byte* ptr_Histro = intensity_histogram.Data)
                    {
                        int newWidth = intensity_histogram.Data.Length / intensity_histogram.Height;
                        for (int row = 0; row < intensity_histogram.Height; row++)
                        {
                            for (int col = 0; col < newWidth; col++)
                            {
                                for (int newrow = row - 3; newrow < row + 4; newrow++)
                                {
                                    if (newrow >= 0 && newrow < intensity_histogram.Height)
                                    {
                                        for (int newcol = col - 3; newcol < col + 4; newcol++)
                                        {
                                            if (newcol >= 0 && newcol < newWidth)
                                            {
                                                temp = *(ptr_Back + (newrow * newWidth) + newcol);
                                                *(ptr_colors + temp) = *(ptr_colors + temp) + 1;
                                            }
                                        }
                                    }
                                }
                                for (int i = 0; i < colors.Length; i++)
                                {
                                    if (*(ptr_colors + i) > max)
                                    {
                                        max = *(ptr_colors + i);
                                        Mn = i;
                                    }
                                    *(ptr_colors + i) = 0;
                                }
                                max = 0;
                                *(ptr_Back + (row * newWidth) + col) = (byte)Mn;
                            }
                        }
                    }
                }
            }
            #endregion

            intensity_histogram = background.Clone();
            return intensity_histogram;
        }

        /// <summary>
        /// Get mean of each pixel in background image
        /// </summary>
        /// <param name="inpImage">back ground image</param>
        /// <returns>mean value for each pixel represented in image</returns>
        unsafe Image<Gray, Byte> GetBnMean(Image<Gray, Byte> inpImage)
        {
            Image<Gray,Byte> MeanImage = new Image<Gray, Byte>(inpImage.Width, inpImage.Height);
            double Bn = 0;
            double BnV1 = 0;
            double BnV2 = 0;
            double BnH1 = 0;
            double BnH2 = 0;
            double temp = 0;
            fixed (byte* ptr_back = inpImage.Data)
            {
                fixed (byte* ptr_MeanImage = MeanImage.Data)
                {
                    int newWidth = inpImage.Data.Length / inpImage.Height;

                    for (int row = 0; row < inpImage.Height; row++)
                    {
                        for (int col = 0; col < inpImage.Data.Length / inpImage.Height; col++)
                        {
                            Bn = *(ptr_back + (row * newWidth) + col);
                            //vertical pixels
                            if (row != 0)
                                BnV1 = *(ptr_back + ((row - 1) * newWidth) + col);
                            if (row != inpImage.Height)
                                BnV2 = *(ptr_back + ((row + 1) * newWidth) + col);
                            //horizontal pixels
                            if (col != 0)
                                BnH1 = *(ptr_back + (row * newWidth) + (col - 1));
                            if (col != newWidth)
                                BnH2 = *(ptr_back + (row * newWidth) + (col + 1));
                            temp = (BnV1 + BnV2 + BnH1 + BnH2) / 4;
                            *(ptr_back + (row * newWidth) + col) = (Byte)temp;
                            BnV1 = 0;
                            BnV2 = 0;
                            BnH1 = 0;
                            BnH2 = 0;
                        }
                    }
                }
            }
            MeanImage = inpImage.Clone();
            return MeanImage;
        }

        /// <summary>
        /// Get median value for each pixel in current image
        /// </summary>
        /// <param name="inpImage">current image </param>
        /// <returns>medain value of cuurent image represented in image </returns>
        unsafe Image<Gray, Byte> GetPnMedian(Image<Gray, Byte> inpImage)
        {
            double[] Pns = new double[3];
            Image<Gray,Byte> MedianImage = new Image<Gray, Byte>(inpImage.Width, inpImage.Height);
            fixed (byte* ptr_curimage = inpImage.Data)
            {
                fixed (byte* ptr_MedianImage = MedianImage.Data)
                {
                    int newWidth = inpImage.Data.Length / inpImage.Height;
                    fixed (double* ptr_pns = Pns)
                    {
                        for (int row = 0; row < inpImage.Height; row++)
                        {
                            for (int col = 0; col < inpImage.Data.Length / inpImage.Height; col++)
                            {
                                *(ptr_pns) = *(ptr_curimage + (row * newWidth) + col);
                                //vertical pixel
                                if (row != 0)
                                    *(ptr_pns + 1) = *(ptr_curimage + ((row - 1) * newWidth) + col);
                                else
                                    *(ptr_pns + 1) = 0;
                                if (row != newWidth)
                                    *(ptr_pns + 2) = *(ptr_curimage + ((row + 1) * newWidth) + col);
                                else
                                    *(ptr_pns + 2) = 0;
                                Array.Sort(Pns);
                                *(ptr_curimage + (row * newWidth) + col) = (byte)*(ptr_pns + 1);
                            }
                        }
                    }
                }
            }
            MedianImage = inpImage.Clone();
            return MedianImage;
        }

        /// <summary>
        /// Get forground mask 
        /// </summary>
        /// <param name="inpImage">difference between current and current image </param>
        /// <param name="TH1">threshold 1</param>
        /// <param name="TH2">threshold 2</param>
        /// <returns>mask image that used to segment forground</returns>
        unsafe Image<Gray, Byte> GetMask(Image<Gray, Byte> inpImage, Image<Gray, Byte> TH1, Image<Gray, Byte> TH2)
        {
            Image<Gray, Byte> MaskImage = new Image<Gray, Byte>(inpImage.Width, inpImage.Height);

            fixed (byte* ptr_curImage = inpImage.Data)
            {
                fixed (byte* ptr_th1 = TH1.Data)
                {
                    fixed (byte* ptr_th2 = TH2.Data)
                    {
                        fixed (byte* ptr_maskImage = MaskImage.Data)
                        {
                            int newWidth = inpImage.Data.Length / inpImage.Height;
                            for (int row = 0; row < inpImage.Height; row++)
                            {
                                for (int col = 0; col < inpImage.Data.Length / inpImage.Height; col++)
                                {
                                    if (*(ptr_curImage + (row * newWidth) + col) < *(ptr_th1 + (row * newWidth) + col))
                                        *(ptr_maskImage + (row * newWidth) + col) = 0;
                                    else if (*(ptr_curImage + (row * newWidth) + col) >= *(ptr_th2 + (row * newWidth) + col))
                                        *(ptr_maskImage + (row * newWidth) + col) = 1;
                                    else if (*(ptr_curImage + (row * newWidth) + col) > *(ptr_th1 + (row * newWidth) + col)
                              && *(ptr_curImage + (row * newWidth) + col) < *(ptr_th2 + (row * newWidth) + col))
                                    {
                                        if (Shadow_Remove(row, col))
                                            *(ptr_maskImage + (row * newWidth) + col) = 0;
                                        else
                                            *(ptr_maskImage + (row * newWidth) + col) = 1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return MaskImage;
        }

        /// <summary>
        /// Get running avg
        /// </summary>
        /// <param name="inpImage">prev Mu</param>
        /// <param name="curImage">current frame</param>
        /// <returns>running avg represented in image</returns>
        unsafe Image<Gray, Byte> GetRunningAvg(Image<Gray, Byte> inpImage, Image<Gray, Byte> curImage)
        {
            Image<Gray, Byte> Mu;
            inpImage._Mul(_alpha);
            curImage._Mul(1 - _alpha);
            Mu = curImage.Add(inpImage);
            _mu = Mu.Clone();
            return Mu;
        }

        /// <summary>
        /// Get Standard Deviation
        /// </summary>
        /// <param name="curImage">prev Segma</param>
        /// <param name="Mu">current Mu</param>
        /// <returns>Standard Deviation represented in image</returns>
        unsafe Image<Gray, Byte> GetStandardDeviation(Image<Gray, Byte> curImage, Image<Gray, Byte> Mu)
        {
            Mu = Mu.AbsDiff(curImage);
            Mu._Mul(1 - _alpha);
            _segma._Mul(_alpha);
            _segma = Mu.Add(_segma);
            return _segma;
        }

        /// <summary>
        /// Get value of threshold 1
        /// </summary>
        /// <param name="inpImage">current Segma</param>
        /// <returns>threshold 1 represneted in image</returns>
        unsafe Image<Gray, Byte> GetTH1(Image<Gray,Byte>inpImage)
        {
            Image<Gray, Byte> TH1;
            TH1=inpImage.Mul(2);
            TH1 = inpImage.Add(new Gray(_MID));
            TH1 = TH1.Add(new Gray(_TD));
            return TH1;
        }

        /// <summary>
        /// Get value of threshold 2
        /// </summary>
        /// <param name="inpImage">Current threshold 1</param>
        /// <returns>threshold 2 represented in image</returns>
        unsafe Image<Gray, Byte> GetTH2(Image<Gray, Byte> inpImage)
        {
            Image<Gray, Byte> TH2 = inpImage.Add(new Gray(_Gat));
            return TH2;
        }

        /// <summary>
        /// Get value of Alpha
        /// </summary>
        /// <returns>Alpha</returns>
        unsafe double GetAlpha()
        {
            if (_MID < 4)
                return 0.98;
            if (_MID < 7 && _MID >= 4)
                return .93;
            return .88;
        }

        /// <summary>
        /// Get median value MID of difference image
        /// </summary>
        /// <param name="diff_image">Difference image</param>
        /// <returns>MID</returns>
        unsafe double GetMID(Image<Gray, Byte> diff_image)
        {

            byte[] arr = new byte[diff_image.Data.Length];
            int temp1 = 0;
            int temp2 = 0;
            double mid = 0;
            fixed (byte* ptr_arr = arr)
            {
                arr = diff_image.Bytes;
                Array.Sort(arr);
                if (diff_image.Data.Length % 2 == 0)
                {
                    temp1 = *(ptr_arr + (diff_image.Data.Length / 2));
                    temp2 = *(ptr_arr + (diff_image.Data.Length / 2) + 1);
                    mid = (temp1 + temp2) / 2;
                    return mid;
                }
                else
                {
                    mid = *(ptr_arr + (diff_image.Data.Length / 2) + 1);
                    return mid;
                }
            }
        }

        /// <summary>
        /// Chech if this pixel is shadow or not
        /// </summary>
        /// <param name="row">pixel row postion</param>
        /// <param name="col">pixel col postion</param>
        /// <returns>true of this pixel is shadow else false</returns>
        unsafe bool Shadow_Remove(int row, int col)
        {
            #region Variables
            Ycc yccBn = new Ycc();
            Ycc yccPn = new Ycc();
            
            double U1Bn = 0, V1Bn = 0, U1Pn = 0, V1Pn = 0;
            double Un = 0, Vn = 0;
            double BnY = 0;
            double BnY1 = 0;
            double BnY2 = 0;
            double BnY3 = 0;
            double BnY4 = 0;

            double PnY = 0;
            double PnY1 = 0;
            double PnY2 = 0;
            double PnY3 = 0;
            double PnY4 = 0;

            double ThresholdValue = 5;
            double ThresholdValue2 = .9;
            double Diffc = 0;
            double Difft = 0;
            #endregion

            #region Using Pointer
            fixed (byte* ptr_back = _YUVbackground.Data)
            {
                fixed (byte* ptr_current = _YUVcurrentImage.Data)
                {
                    int newWidth = _YUVbackground.Data.Length / _YUVbackground.Height;
                    int i = (row * newWidth) + (col * 3);
                    {
                        #region get Diffc
                        //For Background Image
                        BnY = *(ptr_back + i);
                        Vn = *(ptr_back + i + 1);
                        Un = *(ptr_back + i + 2);
                        U1Bn = Un / BnY;
                        V1Bn = Vn / BnY;
                        //For Current Image
                        PnY = *(ptr_current + i);
                        Vn = *(ptr_current + i + 1);
                        Un = *(ptr_current + i + 2);
                        U1Pn = Un / PnY;
                        V1Pn = Vn / PnY;
                        Diffc = Math.Abs(U1Pn - U1Bn) + Math.Abs(V1Pn - V1Bn);
                        #endregion

                        #region Find Background & current Image Neighbours
                        if (row != 0)
                        {
                            BnY1 = *(ptr_back + (i - newWidth));
                            PnY1 = *(ptr_current + (i - newWidth));
                        }
                        if (row != _YUVbackground.Height)
                        {
                            BnY2 = *(ptr_back + (i + newWidth));
                            PnY2 = *(ptr_current + (i + newWidth));
                        }
                        if (col != 0)
                        {
                            BnY3 = *(ptr_back + i - 3);
                            PnY3 = *(ptr_current + i - 3);
                        }
                        if (col != newWidth)
                        {
                            BnY4 = *(ptr_back + i + 3);
                            PnY4 = *(ptr_current + i + 3);
                        }
                        #endregion

                        #region Get Difft
                        Difft = Math.Abs(Threshold1(PnY, PnY1, ThresholdValue)
                            - Threshold1(BnY, BnY1, ThresholdValue));
                        Difft += Math.Abs(Threshold1(PnY, PnY2, ThresholdValue)
                            - Threshold1(BnY, BnY2, ThresholdValue));
                        Difft += Math.Abs(Threshold1(PnY, PnY3, ThresholdValue)
                            - Threshold1(BnY, BnY3, ThresholdValue));
                        Difft += Math.Abs(Threshold1(PnY, PnY4, ThresholdValue)
                            - Threshold1(BnY, BnY4, ThresholdValue));
                        #endregion
                        if (Difft == 0 && Diffc < ThresholdValue2 && PnY < BnY)
                            return true;
                        else
                            return false;

                    }
                }
            }
            #endregion
        }

        /// <summary>
        /// Get shadow threshold 
        /// </summary>
        /// <param name="No1">1st value</param>
        /// <param name="No2">2nd value</param>
        /// <param name="TH">threshold value for difference</param>
        /// <returns>shadow threshold</returns>
        private double Threshold1(double No1, double No2, double TH)
        {
            double ret;
            double diff = Math.Abs(No1 - No2);
            if (diff > TH)
                ret = 1;
            else
                ret = 0;
            return ret;
        }
    }
}
