using System;
using System.Collections.Generic;
using System.Text;

using Emgu.CV;
using Emgu.Util;

namespace HumanDetectionAndTracking
{
    public class DetectionAndTracking
    {
        /// <summary>
        /// Veriables detection, connected components and tracking :)
        /// </summary>
        MovingObjectDetectio_Gaussian _detection;
        ConnectedComponent _connectedComp;
        AppearanceBasedTracking _tracking;
        Image<Gray, Byte> Seg_image;

        Classification classification = new Classification();
        int Threshold = 23;

        /// <summary>
        /// constractor for Detection and Tracking Phase
        /// </summary>
        /// <param name="background">Initial Value BackGround For your Video used To detect Moving Object</param>
        /// 
        public DetectionAndTracking()
        { }
        public DetectionAndTracking(Image<Ycc,Byte> background)
        {
            _detection = new MovingObjectDetectio_Gaussian(background);
            _connectedComp = new ConnectedComponent();
            _tracking = new AppearanceBasedTracking();
            Load();
        }
        /// <summary>
        /// Detect moving objects & Label each one
        /// </summary>
        /// <param name="currentImage">Current Frame Captured from your camera</param>
        /// <returns>List contain all moving objects with there label in current image</returns>
        public List<ComponentData> Detect_Track_Human(Image<Ycc, Byte> currentImage)
        {
            Image<Gray, Byte> movingObjectSegm;
            List<ComponentData> connectedComp;
            List<ComponentData> humans = new List<ComponentData>();
            MaskData maskData = new MaskData();

            movingObjectSegm = _detection.GenerateBinaryImage(currentImage);
            connectedComp = _connectedComp.Find_ConnectedComponent(movingObjectSegm);
            Seg_image = movingObjectSegm;

            

            foreach (ComponentData comp in connectedComp)
            {
                maskData.Mask = comp.Silhouette.Clone();
                maskData.left = comp.LeftPoint;
                maskData.Right = comp.RightPoint;
                maskData.Top = comp.UpperPoint;
                maskData.Bottom = comp.LowerPoint;
                //comp.Label = 0;
                comp.Label = (byte)_tracking.Track(currentImage, maskData);
                if (comp.Label != 255)
                {
                    humans.Add(comp);
                }
            }
            //humans = classify(connectedComp);
            return humans;
        }

        public Image<Gray, Byte> SegmentedImage
        {
            get { return Seg_image; }
        }



        /// <summary>
        /// Human Classification Code :)
        /// Determine if the Connected component is Human or not.
        /// </summary>
        /// <param name="list">list of connected components to be classified</param>
        /// <returns>list of Humans</returns>
        public List<ComponentData> classify(List<ComponentData> list)
        {
            List<ComponentData> humans = new List<ComponentData>();
            for (int i = 0; i < list.Count; i++)
                if (classification.Classify_Image(list[i].Silhouette, Threshold))
                    humans.Add(list[i]);
            return humans;
        }

        /// <summary>
        /// Get Feature Vector of each component and save it.
        /// </summary>
        /// <param name="list">list of connected components</param>
        public void train(List<ComponentData> list)
        {
            for (int i = 0; i < list.Count; i++)
                classification.Training_Image(list[i].Silhouette);
        }

        /// <summary>
        /// Get Feature Vector of current image only.
        /// </summary>
        /// <param name="_image">the image to be trained and saved</param>
        public void trainImage(Image<Gray, Byte> _image)
        {
            classification.Training_Image(_image);
        }

        /// <summary>
        /// Load stored Feature Vectors.
        /// </summary>
        public void Load()
        {
            classification.LoadFeatureVectors();
        }

        /// <summary>
        /// Save current Feature Vectors.
        /// </summary>
        public void Save()
        {
            classification.SaveFeatureVectors();
        }
    }
}
