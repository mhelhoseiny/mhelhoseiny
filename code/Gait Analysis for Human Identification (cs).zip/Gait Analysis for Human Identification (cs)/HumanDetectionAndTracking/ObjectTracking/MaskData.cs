using System;
using System.Collections.Generic;
using System.Text;

using Emgu.CV;
using Emgu.Util;
using System.Drawing;

namespace HumanDetectionAndTracking
{
    public class MaskData
    {
        public Point Right;
        public Point Bottom;
        public Point Top;
        public Point left;
        public Image<Gray, Byte> Mask;
    }
}
