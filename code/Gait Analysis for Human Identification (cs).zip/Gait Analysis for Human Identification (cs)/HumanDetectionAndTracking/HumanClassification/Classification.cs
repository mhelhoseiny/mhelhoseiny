using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using Emgu.CV;
using Emgu.Util;
using System.Windows.Forms;

namespace HumanDetectionAndTracking
{
    public class Classification
    {
        #region Public Variables
        public List<List<int>> _vectorsFeature = new List<List<int>>();
        public List<List<int>> _trainVF = new List<List<int>>();
        public string vectorFeature = "C:\\vectorFeature.bin";
        #endregion

        /// <summary>
        /// This function take Connected Component and it only call another function Called ==> GetFeatureVector
        /// to calculate VectorFeature for this Connected Component
        /// and will Assign the result in public variable (_vectorsFeature)
        /// </summary>
        /// <param name="image">Connected Components of training object</param>
        public void Training_Image(Image<Gray, byte> image)
        {
            GetFeatureVector(image);
        }

        /// <summary>
        /// This function take Connected Component for unknown object and
        /// Threshold ToCompare with min disstortion of it and the trained image
        /// </summary>
        /// <param name="image">Connected Componets of object</param>
        /// <param name="Threshold">Threshold if it > min diss therefore it's human</param>
        /// <returns>true, if it is Human.
        /// false, if else.</returns>
        public bool Classify_Image(Image<Gray, byte> image, int Threshold)
        {
            #region Private Variables
            List<int> _dist = new List<int>();
            int _minDis = 10000;
            int _vectorDiss = 0;
            #endregion

            //Retrun in Public Variable _vectorsFeature
            GetFeatureVector(image);

            for (int i = 0; i < _trainVF.Count; i++)
            {
                for (int a = 0; a < _vectorsFeature.Count; a++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        _vectorDiss += Math.Abs(_vectorsFeature[a][j] - _trainVF[i][j]);
                    }
                    _dist.Add(_vectorDiss);
                    _vectorDiss = 0;
                }
            }
            _dist.Sort();
            if (_dist.Count == 0)
                return false;
            _minDis = _dist[0];

            if (_minDis < Threshold)
            {
                //MessageBox.Show("It's Human ya Man");
                return true;
            }

            //MessageBox.Show("It Isn't Human ya Man");
            return false;
        }

        /// <summary>
        /// This function calculate the VectorFeature for the given Connected Components
        /// </summary>
        /// <param name="_image">Connected Componets of object</param>
        private void GetFeatureVector(Image<Gray, byte> _image)
        {
            #region Private Variables
            bool _next = true;
            int _left_len = 0, _right_len = 0;
            int CntLeft = 1, CntRight = 1;

            List<int> _vectorFeature;
            List<MCvPoint> _vectorFeature_left;
            List<MCvPoint> _vectorFeature_right;
            #endregion

            #region Get Contour Of Image
            _image = _image.Resize(20, 40);
            Contour ctr = _image.FindContours(Emgu.CV.CvEnum.CHAIN_APPROX_METHOD.CV_CHAIN_APPROX_NONE, Emgu.CV.CvEnum.RETR_TYPE.CV_RETR_CCOMP);
            #endregion

            #region Initialization
            _vectorFeature = new List<int>();
            _vectorFeature_left = new List<MCvPoint>();
            _vectorFeature_right = new List<MCvPoint>();
            #endregion
            
            if (ctr == null)
                return;
            while (_next)
            {
                if (ctr.Total >= 20)
                {
                    #region GetPixels
                    for (int i = 0; i < ctr.Total; i++)
                    {
                        //Left Hand Side
                        if (ctr[i].x <= 10)
                            _vectorFeature_left.Add(ctr[i]);
                        //Right Hand Side
                        else if (ctr[i].x > 10)
                            _vectorFeature_right.Add(ctr[i]);
                    }

                    if (_vectorFeature_left.Count < 10 || _vectorFeature_right.Count < 10)
                    { }
                    #endregion

                    else
                    {
                        #region Select 10 Points From Left and Right
                        _left_len = _vectorFeature_left.Count;
                        _right_len = _vectorFeature_right.Count;
                        if (_left_len >= 20)
                            CntLeft = _left_len / 10;
                        if (_right_len >= 20)
                            CntRight = _right_len / 10;
                        //10 From Left
                        for (int i = 0; i < _left_len; )
                        {
                            if (_vectorFeature.Count >= 10)
                                break;
                            _vectorFeature.Add(_vectorFeature_left[i].x);
                            i += CntLeft;
                        }
                        //10 From Right
                        for (int i = 0; i < _right_len; )
                        {
                            if (_vectorFeature.Count >= 20)
                                break;
                            _vectorFeature.Add(_vectorFeature_right[i].x);
                            i += CntRight;
                        }
                        #endregion

                        #region Add Vector To Vectors
                        _vectorsFeature.Add(_vectorFeature);
                        #endregion
                    }
                }

                #region Check For Next Contour
                if (ctr.HNext != null)
                    ctr = ctr.HNext;
                else
                    _next = false;
                #endregion
            }
        }

        /// <summary>
        /// Loading the FeatureVectors of the trained Connected Components
        /// in public variable ( _trainVF )
        /// </summary>
        public void LoadFeatureVectors()
        {
            try
            {
                if (File.Exists(vectorFeature))
                {
                    IFormatter formatter1 = new BinaryFormatter();
                    Stream stream1 = new FileStream(vectorFeature, FileMode.Open, FileAccess.Read, FileShare.Read);
                    _trainVF = (List<List<int>>)formatter1.Deserialize(stream1);
                    stream1.Close();
                }
                else
                {
                    MessageBox.Show("Feature vector data does not exist!");
                    Application.Exit();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
        }

        /// <summary>
        /// Saving FeatureVectors of Training Connected Components
        /// </summary>
        public void SaveFeatureVectors()
        {
            try
            {
                IFormatter formatter1 = new BinaryFormatter();
                Stream stream1 = new FileStream(vectorFeature, FileMode.OpenOrCreate, FileAccess.Write, FileShare.None);
                formatter1.Serialize(stream1, _vectorsFeature);
                stream1.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Error In Saving File ...");
            }
        }
    }
}
