function [W,L,srKX,srKY, fmin] = DASolveMATLAB(X, Y, Labels, kernel,lambda,l,u, L0,MaxIter)
tic

if(~exist('MaxIter'))
    MaxIter=1000;
end
if(kernel ==1)
    KX = X*X';
    KY = Y*Y';
else
    %KX= GaussianKernel(X,KY)
    %KY= GaussianKernel(Y,Labels)
end
srKX = real(KX^0.5);
srKY = real(KY^0.5);

%L = zeros(size(srKX,1), size(srKY,2));
srKXinv = srKX^-1;
srKYinv = (srKY^-1);
%L = srKXinv*(u.*ones(size(srKXinv,1), size(srKYinv,2) ))*srKYinv;
[iSameClass,jSameClass] = find(Labels==1);
[iDiffClass,jDiffClass] = find(Labels==0);

sCInd = sub2ind(size(Labels),iSameClass,jSameClass) ;
dCInd = sub2ind(size(Labels),iDiffClass,jDiffClass) ;
if(~exist('L0'))
    L = zeros(size(srKX,1), size(srKY,2));
    L0 = L(:);
end;

%objFun = @(x) DAobjFun(x, srKX,srKY,Labels,lambda,l, u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd);


%f0 = DAobjFun(L0, srKX,srKY,Labels,lambda,l, u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd);

%[WCVX,LCVX,srKXCVX, srKYCVX, fxCVX] = DASolveCVX(X, Y, Labels, kernel,lambda,l,u);

%Start with the default options
%options = optimset;
% Modify options setting
%options = optimset(options,'Display', 'off');
%options = optimset(options,'GradObj', 'on');
%options = optimset(options,'Hessian', 'off');
%options = optimset(options,'MaxFunEvals', Inf);
%options = optimset(options,'MaxIter', 1000);
%options = optimset(options,'HessPattern', speye(size(L0,1)));
%options = optimset(options,'TolFun', 1e-14);
%options = optimset(options,'TolX', 1e-10);
%options = optimset(options,'DerivativeCheck', 'on');
%options = optimset(options,'MaxIter', 1000);
%[LVec,fval,exitflag,output,grad,hessian] = fminunc(objFun,L0,options);

%options = struct('GradObj','on','Display','iter','LargeScale','off','HessUpdate','bfgs','InitialHessType','identity','GoalsExactAchieve',1);

[LVec,LValue] = Edminimize(L0,'DAobjFun',-MaxIter,srKX,srKY,Labels,lambda,l,u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd);
[fgd,gd] =  DAobjFun(LVec,srKX,srKY,Labels,lambda,l,u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd);



fmin = fgd;
nx = size(srKX,1);
ny = size(srKY,1);
L = reshape(LVec,nx,ny);

% lastF = fmin;
% i=1;
% LVec = L(:);
% while(true)
%     [f,df] = DAobjFun(LVec, srKX,srKY,Labels,lambda,l, u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd);
%     LVec = LVec-0.0000000001*df;
%     f
%     drop = f-lastF
%     lastF = f;
%     i = i+1;
% end

W = X'*srKXinv*L*srKYinv*Y;
toc
end