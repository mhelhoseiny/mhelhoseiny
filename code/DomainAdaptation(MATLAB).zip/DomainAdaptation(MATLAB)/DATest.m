function [TP,TN,FP, FN] =  DATest(W,L,srKS, srKY,TstTxtFs ,TstVFs, TstLabels,l,u, vis)

PredV =   TstTxtFs*W*TstVFs';

if(exist('vis')&& vis==1)
    Res = PredV(:);
    ll = TstLabels(:);
    dist = Res;
    xout = min(dist):0.01*(max(dist)-min(dist)):max(dist);
    [n1, xout1] = hist(dist(find(ll == 1)), xout);
    [n2, xout2] = hist(dist(find(ll == 0)), xout);
    figure;
    bar(xout,n2,'b')
    hold;
    bar(xout,n1,'r')
end
PredLabels = PredV>((l+u)/2);
TP = size(find((PredLabels==1) & (TstLabels==1)),1);
TN = size(find((PredLabels==0) & (TstLabels==0)),1);
FP = size(find((PredLabels==1) & (TstLabels==0)),1);
FN = size(find((PredLabels==0) & (TstLabels==1)),1);
end