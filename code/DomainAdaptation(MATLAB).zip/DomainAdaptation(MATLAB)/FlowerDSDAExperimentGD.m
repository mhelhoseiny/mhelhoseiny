function FlowerDSDAExperimentGD(trClassRatio,kfold, inverseTrTst, kernel,l, u, TestUnknown,maxClasses)
% trClassRatio = 0.8;
% kfold = 5;
% inverseTrTst = 0;
MaxIter = 10000;
if(~exist('maxClasses'))
    maxClasses = Inf;
end
inverseTrTst=0;
load('F:\Mohamed ELhoseiny\Research\Text-Image Rep\DomainAdaptation\DSFlower\FlowerDSVFs.mat');


load('F:\Mohamed ELhoseiny\Research\Text-Image Rep\TMG_6.0R7\data\flowerDS\clsi\k_102\Yclsi.mat');
AllTxtFs = Yclsi';
AllTxtLabels = [1:size(AllTxtFs,1)]';
load('F:\Mohamed ELhoseiny\Research\Text-Image Rep\DomainAdaptation\DSFlower\Labels.mat');
%i=1;
%istart=1;
LambdaRange = [1,10, 10^-1 10^2, 10^3, 10^4,10^-2];
if(exist('F:\Mohamed ELhoseiny\Research\Text-Image Rep\DomainAdaptation\DSFlower\FlowerDAExpr.mat'))
    load('F:\Mohamed ELhoseiny\Research\Text-Image Rep\DomainAdaptation\DSFlower\FlowerDAExpr.mat')
    %istart=i;
else
    Ls =  cell(size(LambdaRange,2), kfold);
    Ws =  cell(size(LambdaRange,2), kfold);

    VTPs = zeros(size(LambdaRange,2), kfold);
    VTNs = zeros(size(LambdaRange,2), kfold);
    VFPs = zeros(size(LambdaRange,2), kfold);
    VFNs = zeros(size(LambdaRange,2), kfold);

    UKTPs = zeros(size(LambdaRange,2), kfold);
    UKTNs = zeros(size(LambdaRange,2), kfold);
    UKFPs = zeros(size(LambdaRange,2), kfold);
    UKFNs = zeros(size(LambdaRange,2), kfold);

    KUTPs = zeros(size(LambdaRange,2), kfold);
    KUTNs = zeros(size(LambdaRange,2), kfold);
    KUFPs = zeros(size(LambdaRange,2), kfold);
    KUFNs = zeros(size(LambdaRange,2), kfold);

    UUTPs = zeros(size(LambdaRange,2), kfold);
    UUTNs = zeros(size(LambdaRange,2), kfold);
    UUFPs = zeros(size(LambdaRange,2), kfold);
    UUFNs = zeros(size(LambdaRange,2), kfold);
    Fs = zeros(size(LambdaRange,2), kfold);
    dFs = zeros(size(LambdaRange,2), kfold);
  
end

for i =1 : size(LambdaRange,2)
    lambda = LambdaRange(i);
 
    for k=1: kfold
        [TrClsTrImIds, TrClsTrImClasses, TrClsTstImIds, TrClsTstImClasses , UnTrClsImIds , UnTrClsImClasses] =exsplitDA(Labels,trClassRatio, kfold, k);
    
    
    % Do training
    
    TrVFs = VFs(TrClsTrImIds+1,:);
    TrNVFs = size(TrVFs,1);
    TrVFLabels = TrClsTrImClasses';
    TruniqueLabels = unique(TrVFLabels);
    TrTxtFs = AllTxtFs(TruniqueLabels,:);
    TrNTxtFs = size(TrTxtFs,1);
    TrTxtLabels = AllTxtLabels(TruniqueLabels);
    TrLabels = repmat(TrTxtLabels,1, TrNVFs) == repmat(TrVFLabels',TrNTxtFs,1);        
    %[W,L,srKS, srKY] = DASolve(TrTxtFs, TrVFs, TrLabels,kernel,lambda,l,u);
     
    if(size(Ls{i,k},1)==0)
        if(i>1)
            [minLambda, minLambdaI] = min(abs(LambdaRange(1:i-1)-lambda));
            [W,L,srKS, srKY,fmin] = DASolveMATLAB(TrTxtFs, TrVFs, TrLabels,kernel,lambda,l,u,Ls{minLambdaI,k}(:),MaxIter);
        else
            [W,L,srKS, srKY,fmin] = DASolveMATLAB(TrTxtFs, TrVFs, TrLabels,kernel,lambda,l,u);
        end
    else
        %if(i~=1)
        %    [minLambda, minLambdaI] = min(abs(LambdaRange(1:i-1)-lambda));
        %    [W,L,srKS, srKY,fmin] = DASolveMATLAB(TrTxtFs, TrVFs, TrLabels,kernel,lambda,l,u,Ls{minLambdaI,k}(:),MaxIter);
        %else
        [W,L,srKS, srKY,fmin] = DASolveMATLAB(TrTxtFs, TrVFs, TrLabels,kernel,lambda,l,u,Ls{i,k}(:),MaxIter);
        %end
    end
   
    dFs(i,k) = fmin-Fs(i,k);
     Fs(i,k) = fmin;
     Ls{i,k} = L;
     Ws{i,k} = W;
%    PredTrL = TrTxtFs*Wi*TrVFs';
%     TrLabelVec = double(TrLabels(:));
%     PredTrLVec = PredTrL(:);
%     cntN = size(find(TrLabelVec==0),1);
%     cntP = size(TrLabelVec,1)- cntN;
%     
%     svm_model=svmtrain(TrLabelVec, PredTrLVec,['-s 0 -c 1 -w0 ',num2str(1.0/cntN), ' -w1 ',num2str(1.0/cntP)]);
%  
    
    % Do Validation'
    VTstTxtFs = TrTxtFs;
    VTstNTxtFs = size(VTstTxtFs,1);
    VTstTxtLabels = TrTxtLabels;
    VTstVFs = VFs(TrClsTstImIds+1,:);
    VTstNVFs = size(VTstVFs,1);
    VVFLabels = TrClsTstImClasses';
    VTstLabels = repmat(VTstTxtLabels,1, VTstNVFs) == repmat(VVFLabels',VTstNTxtFs,1);       

    [VTP, VTN, VFP, VFN] =  DATest(W,L,srKS, srKY,VTstTxtFs ,VTstVFs, VTstLabels,l,u);
        
    
    VTPs(i,k) =  VTP;
    VTNs(i,k) = VTN;
    VFPs(i,k) = VFP;
    VFNs(i,k) = VFN;
    %% prepare unknown classes
    UnknownClasses = unique(UnTrClsImClasses);
    UCTxtFs = AllTxtFs(UnknownClasses,:);
    
    % Known Unknown
    KTstTxtFs = TrTxtFs;
    KTstNTxtFs = size(KTstTxtFs,1);
    KTstTxtLabels = TrTxtLabels;
    UTstVFs = VFs(UnTrClsImIds+1,:);
    UTstNVFs = size(UTstVFs,1);
    UVFLabels = UnTrClsImClasses';
    
    KUTstLabels = repmat(KTstTxtLabels,1, UTstNVFs) == repmat(UVFLabels',KTstNTxtFs,1);       

     [TP, TN, FP, FN] =  DATest(W,L,srKS, srKY,KTstTxtFs ,UTstVFs, KUTstLabels,l,u);
   
      
    KUTPs(i,k) =  TP;
    KUTNs(i,k) = TN;
    KUFPs(i,k) = FP;
    KUFNs(i,k) = FN; 

    % Unknown Known
    
    UTstTxtFs = UCTxtFs;
    UTstNTxtFs = size(UTstTxtFs,1);
    UTstTxtLabels = UnknownClasses';
    KTstVFs = [TrVFs;VTstVFs];
    KTstNVFs = size(KTstVFs,1);
    KVFLabels = [TrVFLabels;VVFLabels];
    
    UKTstLabels = repmat(UTstTxtLabels,1, KTstNVFs) == repmat(KVFLabels',UTstNTxtFs,1);       

    [TP, TN, FP, FN] =  DATest(W,L,srKS, srKY,UTstTxtFs ,KTstVFs, UKTstLabels,l,u);
   
    
   
    UKTPs(i,k) =  TP;
    UKTNs(i,k) = TN;
    UKFPs(i,k) = FP;
    UKFNs(i,k) = FN; 

  
    
    % Unknown Unknown
    UUTstLabels = repmat(UTstTxtLabels,1, UTstNVFs) == repmat(UVFLabels',UTstNTxtFs,1);       

    [TP, TN, FP, FN] =  DATest(W,L,srKS, srKY,UTstTxtFs ,UTstVFs, UUTstLabels,l,u);
   
    UUTPs(i,k) =  TP;
    UUTNs(i,k) = TN;
    UUFPs(i,k) = FP;
    UUFNs(i,k) = FN;  
    
    save('F:\Mohamed ELhoseiny\Research\Text-Image Rep\DomainAdaptation\DSFlower\FlowerDAExpr.mat',...
    'dFs','Fs','i','k','Ls', 'Ws',...
    'VTPs','VTNs','VFPs','VFNs',...
    'UKTPs','UKTNs','UKFPs','UKFNs',...
    'KUTPs','KUTNs','KUFPs','KUFNs',...
    'UUTPs','UUTNs','UUFPs','UUFNs' );
    
   end
    
    
end

VPrecision = 100*VTPs./(VTPs+VFPs)
VRecall= 100*VTPs./(VTPs+VFNs)
VAcc = 100*(VTPs+VTNs)./(VTPs+VTNs+VFPs+VFNs)

KUPrecision = 100*KUTPs./(KUTPs+KUFPs)
KURecall= 100*KUTPs./(KUTPs+KUFNs)
KUAcc = 100*(KUTPs+KUTNs)./(KUTPs+KUTNs+KUFPs+KUFNs)


UKPrecision = 100*UKTPs./(UKTPs+UKFPs)
UKRecall= 100*UKTPs./(UKTPs+UKFNs)
UKAcc = 100*(UKTPs+UKTNs)./(UKTPs+UKTNs+UKFPs+UKFNs)

UUPrecision = 100*UUTPs./(UUTPs+UUFPs)
UURecall= 100*UUTPs./(UUTPs+UUFNs)
UUAcc = 100*(UUTPs+UUTNs)./(UUTPs+UUTNs+UUFPs+UUFNs)


end