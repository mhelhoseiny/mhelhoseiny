MATLAB code the implementation Domain adaptation for object classification across multiple domains (i.e. images from SLR camer, amazon pictures, etc)
This is a solution of a convex optimization problem. 
