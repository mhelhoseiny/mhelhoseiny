function [f,g] = DAobjFun(LVectorized, srKX,srKY,Labels,lambda,l, u,iSameClass,jSameClass,iDiffClass,jDiffClass,sCInd,dCInd)
    
    %tic
    nx = size(srKX,1);
    ny = size(srKY,1);
    L = reshape(LVectorized,nx,ny);

   
    Tmp = srKX*L*srKY;
   
   
   
    WijSC = max(0, l- Tmp(sCInd));
    CiSameClass  = WijSC.*WijSC;
    WijDC = max(0, Tmp(dCInd)-u);
    CiDiffClass  = WijDC.*WijDC;

    sC = (CiSameClass>0);
    NZI = find(sC);
    WijSCNZ = WijSC(NZI);
    iSameClassNZ = iSameClass(NZI);
    jSameClassNZ = jSameClass(NZI);
    
    dC = (CiDiffClass>0);
    NZI = find(dC);
    WijDCNZ = WijDC(NZI);
    iDiffClassNZ = iDiffClass(NZI);
    jDiffClassNZ = jDiffClass(NZI);
    
    r = size(CiDiffClass,1)/size(CiSameClass,1);
    SumCis = lambda*r*sum(CiSameClass)+ lambda*sum(CiDiffClass);
    Regulizer = 0.5*norm(L,'fro').^2;
    

    
    f = SumCis+Regulizer ;
    

    dfR = L;
    %f2 = 0.5*(norm(L,'fro').^2)+lambda*r*sum(CiSameClass) +lambda*sum(CiDiffClass); 


   
    
    LenSC = size(iSameClassNZ,1)*max(size(L,1),size(L,2));
    MaxLen = 10^7;

    if(LenSC<=MaxLen)
       
        TmpSCVX = srKX(iSameClassNZ,:);
        TmpSCVX2 =  TmpSCVX.*repmat(WijSCNZ,[1, size(TmpSCVX,2)]);
        TmpSCVY = srKY(:, jSameClassNZ)';

        VSCxy = TmpSCVX2'*TmpSCVY;

        dfSC2 = -2*VSCxy;
    else
        Nsubsets = ceil(LenSC/MaxLen);
        subsetSize = floor(size(iSameClassNZ,1)/Nsubsets);
        NrealSubsets = ceil(size(iSameClassNZ,1)/subsetSize);
        maxInd = size(iSameClassNZ,1);
        dfSC2 = zeros(size(L,1),size(L,2));
        for i=1:NrealSubsets
            SCRange = (i-1)*subsetSize+1:min(i*subsetSize,maxInd);
            TmpSCVX = srKX(iSameClassNZ(SCRange),:);
            WiSI =  repmat(WijSCNZ(SCRange),[1, size(TmpSCVX,2)]); 
            TmpSCVX2 =  TmpSCVX.*WiSI;
            TmpSCVY = srKY(:, jSameClassNZ(SCRange))';
            dfSC2 = dfSC2+TmpSCVX2'*TmpSCVY;        
        end
        dfSC2 = -2*dfSC2;
        
        
    end
	
	
    LenDC = size(iDiffClassNZ,1)*max(size(L,1),size(L,2));
    
    if(LenDC<=MaxLen)
       
        TmpDCVX = srKX(iDiffClassNZ,:);
        TmpDCVY = srKY(:, jDiffClassNZ)';
        TmpDCVX2 = TmpDCVX.*repmat(WijDCNZ,[1, size(TmpDCVX,2)]);
        VDCxy = TmpDCVX2'*TmpDCVY;
        dfDC2 = 2*VDCxy;
    else
        Nsubsets = ceil(LenDC/MaxLen);
        subsetSize = floor(size(iDiffClassNZ,1)/Nsubsets);
        NrealSubsets = ceil(size(iDiffClassNZ,1)/subsetSize);
        maxInd = size(iDiffClassNZ,1);
        dfDC2 = zeros(size(L,1),size(L,2));
        for i=1:NrealSubsets
            DCRange = (i-1)*subsetSize+1:min(i*subsetSize,maxInd);
            TmpDCVX = srKX(iDiffClassNZ(DCRange),:);
            WiSI =  repmat(WijDCNZ(DCRange),[1, size(TmpDCVX,2)]); 
            TmpDCVY = srKY(:, jDiffClassNZ(DCRange))';
            TmpDCVX2 = TmpDCVX.*WiSI;
            dfDC2 = dfDC2+TmpDCVX2'*TmpDCVY;
           
        end
        dfDC2 = 2*dfDC2;
        
        
    end
    
    df = dfR+ lambda*(r* dfSC2 +dfDC2);

    g = df(:);
    %toc
    %f
end