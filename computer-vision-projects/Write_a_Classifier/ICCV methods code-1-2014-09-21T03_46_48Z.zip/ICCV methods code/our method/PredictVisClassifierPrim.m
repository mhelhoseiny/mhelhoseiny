% xTr is the training textual feautres
% yTr is the corresponding visual classifiers
% xTst is the testual features to generate classifiers for it
% VFf visual features of Known classes (nxd is ths number of samples in the training data)
% VFlabels is the corresponding labels
% C, B Parameters of the classifgier predictor
% Yp is the predicted y from the regression is UK x d, UK is the count of
% unknown classes

% Param.W0s, Param.Eps0s, Param.Sigmas (Cell Array), Param.DistType =1 (Euclidian) or 
% 2 (Cosine Similarity)
% Param.OneClassSVM =1 or 0
% Param.M5MC1
% Param.M5MC2
% Param.VFsPlus, activated only when DistType =4, No constraints are
% removed
% TODO: resign this function so that it is takes less maintenance

function [Ws, Param,Epss] = PredictVisClassifierPrim( VFk, VFlabels,Yp, C, B, K, Param)

% If needs cross valiodation peform cross validation to slect parameters
%%
Yt=-1*ones(numel(VFlabels),1); %pick the X and Y for the particular SVM inside the loop
Xt= VFk; %X is the same and Y is different
Ws = zeros(size(VFk,2)+1,size(Yp,1) );
Epss=  zeros(size(VFk,1),size(Yp,1) );
fvals = zeros(size(Yp,1),1);


sigmaExists = exist('Param','var')&&isfield(Param, 'Sigmas');

ExParam.DistType = 1;

%Initialization is ignored in case of 4
if(exist('Param','var')&&isfield(Param, 'DistType'))
   ExParam.DistType = Param.DistType;
end

ExParam.OneClassSVM =0;
if(exist('Param','var')&&isfield(Param, 'OneClassSVM'))
   ExParam.OneClassSVM = Param.OneClassSVM;
end

ExParam.M5MC1 = 0;
ExParam.M5MC2 = 0;
if(exist('Param','var')&&isfield(Param, 'M5MC1'))
   ExParam.M5MC1 = Param.M5MC1;
end


if(exist('Param','var')&&isfield(Param, 'M5MC2'))
   ExParam.M5MC2 = Param.M5MC2;
end

% Param.M5MC1
% Param.M5MC2

%Param.ZtoFullData.VFsUKTr 
%Param.ZtoFullData.VFsYKTrLabels
%Param.ZtoFullData.YpTstClasses      
ZeroToFullMode = 0;
if( exist('Param','var')&&isfield(Param, 'ZtoFullData'))
    ZeroToFullMode=1;
end
            
            
for i=1 : size(Yp,1)
    i
    
    if( ZeroToFullMode)
        ExParam.XsPlus = Param.ZtoFullData.VFsUKTr( Param.ZtoFullData.VFsYKTrLabels== Param.ZtoFullData.YpTstClasses(i)   ,:);
    end
    if(sigmaExists)
        ExParam.SigmaInv =  diag(1./Param.Sigmas(i,:));
    end
    if(ExParam.DistType==4)
        ExParam.tW = Param.tW(i,:);
        ExParam.l = Param.l;
    end
    if(( ~exist('Param','var')) || (exist('Param','var')&&(~isfield(Param,'W0s')||~isfield(Param,'Eps0s'))))
        %Ws(:,i) = solvePrim(Xt,Yt, Yp(i,:)', B, C);
        if(i==1)
            [Ws(:,i), fvals(i), Epsi] = solvePrimquadCPLEX(Xt,Yt, Yp(i,:)', B, C, K,ExParam);   
        else
            distI = dist2(Yp(1:i-1,:), Yp(i,:));
            [minV , ind] = min(distI);
             ExParam.varsI = [Ws(:,ind);Epss(:,ind)];
            [Ws(:,i), fvals(i), Epsi] = solvePrimquadCPLEX(Xt,Yt, Yp(i,:)', B, C, K, ExParam);   
        end
    else
        ExParam.varsI = [Param.W0s(:,i);Param.Eps0s(i,:)];
        [Ws(:,i), fvals(i), Epsi] = solvePrimquadCPLEX(Xt,Yt, Yp(i,:)', B, C, K, ExParam); 
    end
    Epss(:,i) = Epsi;
end

Param.K = K;
Param.C = C;
Param.B = B;


%ExParam.varsI, ExParam.SigmaInv
function [w,fval,eps ] = solvePrimquadCPLEX(Xt,Yt, Yp, B, C, K,ExParam)
% options = optimset('Display','iter');
% n = numel(Yt);
% d= size(Xt,2);
% Build Constraint Matrix
% A =  zeros(n, d+1+n);
% A( 1: n, d+2:d+1+n) = -eye(n);
% A( 1: n, 1:d) = (Xt);
% A( 1: n, d+1) = ones(n, 1);
% 
% 
% b = zeros(n,1);
% b(1:n,1) = -1; 
% 
% varsI = [Yp ; zeros(n,1)];
% %
% Hmat = [2*(K+B)*eye(d),zeros(d,n+1); zeros(1,d), 2*B,zeros(1,n); zeros(n,n+1+d )];
% fvec = [-2*B*Yp ;C*ones(n,1)];
% %[varsol,fval,exitflag,output,lambda] = quadprog(Hmat,fvec,A,b,[],[],[],[],varsI,options);
% cplex = Cplex('qcpPrim');
% cplex.Param.qpmethod.Cur=1;
% cplex.Param.solutiontarget.Cur=1;
% cplex.Param.workmem.Cur=1200;
% cplex.Model.sense = 'minimize';
% cplex.addCols(fvec, [], [-inf*ones(d+1,1) ; zeros(n,1) ] ,inf*ones(d+n+1,1));
% cplex.Model.Q = Hmat;
% cplex.addRows(-inf*ones(n,1), A, b);
% cplex.solve();

% fprintf ('\nSolution status = %s\n', cplex.Solution.statusstring);
% fprintf ('Solution value = %f\n', cplex.Solution.objval);
% varsol = cplex.Solution.x;
options = cplexoptimset('cplex');
options.Diagnostics = 'on';
options.qpmethod.Cur=1;
options.lpmethod.Cur=1;
options.solutiontarget.Cur=1;
%options.simplex.display

options.workmem.Cur=1500;

nPluses = 0;
if(isfield(ExParam, 'XsPlus'))
    nPluses = size(ExParam.XsPlus,1);
end

n = numel(Yt);
d= size(Xt,2);


% Build Constraint Matrix

if(ExParam.DistType==4 )
%ExParam.M5MC1 = 0;
%ExParam.M5MC2 = 0;
if(ExParam.M5MC1==1)
    ExParam.M5MC1
    A =  sparse(2*n, d+1+n);
 
    A( 1: n, d+2:d+1+n) = -speye(n);
    A( 1: n, 1:d) = sparse(Xt);
    A( 1: n, d+1) = sparse(ones(n, 1));
    A( n+1: 2*n, d+2:d+1+n) = -speye(n);


    b = sparse(2*n,1);

    if(ExParam.OneClassSVM==0)
    b(1:n,1) = -1;
    end
elseif(ExParam.M5MC2==1)
    ExParam.M5MC2
    A =  sparse(n+1, d+1+n);

    if(numel(Yp) == numel(ExParam.tW))
        A( n+1, 1:d+1) = -sparse(ExParam.tW);
    else
        A( n+1, 1:d) = -sparse(ExParam.tW);
    end
    A( 1: n, d+2:d+1+n) = -speye(n);


    b = sparse(n+1,1);
    
    b(n+1,1) = -ExParam.l;
else
    A =  sparse(2*(n+nPluses)+1, d+1+n+nPluses);
 
    A( 1: n, d+2:d+1+n) = -speye(n);
    A( 1: n, 1:d) = sparse(Xt);
    A( 1: n, d+1) = sparse(ones(n, 1));
    if(nPluses>0)
         A( n+1: n+nPluses, 1:d) = -sparse(ExParam.XsPlus);
         A( n+1: n+nPluses, d+1) = -sparse(ones(nPluses, 1));
         A( n+1: n+nPluses, d+2+n:d+1+n+nPluses) = -speye(nPluses);
    end
    
    if(numel(Yp) == numel(ExParam.tW))
        A( n+nPluses+1, 1:d+1) = -sparse(ExParam.tW);
    else
        A( n+nPluses+1, 1:d) = -sparse(ExParam.tW);
    end
    A( n+2: 2*n+1, d+2:d+1+n) = -speye(n);


    b = sparse(2*(n+nPluses)+1,1);

    if(ExParam.OneClassSVM==0)
    b(1:n+nPluses,1) = -1;
    end
    b(n+nPluses+1,1) = -ExParam.l;
end
elseif(ExParam.DistType~=3)
A =  sparse(2*n, d+1+n);

A( n+1: 2*n, d+2:d+1+n) = -speye(n);
A( 1: n, d+2:d+1+n) = -speye(n);
A( 1: n, 1:d) = sparse(Xt);
A( 1: n, d+1) = sparse(ones(n, 1));

b = sparse(2*n,1);

if(ExParam.OneClassSVM==0)
b(1:n,1) = -1;
end

else
    
A =  sparse(2*n, 2*(d+1)+n);

A( 1: n, 2*(d+1)+1:2*(d+1)+n) = -speye(n);
A( 1: n, 1:d) = sparse(Xt);
A( 1: n, d+1) = sparse(ones(n, 1));


A( n+1:2*n, 2*(d+1)+1:2*(d+1)+n) = -speye(n);


b = sparse(2*n,1);

if(ExParam.OneClassSVM==0)
b(1:n,1) = -1;
end



end


%
if(ExParam.DistType==4 ||ExParam.DistType==5)
Hmat = [2*eye(d),zeros(d,n+nPluses+1); zeros(1,d), 2,zeros(1,n+nPluses); zeros(n+nPluses,n+nPluses+1+d )];

if(ExParam.DistType==4 )
  if(numel(Yp) == numel(ExParam.tW))
  fvec = [-B*Yp-K*ExParam.tW' ;C*ones(n+nPluses,1)];
  else
  fvec = [-B*Yp-K*[ExParam.tW';-2] ;C*ones(n+nPluses,1)];  
  end
else
  fvec = [-B*Yp ;C*ones(n,1)];  
end


if(ExParam.OneClassSVM==1)
   fvec(d+1) =   fvec(d+1)+1;
end

if(ExParam.DistType==4 )
     if(numel(Yp) == numel(ExParam.tW))
        varsI = [ExParam.tW' ; zeros(n+1,1)];
     else
        varsI = [ExParam.tW' ; zeros(n,1)];
     end
else    
varsI = [Yp ; zeros(n,1)];
end


[varsol,fval,exitflag,output,lambda] = cplexqp(Hmat,fvec,A,b,[],[],[],[],varsI,options);
w = varsol(1:d+1,1);
eps =  varsol(d+2:d+1+n,1);

elseif(ExParam.DistType==1)
%% DistType 1
if(~(exist('ExParam', 'var') && isfield(ExParam,'SigmaInv')))
Hmat = [2*(K+B)*eye(d),zeros(d,n+1); zeros(1,d), 2*B,zeros(1,n); zeros(n,n+1+d )];
fvec = [-2*B*Yp ;C*ones(n,1)];
if(ExParam.OneClassSVM==1)
   fvec(d+1) =fvec(d+1)+B;
end

else 
Hmat = [2*(K)*eye(d),zeros(d,n+1); zeros(1,d), 0,zeros(1,n); zeros(n,n+1+d )];
Hmat = Hmat+ [2*(B)*ExParam.SigmaInv,zeros(d+1,n); zeros(n,n+1+d )];
fvec = [-2*B* ExParam.SigmaInv*Yp ;C*ones(n,1)];
if(ExParam.OneClassSVM==1)
   fvec(d+1) =fvec(d+1)+B;
end
end
if(~(exist('ExParam', 'var') && isfield(ExParam,'varsI')))
    varsI = [Yp ; zeros(n,1)];
else
    varsI = ExParam.varsI;
end
[varsol,fval,exitflag,output,lambda] = cplexqp(Hmat,fvec,A,b,[],[],[],[],varsI,options);
w = varsol(1:d+1,1);
eps =  varsol(d+2:d+1+n,1);
elseif(ExParam.DistType==2) %% 2nd formulation cosine similartit
        fprintf('Ignoreing K for cosine similarity mode')
        %% Consine Similarity
        Ypnorm = Yp;
        if(~(exist('ExParam', 'var') && isfield(ExParam,'SigmaInv')))
        Hmat = [2*eye(d),zeros(d,n+1); zeros(1,d), 2,zeros(1,n); zeros(n,n+1+d )];
        fvec = [-B*Ypnorm ;C*ones(n,1)];
        else
        Hmat = [2*ExParam.SigmaInv,zeros(d+1,n); zeros(n,n+1+d )];
        fvec = [-B*ExParam.SigmaInv*Ypnorm ;C*ones(n,1)];
        end
        
        if(ExParam.OneClassSVM==1)
            fvec(d+1) =   fvec(d+1)+1;
        end
        if(~(exist('ExParam', 'var') && isfield(ExParam,'varsI')))
            varsI = [Yp ; zeros(n,1)];
        else
            varsI = ExParam.varsI;
        end
        [varsol,fval,exitflag,output,lambda] = cplexqp(Hmat,fvec,A,b,[],[],[],[],varsI,options);
        w = varsol(1:d+1,1);
        eps =  varsol(d+2:d+1+n,1);
elseif(ExParam.DistType==3)
            if(~(exist('ExParam', 'var') && isfield(ExParam,'SigmaInv')))
                Hmat = zeros(2*(d+1)+n);
                Hmat(1:2*(d+1),1:2*(d+1)) = 2*eye(2*(d+1));
                fvec = [-B*Yp;-2*Yp;C*ones(n,1)];
            else 
                Hmat = zeros(2*(d+1)+n);
                Hmat(1:d+1,1:d+1) = 2*eye(d+1);
                 
                Hmat(d+2:2*(d+1),d+2:2*(d+1)) = 2*ExParam.SigmaInv;
                fvec = [-B*Yp;-2*ExParam.SigmaInv*Yp;C*ones(n,1)];
            end
            if(ExParam.OneClassSVM==1)
               fvec(d+1) =   fvec(d+1)+1;
            end
            if(~(exist('ExParam', 'var') && isfield(ExParam,'varsI')))
                varsI = [Yp ; zeros(d+1+n,1)];
            else
                varsI = ExParam.varsI;
            end      
            

            [varsol,fval,exitflag,output,lambda] = cplexqp(Hmat,fvec,A,b,[],[],[],[],varsI,options);
            exitflag
            w = varsol(1:d+1,1);
            eps =  varsol(2*(d+1)+1:2*(d+1)+n,1);
end
    





function [w,fval,eps ] = solvePrimquad(Xt,Yt, Yp, B, C, K,varsI)

n = numel(Yt);
d= size(Xt,2);
% Build Constraint Matrix
A =  sparse(2*n, d+1+n);

A( n+1: 2*n, d+2:d+1+n) = -speye(n);
A( 1: n, d+2:d+1+n) = -speye(n);
A( 1: n, 1:d) = sparse(Xt);
A( 1: n, d+1) = sparse(ones(n, 1));

b = sparse(2*n,1);
b(1:n,1) = -1; 
if(~exist('varI'))
    varsI = [Yp ; zeros(n,1)];
end
varsI = [Yp ; zeros(n,1)];
%
Hmat = [2*(K+B)*eye(d),zeros(d,n+1); zeros(1,d), 2*B,zeros(1,n); zeros(n,n+1+d )];
fvec = [-2*B*Yp ;C*ones(n,1)];

%cfolder = pwd;
%cd([matlabroot, '\toolbox\matlab\optimfun']);
options = optimset('Algorithm','active-set','Display','iter');
%cd([matlabroot, '\toolbox\optim\optim']);
[varsol,fval,exitflag,output,lambda] = quadprog(Hmat,fvec,A,b,[],[],[],[],varsI,options);
%cd(cfolder);
w = varsol(1:d+1,1);
eps =  varsol(d+2:d+1+n,1);

function [w, fval,eps] = solvePrimfmincon(Xt,Yt, yp, B, C)
options = optimset('GradObj','on');
options = optimset(options,'LargeScale','off');
options = optimset(options,'DerivativeCheck','off');
options = optimset(options,'Display','off');
options = optimset(options,'MaxIter',50);
options = optimset(options,'TolFun',1e-6);
options = optimset(options,'TolX',1e-6);

options = optimset(options,'LineSearchType','cubicpoly');
n = numel(Yt);
d= size(Xt,2);
%options = optimset(options,'TypicalX',d+1+n);
A =  sparse(2*n, d+1+n);

A( n+1: 2*n, d+2:d+1+n) = -speye(n);
A( 1: n, d+2:d+1+n) = -speye(n);
A( 1: n, 1:d) = sparse(Xt);
A( 1: n, d+1) = sparse(ones(n, 1));

b = sparse(2*n,1);
b(1:n,1) = -1; 
varsI = [yp ; zeros(n,1)];
% A =  zeros(2*n, d+1+n);
% 
% A( n+1: 2*n, d+2:d+1+n) = -eye(n);
% A( 1: n, d+2:d+1+n) = -eye(n);
% A( 1: n, 1:d) = Xt;
% A( 1: n, d+1) = ones(n, 1);
% 
% b = zeros(2*n,1);
% b(1:n,1) = -1; 
% varsI = [yp ; zeros(n,1)];

myprimCostfun = @(x)primCostfun(x,n,d,C,B,yp);
%cfolder = pwd;
%cd([matlabroot, '\toolbox\matlab\optimfun']);
% Optimization
[varsol, fval] = fmincon(myprimCostfun,varsI,A, b,[],[],[],[],[], options);
%cd(cfolder)
w = varsol(1:d+1,1);
eps =  varsol(d+2:d+1+n,1);

function [f,df] = primCostfun(vars,n,d,C,B,yp)

w = vars(1:d ,1);
b = vars(d+1 ,1);
epsI =  vars(d+2:d+1+n ,1);
wminyp = ([w;b]-yp);
f = 0.5*(w'*w)+ C*sum( epsI) + B* (wminyp'*wminyp);

df = zeros(d+1+n,1);
df(1:d) = w +2*B * (w-yp(1:d,1)) ; %d/dw
df(d+1) = 2*B*(b-yp(d+1));  %d/db
df(d+2:d+1+n) = C; %d/depsi

% function w = solvePrim(Xt,Yt, yp, B, Ct)
% 
% n = numel(Yt);
% d= size(Xt,2);
% cvx_begin %classical svm
%     variables wtrain(d) e(n) btrain
%     dual variable alphatrain
%     minimize( 0.5*wtrain'*wtrain + Ct*sum(e) + B * ([wtrain;btrain] -yp)'*([wtrain;btrain]-yp) ) %norm(w) almost works except it takes an extra sqrt
%     subject to
%         Yt.*(Xt*wtrain+btrain)-1 +e >0   :alphatrain;
%         e>0; %slack
% cvx_end
% 
% w = [wtrain;btrain];
% 
% 
% function [w,fval,eps ] = solvePrimquadMosek(Xt,Yt, Yp, B, C, K, varsI)
% options = optimset('Display','iter');
% n = numel(Yt);
% d= size(Xt,2);
% % Build Constraint Matrix
% A =  sparse(2*n, d+1+n);
% 
% A( n+1: 2*n, d+2:d+1+n) = -speye(n);
% A( 1: n, d+2:d+1+n) = -speye(n);
% A( 1: n, 1:d) = sparse(Xt);
% A( 1: n, d+1) = sparse(ones(n, 1));
% 
% b = sparse(2*n,1);
% b(1:n,1) = -1; 
% 
% %
% Hmat = [2*(K+B)*eye(d),zeros(d,n+1); zeros(1,d), 2*B,zeros(1,n); zeros(n,n+1+d )];
% fvec = [-2*B*Yp ;C*ones(n,1)];
% 
% 
% if(~exist('varsI'))
%     varsI = [Yp ; zeros(n,1)];
% end
% 
% [varsol,fval,exitflag,output,lambda] = quadprog(Hmat,fvec,A,b,[],[],[],[],varsI,options);
% w = varsol(1:d+1,1);
% eps =  varsol(d+2:d+1+n,1);







